# Hybrid 4-Tier Offline Speech & Touch Capture Engine

Upgrades MoniBuddy's voice capture into a resilient, zero-surprise **4-Tier Progressive Speech & Touch Fallback Architecture (Strategy C)** so users across all browsers and low-spec Android phones can log township transactions online or completely offline without ever losing prepaid mobile data.

### User Review & Critical Decisions

> [!IMPORTANT]
> All core architectural and UX choices below reflect your confirmed preferences from our planning discussion and protect users' prepaid mobile data by default.

- **Confirmed Decision 1 — Strategy C (4-Tier Hybrid Progressive Pipeline)**: Startups perform capability detection and cascade automatically across **Tier 1** (Online Native Web Speech), **Tier 2** (Offline Native On-Device `processLocally = true`), **Tier 3** (Web Worker Quantized WASM Speech Engine cached locally), and **Tier 4** (Visual Category, Slang & Numeric Touch Pad).
- **Confirmed Decision 2 — Hybrid Data-Safe Model Fetching**:
  - **Silent Background Pre-Fetch on Unmetered Wi-Fi**: Inspects the browser Network Information API (`navigator.connection.type === 'wifi'` and `saveData === false`) to silently cache the ~35 MB quantized speech model in the background via Web Worker + Cache API / IndexedDB.
  - **Zero Unsolicited Cellular Downloads + Transparent Opt-In Modal**: Never auto-downloads on cellular (`2G/3G/4G/LTE`) or Data Saver connections. When offline or on a browser without native speech (e.g., Firefox/Opera) and no local model is cached yet, presents the **"Offline Voice Pack Needed"** modal with three non-blocking choices: **Download Now (35 MB)**, **Download Later on Wi-Fi**, and **Use Manual Touch Pad**.
- **Confirmed Decision 3 — Full Township Tier 4 Touch Pad**: Provides high-contrast **Slang Quick-Taps** (*Tiger R10, Choco R20, Clipa R100, Grand R1 000, Stokvel*), **Category Icon Pads**, and a **Tactile Rand Keypad** (`+R10`, `+R20`, `+R50`, `+R100`, `0–9`) with `48×48px` minimum hit targets—accessible automatically on fallback or anytime via a direct mode switcher.

---

### 1. Overview & Core Concept

- **What It Does**: Replaces single-point-of-failure browser voice recognition with an adaptive multi-tier capture pipeline paired with a Progressive Web App offline shell, intelligent Wi-Fi model pre-caching, an explicit cellular data-guard prompt, and a zero-literacy visual touch pad.
- **Target Audience / Persona**: South African township earners, spaza shopkeepers, commuters, and piece-job workers using budget Android phones on prepaid airtime, intermittent 2G/EDGE signal, or alternative browsers like Firefox and Opera.
- **Key Value**: Guarantees 100% transaction-logging availability across every browser and connectivity state while strictly respecting prepaid mobile data balances.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Startup & Unmetered Wi-Fi Upgrade**: When MoniBuddy loads, the speech capability coordinator checks browser Web Speech support, on-device `processLocally` support, cached local model state, and `navigator.connection`. If connected to unmetered Wi-Fi (`saveData === false`), the Web Worker quietly caches the quantized speech pack in the background and surfaces subtle unboxed status text (`Offline voice pack ready`).
  2. **Seamless Voice Capture (Tiers 1 → 2 → 3)**: Tapping **Speak Transaction** selects the fastest zero-data-cost tier available:
     - *Online + Native Support*: Streams fast native recognition (**Tier 1**).
     - *Offline + Native On-Device Support*: Runs native speech with `processLocally = true` (**Tier 2**).
     - *Offline or Firefox/Opera + Cached WASM Pack*: Captures microphone audio via `getUserMedia()`, resamples to 16 kHz mono PCM, and transcribes locally inside a dedicated Web Worker (**Tier 3**) before feeding the transcript into the Vernacular Slang Parser.
  3. **Cellular / Uncached Offline Guard Modal**: If Tier 1/2 cannot run (offline or unsupported browser) and the 35 MB WASM voice pack is not cached yet, the **Offline Voice Pack Needed** modal explains the 35 MB requirement clearly and lets the user choose **Download Now (35 MB)** (with live MB/percentage progress bar and cancel button), **Download Later on Wi-Fi** (queues automatic download for the next Wi-Fi session and opens the Touch Pad immediately), or **Use Manual Touch Pad**.
  4. **Instant Tier 4 Touch Pad (Automatic or Direct Toggle)**: If microphone permission is denied, hardware memory is constrained, or the user taps **Touch Pad** directly, the panel switches smoothly into a tactile grid featuring Money In / Money Out selection, illustrated township category tiles, vernacular slang multipliers (*+1 Tiger R10*, *+1 Choco R20*, *+1 Clipa R100*, *+1 Grand R1 000*), quick Rand adders, and a large-digit numeric pad that builds ledger entries ready to save in one tap.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Utilitarian, daylight-legible mobile financial ledger tailored for one-handed thumb operation on `360px–430px` phones while expanding cleanly across a 12-column desktop workspace.
  - *Color Palette & Mood*: Disciplined 60-30-10 distribution—60% crisp neutral canvas (`bg-slate-50`), 30% clean white structural surfaces (`bg-white` with `border-slate-200` hairline dividers), and 10% high-intent emerald (`bg-emerald-700`) for primary save/mic actions, paired with semantic rose (`text-rose-700`) for Money Out and amber (`text-amber-800`) for data-warning states. Never signals state by color alone.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` (Regular 400, Bold 700) for clear plain-language labels and modals, paired with `JetBrains Mono` (`font-mono tabular-nums`) for all Rand figures, keypad digits, and download progress percentages so numbers never jitter.
  - *Component Styling & Layout*: Single-elevation `rounded-2xl` surface containers with `16px–24px` outer padding, hairline dividers instead of nested card boxes or thick left borders, unboxed inline metadata separated by `·` (zero static pill clutter), and `min-h-[48px] min-w-[48px]` touch targets across all voice, modal, slang, category, and keypad buttons.

- **Interactive Feedback & Motion**:
  - Fast `150ms` tactile press states (`active:scale-[0.98]`, compositor-only `transform` and `opacity`) on every keypad, slang, and category button.
  - Determinate progress bar with byte/percentage readout and instant cancellation while downloading or initializing the WASM model in the Web Worker.
  - Clear inline recovery banners whenever mic permission is blocked, automatically revealing the Tier 4 Touch Pad without trapping the user.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Quantized Whisper Tiny inside a Dedicated Web Worker for Tier 3**
  - *Chosen Approach*: Run quantized `whisper-tiny` ONNX weights via WebAssembly inside an isolated module Web Worker, fed by 16 kHz mono `Float32Array` audio captured via `MediaRecorder` / `AudioContext`.
  - *Why*: Keeps the main UI thread 100% responsive on budget Android phones, works identically across Firefox, Opera, Safari, and Chromium without cloud servers, and persists model weights in browser Cache Storage / IndexedDB across sessions.
  - *Alternatives Considered*: Running inference on the main thread (rejected due to UI freezes on 2 GB RAM devices) or pure Strategy B upfront downloads (rejected to protect prepaid mobile data).

- **Decision 2 — Network-Aware Pre-Fetch Coordinator + Offline PWA Asset Caching**
  - *Chosen Approach*: Combine `navigator.connection` inspection (`type === 'wifi'`, `effectiveType`, `saveData`) and MoniBuddy's active network mode with PWA Service Worker asset precaching so both the app shell and cached voice pack load with zero mobile data.
  - *Why*: Offline speech recognition only helps in real life if the web app itself can open without data and remembers queued *"Download Later on Wi-Fi"* requests when the user walks into a home or hotspot Wi-Fi zone.

- **Decision 3 — Unified Vernacular Ledger Pipeline Across Voice & Touch Tiers**
  - *Chosen Approach*: Both spoken transcripts (Tiers 1–3) and Tier 4 Touch Pad taps produce the same structured `ParsedVoiceEntry` items in the preview list before final ledger commit.
  - *Why*: Users can combine multiple items (e.g., tapping *Taxi* + twice on *+Choco R20*, then adding *Airtime* + *+Clipa R100*), review or adjust amounts, and save everything in a single consistent confirmation flow.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                     PWA Offline Shell & Cache Storage                        │
│   App Shell Precache (HTML/JS/CSS)  +  Cached ONNX Voice Pack (~35 MB q8)    │
└───────────────────────────────────────┬──────────────────────────────────────┘
                                        │
┌───────────────────────────────────────▼──────────────────────────────────────┐
│                Network & Capability Coordinator (Startup / Live)             │
│  • Detects SpeechRecognition, processLocally, getUserMedia, Worker, Cache    │
│  • Monitors navigator.connection (wifi vs cellular, saveData) + online state │
│  • Auto-prefetches Tier 3 pack ONLY on unmetered Wi-Fi or queued Wi-Fi       │
└──────────────────┬────────────────────────────────────────┬──────────────────┘
                   │                                        │
       [Tap "Speak Transaction"]                 [Uncached + Cellular/Offline]
                   │                                        │
┌──────────────────▼──────────────────┐     ┌───────────────▼──────────────────┐
│   4-Tier Progressive Speech Router  │     │  "Offline Voice Pack Needed" UI  │
│                                     │     │  • [Download Now (35 MB)]        │
│  Tier 1: Native Web Speech (Online) │     │  • [Download Later on Wi-Fi]    │
│     │ (offline / network error)     │     │  • [Use Manual Touch Pad]        │
│     ▼                               │     └───────────────┬──────────────────┘
│  Tier 2: Native On-Device           │                     │
│          (processLocally = true)    │                     │
│     │ (unsupported / Firefox / err) │                     │
│     ▼                               │                     │
│  Tier 3: 16kHz PCM Audio Capture    │◀──[If Downloaded]───┘
│          ──▶ WASM Whisper Worker    │
│     │ (mic denied / OOM / declined) │
│     ▼                               │
│  Tier 4: Visual Slang & Keypad UI   │◀──[Declined / Direct Mode Toggle]
└──────────────────┬──────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│            Vernacular Slang Parser  ──▶  Editable Entry Preview              │
│   Converts spoken phrases OR slang/category keypad taps into ZAR entries     │
└───────────────────────────────────────┬──────────────────────────────────────┘
                                        │
                                        ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                  MoniBuddy Local Ledger & Scam Shield State                  │
└──────────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Speech Capability & Model Cache State**: Tracks `activeTier` (`'tier1-cloud' | 'tier2-ondevice' | 'tier3-wasm' | 'tier4-touch'`), `modelStatus` (`'uncached' | 'queued-wifi' | 'downloading' | 'ready' | 'error'`), `downloadProgress` (`0–100`), and `connectionProfile` (`'wifi' | 'cellular' | 'offline' | 'save-data'`). Persists `queuedForWifi` and `modelCached` flags in `localStorage` alongside the actual binary weights in browser Cache Storage.
  - **Tier 4 Touch Pad Composer State**: Tracks `padType` (`'expense' | 'income'`), `selectedCategory` (with icon, default title, and flow direction), `keypadBuffer` (current numeric ZAR value), and `slangBreakdown` (accumulated slang tags such as `choco`, `clipa`) before appending to `parsedEntries`.

- **Interactive Component & State Mapping**:
  - **Voice / Touch Mode Switcher**: Segmented control at the top of the capture panel allowing instant manual switching between **Voice Capture** and **Manual Touch Pad** at any time, plus automatic switching to Touch Pad on Tier 4 fallback.
  - **Smart Speak Button & Live Audio Meter**: Starts Tier 1/2 recognition immediately or records microphone audio for Tier 3 WASM transcription with an explicit **Done Speaking / Transcribe** trigger (plus auto-stop cap at 15 seconds to protect low-RAM devices).
  - **Offline Voice Pack Modal**: Renders only on user-initiated voice capture when Tiers 1 & 2 are unavailable and Tier 3 weights are not yet cached; wires all three CTA buttons to real worker download, Wi-Fi queue persistence, or immediate Touch Pad activation.
  - **Tier 4 Visual Touch Pad**: Wires category icon tiles, vernacular slang quick-add buttons (`+R10 Tiger`, `+R20 Choco`, `+R100 Clipa`, `+R1 000 Grand`, `Stokvel`), quick Rand incrementers (`+R50`), and `0–9` / `Backspace` / `Clear` / `Add Item` controls directly into the preview list and ledger save handler.
  - **In-App Offline Install Action**: Adds a compact PWA **Install App** control in the navigation drawer/bar so users can install MoniBuddy to their Android/iOS home screen for zero-data startup.
