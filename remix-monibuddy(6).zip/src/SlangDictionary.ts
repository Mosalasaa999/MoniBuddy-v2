export interface SlangAliasGroup {
  readonly term: string;
  readonly aliases: readonly string[];
  readonly amount?: number;
  readonly category: string;
}

/**
 * Curated South African vernacular & township currency slang matrix.
 * Ambiguous English homophones ("chalk", "chocolate", "shock", "clip", "sticker", bare "k")
 * are intentionally excluded so everyday grocery/school items never misfire as slang notes.
 */
export const PHONETIC_ALIAS_MATRIX: readonly SlangAliasGroup[] = [
  {
    term: 'tiger',
    aliases: ['tiger', 'taiga', 'tiga', 'tyger', 'tigers', 'ithayiga'],
    amount: 10,
    category: 'General Expense'
  },
  {
    term: 'choco',
    aliases: ['choco', 'choko', 'choc', 'chock', 'chok', 'ichoko', 'i-choko', 'chocos'],
    amount: 20,
    category: 'General Expense'
  },
  {
    term: 'clipa',
    aliases: ['clipa', 'clipper', 'clippers', 'klipa', 'kliper', 'iclipa', 'i-clipa', 'stikka', 'steka'],
    amount: 100,
    category: 'General Expense'
  },
  {
    term: 'grand',
    aliases: ['grand', 'grands', 'thousand', 'nkani'],
    amount: 1000,
    category: 'General Expense'
  },
  {
    term: 'stokvel',
    aliases: ['stokvel', 'stokfele', 'umgalelo', 'mogodisano'],
    category: 'Group Savings'
  },
  {
    term: 'mashonisa',
    aliases: ['mashonisa', 'umashonisa', 'bomashonisa', 'machonisa', 'skopper', 'skoper'],
    category: 'Unregistered Credit / Loan'
  },
  {
    term: 'tjotjo',
    aliases: ['tjotjo', 'tjo-tjo', 'cooldrink money', 'cold drink fee', 'inyoba'],
    category: 'Bribe / Upfront Fee'
  }
];

/**
 * Expands South African phonetic/vernacular money and fraud slang terms into canonical
 * tokens so downstream security parsers (`scamParser.ts`) can match evasive slang phrases
 * such as "send 2 clipa tjotjo to unlock loan" -> "send 2 R100 upfront release fee to unlock loan".
 */
export const expandVernacularAliasesForSecurity = (input: string): string => {
  if (!input) return '';
  return input
    .replace(/\b(tjotjo|tjo[\s-]?tjo|cooldrink\s+money|cold\s+drink\s+fee|inyoba)\b/giu, 'upfront release fee')
    .replace(/\b(umashonisa|bomashonisa|machonisa|skopper|skoper)\b/giu, 'mashonisa')
    .replace(/\b(\d+|one|two|three|four|five)\s+(tiger|taiga|tiga|tyger|tigers|ithayiga)\b/giu, 'R10')
    .replace(/\b(\d+|one|two|three|four|five)\s+(choko|choco|choc|chock|ichoko|chocos)\b/giu, 'R20')
    .replace(/\b(\d+|one|two|three|four|five)\s+(clipa|clipper|clippers|klipa|iclipa|stikka|steka)\b/giu, 'R100');
};

export interface ParsedVoiceEntry {
  type: 'income' | 'expense';
  title: string;
  amount: number;
  category: string;
  tags: string[];
}

export interface ParsedVoiceTransaction {
  entries: ParsedVoiceEntry[];
  slangTags: string[];
}

interface AliasMatch {
  group: SlangAliasGroup;
  alias: string;
  index: number;
  end: number;
}

interface NumberMatch {
  value: number;
  index: number;
  end: number;
  isWordNumber: boolean;
}

interface CategoryMatch {
  category: string;
  type: ParsedVoiceEntry['type'];
  index: number;
  end: number;
}

/**
 * Strict cardinal & vernacular number words ONLY — prepositions/verbs ("to", "too", "for", "won", "ku")
 * are excluded so phrases like "taxi to work" or "for bread" never invent phantom Rand amounts.
 */
const NUMBER_WORDS: Readonly<Record<string, number>> = {
  zero: 0,
  one: 1,
  unye: 1,
  kunye: 1,
  een: 1,
  two: 2,
  mbili: 2,
  bili: 2,
  pedi: 2,
  twee: 2,
  three: 3,
  ntathu: 3,
  thathu: 3,
  tharo: 3,
  drie: 3,
  four: 4,
  nne: 4,
  hlano_four: 4,
  vier: 4,
  five: 5,
  nhlanu: 5,
  hlanu: 5,
  hlano: 5,
  vyf: 5,
  six: 6,
  ses: 6,
  seven: 7,
  sewe: 7,
  eight: 8,
  agt: 8,
  nine: 9,
  nege: 9,
  ten: 10,
  ishumi: 10,
  lesome: 10,
  tien: 10,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fifty: 50,
  hundred: 100
};

/**
 * Category patterns ordered so explicit expense cues ("pay for", "pay rent", "pay electricity",
 * groceries, school, transport) never misfire as salary income.
 */
const CATEGORY_PATTERNS: readonly {
  pattern: RegExp;
  category: string;
  type: ParsedVoiceEntry['type'];
}[] = [
  {
    pattern: /\b(salaries|salary|wage|wages|payslip|stipend|piece\s*job|sassa\s*grant|grant\s*payout|sold\s+stock|spaza\s+sales|market\s+sales|got\s+paid|customer\s+paid|client\s+paid|received\s+(?:cash|money|payment)|earned|income)\b/giu,
    category: 'Salary / Income',
    type: 'income'
  },
  {
    pattern: /\b(spaza|market|emakethe)\b/giu,
    category: 'Market Sales Income',
    type: 'income'
  },
  {
    pattern: /\b(taxi|taxis|transport|bus|train|fare|rank)\b/giu,
    category: 'Transport / Taxi Expense',
    type: 'expense'
  },
  {
    pattern: /\b(data|airtime|internet|wifi|wi-fi|bundle)\b/giu,
    category: 'Connectivity',
    type: 'expense'
  },
  {
    pattern: /\b(electricity|ugesi|motlakase|krag|water|utilities|prepaid\s+token)\b/giu,
    category: 'Utilities',
    type: 'expense'
  },
  {
    pattern: /\b(rent|irenti|housing|accommodation)\b/giu,
    category: 'Housing / Rent',
    type: 'expense'
  },
  {
    pattern: /\b(bread|milk|maize|mealie|groceries|food|chocolate|meat|cooking\s+oil|ukudla|kos)\b/giu,
    category: 'Groceries',
    type: 'expense'
  },
  {
    pattern: /\b(school|uniform|chalk|stationery|books|creche|fees)\b/giu,
    category: 'School / Education',
    type: 'expense'
  },
  {
    pattern: /\b(stokvel|stokfele|umgalelo|mogodisano|society)\b/giu,
    category: 'Group Savings',
    type: 'expense'
  },
  {
    pattern: /\b(pay\s+for|paid\s+for|bought|buy|spent)\b/giu,
    category: 'General Expense',
    type: 'expense'
  }
];

const escapeRegex = (value: string): string => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const findAliases = (text: string): AliasMatch[] => {
  const aliases = PHONETIC_ALIAS_MATRIX
    .flatMap(group => group.aliases.map(alias => ({ group, alias })))
    .sort((left, right) => right.alias.length - left.alias.length);
  const aliasPattern = aliases.map(item => escapeRegex(item.alias)).join('|');
  const regex = new RegExp(`(^|[^\\p{L}\\p{N}])(${aliasPattern})(?=$|[^\\p{L}\\p{N}])`, 'giu');
  const matches: AliasMatch[] = [];

  for (const match of text.matchAll(regex)) {
    const alias = match[2].toLocaleLowerCase();
    const definition = aliases.find(item => item.alias === alias);
    if (!definition || match.index === undefined) continue;
    const aliasOffset = match[0].length - match[2].length;
    const index = match.index + aliasOffset;
    matches.push({
      group: definition.group,
      alias,
      index,
      end: index + match[2].length
    });
  }

  return matches;
};

const NUMBER_WORD_KEYS = Object.keys(NUMBER_WORDS).filter(k => !k.includes('_'));

const findNumberMatches = (text: string): NumberMatch[] => {
  const wordAlternation = NUMBER_WORD_KEYS.join('|');
  const pattern = new RegExp(
    `\\b(\\d+(?:[.,]\\d{1,2})?(?!\\s*k\\b)|${wordAlternation})\\b`,
    'giu'
  );
  const matches: NumberMatch[] = [];

  for (const match of text.matchAll(pattern)) {
    if (match.index === undefined) continue;
    const token = match[1].toLocaleLowerCase();
    const isDigit = /^\d/.test(token);
    const value = isDigit ? Number(token.replace(',', '.')) : NUMBER_WORDS[token];
    if (Number.isFinite(value)) {
      matches.push({
        value,
        index: match.index,
        end: match.index + match[0].length,
        isWordNumber: !isDigit
      });
    }
  }

  return matches;
};

const findCategoryMatches = (text: string): CategoryMatch[] => {
  const matches: CategoryMatch[] = [];
  for (const definition of CATEGORY_PATTERNS) {
    for (const match of text.matchAll(definition.pattern)) {
      if (match.index === undefined) continue;
      // Avoid overlapping duplicate matches where a specific category already matched
      const start = match.index;
      const end = match.index + match[0].length;
      const overlapsExisting = matches.some(
        existing => start < existing.end && end > existing.index
      );
      if (!overlapsExisting) {
        matches.push({
          category: definition.category,
          type: definition.type,
          index: start,
          end
        });
      }
    }
  }
  return matches.sort((a, b) => a.index - b.index);
};

const isSameClause = (text: string, firstIndex: number, secondIndex: number): boolean => {
  const start = Math.min(firstIndex, secondIndex);
  const end = Math.max(firstIndex, secondIndex);
  const span = text.slice(start, end);
  return !/[;!?]|(?<!\d)[.,](?!\d)|\b(?:and|kanye|plus|then|le|en)\b/iu.test(span);
};

const categoryForPosition = (
  text: string,
  targetIndex: number,
  targetEnd: number,
  categories: readonly CategoryMatch[]
): CategoryMatch | undefined => {
  const specificFirst = [...categories].sort((a, b) => {
    const aGeneric = a.category === 'General Expense' ? 1 : 0;
    const bGeneric = b.category === 'General Expense' ? 1 : 0;
    return aGeneric - bGeneric;
  });

  let nearest: { match: CategoryMatch; distance: number } | null = null;
  for (const category of specificFirst) {
    if (!isSameClause(text, category.index, targetIndex)) continue;
    const distance =
      category.end <= targetIndex
        ? targetIndex - category.end
        : category.index >= targetEnd
          ? category.index - targetEnd
          : 0;
    const adjustedDistance =
      category.category === 'General Expense' ? distance + 50 : distance;
    if (!nearest || adjustedDistance < nearest.distance) {
      nearest = { match: category, distance: adjustedDistance };
    }
  }
  return nearest?.match;
};

const quantityBeforeAlias = (
  transcript: string,
  match: AliasMatch,
  numberMatches: readonly NumberMatch[],
  previousAliasEnd: number
): number => {
  const candidate = [...numberMatches]
    .reverse()
    .find(
      number =>
        number.end <= match.index &&
        number.index >= previousAliasEnd &&
        match.index - number.end <= 28 &&
        isSameClause(transcript, number.index, match.index)
    );
  if (!candidate || candidate.value <= 0) return 1;

  const between = transcript.slice(candidate.end, match.index);
  if (!/^[\s,.'’\-]*(?:(?:u|i|a|an|the|x|×)[\s.'’\-]*)*$/iu.test(between)) return 1;
  return candidate.value;
};

const extractCurrencyAmounts = (text: string): NumberMatch[] => {
  const matches: NumberMatch[] = [];
  const patterns: readonly { regex: RegExp; multiplier: number }[] = [
    {
      regex: /\b(?:u)?R\s*(\d+(?:[.,]\d{1,2})?)\s*k\b/giu,
      multiplier: 1000
    },
    {
      regex: /\b(\d+(?:[.,]\d{1,2})?)\s*k\b/giu,
      multiplier: 1000
    },
    {
      regex: /\b(?:u)?R\s*(\d+(?:[.,]\d{1,2})?)(?![\d\p{L}])/giu,
      multiplier: 1
    },
    {
      regex: /\b(\d+(?:[.,]\d{1,2})?)\s*(?:rand|rands|zar)\b/giu,
      multiplier: 1
    }
  ];

  for (const { regex, multiplier } of patterns) {
    for (const match of text.matchAll(regex)) {
      if (match.index === undefined) continue;
      const numericText = match[1];
      const rawVal = Number(numericText.replace(',', '.'));
      const value = Math.round(rawVal * multiplier * 100) / 100;
      if (!Number.isFinite(value) || value <= 0) continue;

      const start = match.index;
      const end = match.index + match[0].length;
      const overlaps = matches.some(m => start < m.end && end > m.index);
      if (!overlaps) {
        matches.push({
          value,
          index: start,
          end,
          isWordNumber: false
        });
      }
    }
  }
  return matches.sort((left, right) => left.index - right.index);
};

export const parseVernacularTransaction = (transcript: string): ParsedVoiceTransaction => {
  const aliases = findAliases(transcript);
  const numbers = findNumberMatches(transcript);
  const categories = findCategoryMatches(transcript);
  const slangTags = [...new Set(aliases.map(match => match.group.term))];
  const positionedEntries: { index: number; entry: ParsedVoiceEntry }[] = [];
  let previousAliasEnd = 0;

  // 1. Slang denomination entries (tiger=R10, choco=R20, clipa=R100, grand=R1000)
  for (const alias of aliases) {
    if (alias.group.amount !== undefined) {
      const categoryMatch = categoryForPosition(transcript, alias.index, alias.end, categories);
      const quantity = quantityBeforeAlias(transcript, alias, numbers, previousAliasEnd);
      const amount = Math.round(alias.group.amount * quantity * 100) / 100;
      const category = categoryMatch?.category ?? alias.group.category;
      positionedEntries.push({
        index: alias.index,
        entry: {
          type: categoryMatch?.type ?? 'expense',
          title: `${category} (${quantity} x R${alias.group.amount} ${alias.group.term})`,
          amount,
          category,
          tags: [alias.group.term]
        }
      });
      previousAliasEnd = alias.end;
    }
  }

  // 2. Explicit currency amounts (e.g., "R32", "50 rand", "100k")
  const currencyAmounts = extractCurrencyAmounts(transcript);
  for (const currency of currencyAmounts) {
    const hasAmountAliasInClause = aliases.some(
      alias =>
        alias.group.amount !== undefined &&
        isSameClause(transcript, alias.index, currency.index)
    );
    const nearestCategory = categoryForPosition(
      transcript,
      currency.index,
      currency.end,
      categories
    );
    const nonAmountAliasInClause = aliases.find(
      alias =>
        alias.group.amount === undefined &&
        isSameClause(transcript, alias.index, currency.index)
    );

    if (hasAmountAliasInClause) continue;

    const resolvedCategory =
      nearestCategory?.category ??
      nonAmountAliasInClause?.group.category ??
      'General Expense';
    const resolvedType = nearestCategory?.type ?? 'expense';
    const clauseTags = aliases
      .filter(a => isSameClause(transcript, a.index, currency.index))
      .map(a => a.group.term);

    positionedEntries.push({
      index: currency.index,
      entry: {
        type: resolvedType,
        title: resolvedCategory,
        amount: currency.value,
        category: resolvedCategory,
        tags: [...new Set(clauseTags)]
      }
    });
  }

  // 3. Bare numeric fallback (e.g., "pay for taxi 20", "wages 600") — digits >= 1 or explicit number words paired with a category
  if (positionedEntries.length === 0) {
    const bareCandidates = numbers.filter(
      n => n.value > 0 && (!n.isWordNumber || categories.length > 0)
    );
    for (const number of bareCandidates) {
      const category = categoryForPosition(transcript, number.index, number.end, categories);
      if (number.isWordNumber && !category) continue;

      const resolvedCategory = category?.category ?? 'General Expense';
      positionedEntries.push({
        index: number.index,
        entry: {
          type: category?.type ?? 'expense',
          title: resolvedCategory,
          amount: number.value,
          category: resolvedCategory,
          tags: slangTags
        }
      });
      break;
    }
  }

  const entries = positionedEntries
    .sort((a, b) => a.index - b.index)
    .map(item => item.entry);

  return { entries, slangTags };
};
