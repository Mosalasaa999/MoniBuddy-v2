import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Radio,
  Wifi,
  WifiOff,
  RefreshCw,
  PhoneCall,
  PhoneOff,
  HardDrive,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';

export const Sync2G: React.FC = () => {
  const {
    networkMode,
    setNetworkMode,
    carrierSimulation,
    syncLedger,
    transactions,
    safeToSpend,
    emergencyBuffer,
    pots,
    addTransaction
  } = useApp();

  const [ussdInput, setUssdInput] = useState<string>('*120*6664#');
  const [isSessionActive, setIsSessionActive] = useState<boolean>(false);
  const [ussdScreenText, setUssdScreenText] = useState<string>('');
  const [currentMenuStep, setCurrentMenuStep] = useState<string>('root');
  const [ussdReplyInput, setUssdReplyInput] = useState<string>('');

  const formatZAR = (amount: number) => {
    return 'R ' + amount.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  const startUssdSession = () => {
    setIsSessionActive(true);
    setCurrentMenuStep('main');
    setUssdScreenText(
      `MoniBuddy Free Menu (*120*6664#)\n` +
      `1. Safe to Spend Balance\n` +
      `2. Emergency Fund\n` +
      `3. Savings Pots\n` +
      `4. Record Cash Taxi (R20)\n` +
      `5. Scam Helpline\n` +
      `0. Exit`
    );
  };

  const handleUssdSubmit = (choice: string) => {
    const trimmed = choice.trim();
    setUssdReplyInput('');

    if (currentMenuStep === 'main') {
      if (trimmed === '1') {
        setCurrentMenuStep('balance');
        setUssdScreenText(
          `Safe to Spend: ${formatZAR(safeToSpend)}\n` +
          `Emergency Fund: ${formatZAR(emergencyBuffer)}\n` +
          `Savings Pots: ${formatZAR(pots.reduce((s, p) => s + p.currentAmount, 0))}\n\n` +
          `1. Back to Menu\n0. Exit`
        );
      } else if (trimmed === '2') {
        setCurrentMenuStep('buffer');
        setUssdScreenText(
          `Emergency Fund: ${formatZAR(emergencyBuffer)}\n\n` +
          `1. Add R50 to Emergency Fund\n` +
          `2. Back to Menu\n` +
          `0. Exit`
        );
      } else if (trimmed === '3') {
        setCurrentMenuStep('pots');
        const potsSummary = pots.length > 0
          ? pots.map((p, idx) => `${idx + 1}. ${p.name}: ${formatZAR(p.currentAmount)}`).join('\n')
          : 'No savings pots yet.';
        setUssdScreenText(
          `Your Savings Pots:\n${potsSummary}\n\n` +
          `1. Back to Menu\n0. Exit`
        );
      } else if (trimmed === '4') {
        addTransaction({
          type: 'expense',
          title: 'Taxi fare (Recorded via USSD)',
          amount: 20,
          category: 'Transport',
          date: new Date().toISOString().split('T')[0]
        });
        setCurrentMenuStep('main');
        setUssdScreenText(
          `✓ R20.00 Taxi fare recorded!\n` +
          `New Safe to Spend: ${formatZAR(Math.max(0, safeToSpend - 20))}\n\n` +
          `1. Back to Menu\n0. Exit`
        );
      } else if (trimmed === '5') {
        setCurrentMenuStep('scam');
        setUssdScreenText(
          `Free Helplines:\n` +
          `Bank Fraud: 0860 101 248\n` +
          `Police / Extortion: 08600 10111\n\n` +
          `1. Back to Menu\n0. Exit`
        );
      } else if (trimmed === '0') {
        endUssdSession();
      } else {
        startUssdSession();
      }
    } else if (currentMenuStep === 'buffer') {
      if (trimmed === '1') {
        addTransaction({
          type: 'buffer_deposit',
          title: 'Saved R50 for emergency (via USSD)',
          amount: 50,
          category: 'Buffer',
          date: new Date().toISOString().split('T')[0]
        });
        setCurrentMenuStep('main');
        setUssdScreenText(`✓ R50 added to your emergency fund!\n\n1. Back to Menu\n0. Exit`);
      } else {
        startUssdSession();
      }
    } else {
      if (trimmed === '1') {
        startUssdSession();
      } else {
        endUssdSession();
      }
    }
  };

  const endUssdSession = () => {
    setIsSessionActive(false);
    setCurrentMenuStep('root');
    setUssdScreenText('');
    setUssdInput('*120*6664#');
  };

  const pressKeypad = (char: string) => {
    if (!isSessionActive) {
      setUssdInput(prev => prev + char);
    } else {
      setUssdReplyInput(prev => prev + char);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <PhoneCall className="h-6 w-6 text-emerald-700" />
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Use Without Data (USSD &amp; Offline)
          </h2>
          <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-800 ring-1 ring-emerald-600/20">
            No Airtime Needed
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-0.5">
          See how you can dial *120*6664# on any simple button phone to check your balances for free without data.
        </p>
      </div>

      {/* Connection Mode Choices */}
      <div>
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
          Try Different Signal Conditions:
        </span>
        <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={() => setNetworkMode('2g')}
            className={`rounded-2xl border p-4 text-left transition-all ${
              networkMode === '2g'
                ? 'border-amber-400 bg-amber-50/70 ring-2 ring-amber-500/30'
                : 'border-slate-200 bg-white hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs sm:text-sm font-bold text-slate-900">Slow 2G Network</span>
              <Radio className={`h-4 w-4 ${networkMode === '2g' ? 'text-amber-600' : 'text-slate-400'}`} />
            </div>
            <p className="mt-1 text-xs text-slate-500 leading-snug">
              When phone signal is weak in rural areas. Uses tiny, cheap packets of data.
            </p>
          </button>

          <button
            onClick={() => setNetworkMode('4g')}
            className={`rounded-2xl border p-4 text-left transition-all ${
              networkMode === '4g'
                ? 'border-emerald-400 bg-emerald-50/70 ring-2 ring-emerald-500/30'
                : 'border-slate-200 bg-white hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs sm:text-sm font-bold text-slate-900">Normal Internet</span>
              <Wifi className={`h-4 w-4 ${networkMode === '4g' ? 'text-emerald-600' : 'text-slate-400'}`} />
            </div>
            <p className="mt-1 text-xs text-slate-500 leading-snug">
              When you are in town with normal Wi-Fi or cellular bundle.
            </p>
          </button>

          <button
            onClick={() => setNetworkMode('offline')}
            className={`rounded-2xl border p-4 text-left transition-all ${
              networkMode === 'offline'
                ? 'border-rose-400 bg-rose-50/70 ring-2 ring-rose-500/30'
                : 'border-slate-200 bg-white hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs sm:text-sm font-bold text-slate-900">Zero Internet (Airplane)</span>
              <WifiOff className={`h-4 w-4 ${networkMode === 'offline' ? 'text-rose-600' : 'text-slate-400'}`} />
            </div>
            <p className="mt-1 text-xs text-slate-500 leading-snug">
              Zero connectivity. All your numbers are saved directly on your phone.
            </p>
          </button>
        </div>
      </div>

      {/* Feature Phone Simulator & Local Data Info */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Button Phone Simulator */}
        <div className="lg:col-span-6 flex flex-col items-center">
          <div className="w-full max-w-xs rounded-3xl border-4 border-slate-800 bg-slate-950 p-4 text-white shadow-xl">
            <div className="flex items-center justify-between px-1 pb-2 text-[10px] text-slate-400 font-mono">
              <span>MTN / VODACOM</span>
              <span>FREE USSD</span>
            </div>

            {/* LCD Screen */}
            <div className="rounded-xl border border-emerald-900 bg-emerald-950/90 p-3 font-mono text-emerald-300 min-h-[170px] flex flex-col justify-between text-xs">
              {!isSessionActive ? (
                <div>
                  <div className="text-[11px] text-emerald-400/80">Dial free code:</div>
                  <div className="mt-2 text-xl font-bold tracking-wider text-emerald-100">
                    {ussdInput}
                  </div>
                  <p className="mt-3 text-[10px] text-emerald-400/80 leading-snug">
                    Tap the green Call button below to see the interactive menu on a button phone.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <pre className="text-xs whitespace-pre-wrap text-emerald-200 leading-relaxed">
                    {ussdScreenText}
                  </pre>

                  <div className="flex gap-1 pt-2 border-t border-emerald-900/60">
                    <input
                      type="text"
                      value={ussdReplyInput}
                      onChange={e => setUssdReplyInput(e.target.value)}
                      placeholder="Type number..."
                      className="w-full rounded bg-emerald-900 px-2 py-1 text-xs text-white focus:outline-hidden"
                      autoFocus
                      onKeyDown={e => {
                        if (e.key === 'Enter') handleUssdSubmit(ussdReplyInput);
                      }}
                    />
                    <button
                      onClick={() => handleUssdSubmit(ussdReplyInput)}
                      className="rounded bg-emerald-600 px-2 text-xs font-bold text-white hover:bg-emerald-500"
                    >
                      Send
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Call button */}
            <div className="mt-3">
              {!isSessionActive ? (
                <button
                  onClick={startUssdSession}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2 text-xs font-bold text-white hover:bg-emerald-500"
                >
                  <PhoneCall className="h-4 w-4" />
                  <span>Call *120*6664# (Free)</span>
                </button>
              ) : (
                <button
                  onClick={endUssdSession}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-rose-600 py-2 text-xs font-bold text-white hover:bg-rose-500"
                >
                  <PhoneOff className="h-4 w-4" />
                  <span>End Call</span>
                </button>
              )}
            </div>

            {/* Keypad */}
            <div className="mt-3 grid grid-cols-3 gap-1.5">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map(k => (
                <button
                  key={k}
                  onClick={() => pressKeypad(k)}
                  className="rounded-lg bg-slate-800 py-2 font-mono text-xs font-bold text-slate-200 hover:bg-slate-700 active:scale-95 transition-all"
                >
                  {k}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Plain explanation of phone storage */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
            <h4 className="text-sm font-bold text-slate-900">All Your Numbers Are Saved on Your Phone</h4>
            <p className="mt-1 text-xs text-slate-600 leading-relaxed">
              You never need an expensive internet bundle to use MoniBuddy. Everything is stored directly in your phone browser, so it works even if you run out of airtime.
            </p>

            <div className="mt-4 rounded-2xl bg-slate-50 p-4 border border-slate-100 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500">Unsaved changes:</span>
                <span className="font-bold text-slate-800">
                  {transactions.filter(t => !t.synced).length} records
                </span>
              </div>

              <button
                onClick={syncLedger}
                disabled={carrierSimulation.isSyncing || networkMode === 'offline'}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-700 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 disabled:opacity-50 transition-colors"
              >
                <RefreshCw className={`h-4 w-4 ${carrierSimulation.isSyncing ? 'animate-spin' : ''}`} />
                <span>
                  {carrierSimulation.isSyncing
                    ? 'Updating...'
                    : networkMode === 'offline'
                    ? 'Offline (Saved on device)'
                    : 'Save & Reconcile Now'}
                </span>
              </button>
            </div>

            <div className="mt-4 space-y-2 text-xs text-slate-600">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Works on 2G edge networks with almost zero data cost.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Button phones can dial the free USSD shortcode anytime.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
