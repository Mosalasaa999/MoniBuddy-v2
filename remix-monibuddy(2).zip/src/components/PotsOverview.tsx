import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GoalPot } from '../types';
import {
  ShieldCheck,
  PiggyBank,
  Plus,
  ChevronDown,
  ChevronUp,
  Info,
  TrendingUp,
  Trash2,
  Lock,
  Edit2
} from 'lucide-react';

interface PotsOverviewProps {
  onOpenNewPotModal: () => void;
  onOpenBufferModal: () => void;
  onSelectPotForAction: (pot: GoalPot, mode: 'deposit' | 'withdraw') => void;
}

export const PotsOverview: React.FC<PotsOverviewProps> = ({
  onOpenNewPotModal,
  onOpenBufferModal,
  onSelectPotForAction
}) => {
  const {
    t,
    startingBalance,
    setStartingBalance,
    safeToSpend,
    totalIncome,
    totalExpenses,
    totalGoalSavings,
    emergencyBuffer,
    burnRate,
    weeksBufferCovers,
    estimatedMonthEndSafe,
    pots,
    deletePot
  } = useApp();

  const [editingStarting, setEditingStarting] = useState<boolean>(false);
  const [startingInput, setStartingInput] = useState<string>(startingBalance.toString());
  const [showHowItWorks, setShowHowItWorks] = useState<boolean>(false);

  const handleSaveStarting = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(startingInput);
    if (!isNaN(val) && val >= 0) {
      setStartingBalance(val);
      setEditingStarting(false);
    }
  };

  const formatZAR = (amount: number) => {
    return 'R ' + amount.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  return (
    <div className="space-y-6">
      {/* Friendly Privacy Welcome Banner */}
      <div className="flex items-center justify-between rounded-2xl border border-emerald-200/90 bg-emerald-50/70 p-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-700 text-white shadow-xs">
            <Lock className="h-4 w-4" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-emerald-950">
              {t.goodDayBanner}
            </h4>
            <p className="text-[11px] sm:text-xs text-emerald-800/90 mt-0.5">
              {t.goodDayBannerSub}
            </p>
          </div>
        </div>
        <span className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800">
          <span className="h-2 w-2 rounded-full bg-emerald-600"></span>
          100% Private
        </span>
      </div>

      {/* HERO CARD: SAFE TO SPEND TODAY */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950 p-6 text-white shadow-xl ring-1 ring-white/10 sm:p-8">
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              {t.safeToSpend}
            </span>
            <button
              onClick={() => {
                setStartingInput(startingBalance > 0 ? startingBalance.toString() : '');
                setEditingStarting(!editingStarting);
              }}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-900/60 px-2.5 py-1 text-xs font-semibold text-emerald-200 hover:bg-emerald-800/60 transition-colors border border-emerald-700/50"
            >
              <Edit2 className="h-3 w-3" />
              <span>Change Starting Cash</span>
            </button>
          </div>

          <div className="mt-3 flex items-baseline gap-2">
            <span className="font-mono text-4xl sm:text-5xl font-extrabold tracking-tight text-white">
              {formatZAR(safeToSpend)}
            </span>
          </div>

          <p className="mt-2 text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-xl">
            {t.safeToSpendDesc}
          </p>

          {/* Quick Edit Starting Balance Dropdown Form */}
          {editingStarting && (
            <form onSubmit={handleSaveStarting} className="mt-4 rounded-xl border border-emerald-700/60 bg-emerald-900/50 p-3 max-w-md animate-in fade-in-50">
              <label className="block text-xs font-bold text-emerald-200">
                How much total cash / bank balance do you have right now?
              </label>
              <div className="mt-2 flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm font-bold text-emerald-300">R</span>
                  <input
                    type="number"
                    step="any"
                    value={startingInput}
                    onChange={e => setStartingInput(e.target.value)}
                    placeholder="0.00"
                    className="w-full rounded-lg border border-emerald-600/70 bg-emerald-950 pl-8 pr-3 py-1.5 text-sm font-mono text-white placeholder:text-emerald-500/60 focus:outline-hidden"
                    autoFocus
                  />
                </div>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-500 px-3.5 py-1.5 text-xs font-bold text-emerald-950 hover:bg-emerald-400"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setEditingStarting(false)}
                  className="rounded-lg border border-emerald-700 px-2.5 py-1.5 text-xs text-emerald-300 hover:bg-emerald-800/40"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* 5 Simple Clean Stat Boxes */}
          <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-5">
            <div className="rounded-xl border border-emerald-900/60 bg-emerald-950/60 p-2.5 sm:p-3">
              <div className="text-[10px] font-bold uppercase text-emerald-300">
                {t.startingTotal}
              </div>
              <div className="mt-1 font-mono text-sm sm:text-base font-bold text-white">
                {formatZAR(startingBalance)}
              </div>
            </div>

            <div className="rounded-xl border border-emerald-900/60 bg-emerald-950/60 p-2.5 sm:p-3">
              <div className="text-[10px] font-bold uppercase text-emerald-300">
                {t.income}
              </div>
              <div className="mt-1 font-mono text-sm sm:text-base font-bold text-emerald-300">
                +{formatZAR(totalIncome)}
              </div>
            </div>

            <div className="rounded-xl border border-emerald-900/60 bg-emerald-950/60 p-2.5 sm:p-3">
              <div className="text-[10px] font-bold uppercase text-emerald-300">
                {t.expenses}
              </div>
              <div className="mt-1 font-mono text-sm sm:text-base font-bold text-rose-300">
                -{formatZAR(totalExpenses)}
              </div>
            </div>

            <div className="rounded-xl border border-emerald-900/60 bg-emerald-950/60 p-2.5 sm:p-3">
              <div className="text-[10px] font-bold uppercase text-emerald-300">
                {t.goalSavings}
              </div>
              <div className="mt-1 font-mono text-sm sm:text-base font-bold text-teal-300">
                {formatZAR(totalGoalSavings)}
              </div>
            </div>

            <div className="col-span-2 sm:col-span-1 rounded-xl border border-emerald-900/60 bg-emerald-950/60 p-2.5 sm:p-3">
              <div className="text-[10px] font-bold uppercase text-emerald-300">
                {t.emergencyBuffer}
              </div>
              <div className="mt-1 font-mono text-sm sm:text-base font-bold text-amber-300">
                {formatZAR(emergencyBuffer)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Simplified Month-End Forecast */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs flex items-center gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
          <TrendingUp className="h-5 w-5" />
        </div>
        <div className="text-xs text-slate-600 leading-relaxed">
          {estimatedMonthEndSafe !== null ? (
            <span>
              <strong>Month-end estimate:</strong> At your current daily spending, you will likely have{' '}
              <strong className="text-emerald-700 font-mono text-sm">{formatZAR(estimatedMonthEndSafe)}</strong> left at the end of the month.
            </span>
          ) : (
            <span>
              <strong>Tip:</strong> Log at least 3 daily expenses to unlock a simple forecast of whether your cash will last until month-end.
            </span>
          )}
        </div>
      </div>

      {/* Helpful Tips: How MoniBuddy Helps You (Collapsible) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-emerald-600" />
            <h4 className="text-xs sm:text-sm font-bold text-slate-900">{t.howItWorks}</h4>
          </div>
          <button
            onClick={() => setShowHowItWorks(!showHowItWorks)}
            className="flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800"
          >
            <span>{showHowItWorks ? t.hide : t.show}</span>
            {showHowItWorks ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>
        </div>

        {showHowItWorks && (
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 animate-in fade-in-50 pt-2 border-t border-slate-100">
            <div className="rounded-xl bg-slate-50 p-3">
              <div className="text-base mb-1">🍚</div>
              <h5 className="text-xs font-bold text-slate-900">1. Savings Pots</h5>
              <p className="mt-1 text-[11px] text-slate-600 leading-snug">
                Put money away for groceries, spaza stock, and school so you don&apos;t accidentally spend it.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 p-3">
              <div className="text-base mb-1">🛡️</div>
              <h5 className="text-xs font-bold text-slate-900">2. Emergency Cushion</h5>
              <p className="mt-1 text-[11px] text-slate-600 leading-snug">
                Build a small backup fund so you never need to borrow from expensive loan sharks (mashonisa).
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 p-3">
              <div className="text-base mb-1">🚨</div>
              <h5 className="text-xs font-bold text-slate-900">3. Scam Checker</h5>
              <p className="mt-1 text-[11px] text-slate-600 leading-snug">
                Check fake SASSA, job, or banking messages for free right on your phone without internet.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 p-3">
              <div className="text-base mb-1">📶</div>
              <h5 className="text-xs font-bold text-slate-900">4. Works Without Data</h5>
              <p className="mt-1 text-[11px] text-slate-600 leading-snug">
                Dial *120*6664# on any button phone for free to check your numbers even with zero airtime.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Two Main Cards: Emergency Fund & Savings Pots */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {/* Emergency Fund Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-slate-500">
                {t.emergencyBuffer}
              </span>
              <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" />
                No Loan Sharks
              </span>
            </div>

            <div className="mt-2 font-mono text-3xl font-extrabold text-slate-900">
              {formatZAR(emergencyBuffer)}
            </div>

            <p className="mt-1 text-xs text-slate-500">
              {weeksBufferCovers > 0 ? (
                <span>Covers about <strong className="text-slate-800">{weeksBufferCovers} weeks</strong> of essential household groceries</span>
              ) : (
                'Start with R50 or R100 to build your family cushion'
              )}
            </p>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-100">
            <button
              onClick={onOpenBufferModal}
              className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-emerald-700 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>{t.addToBuffer}</span>
            </button>
          </div>
        </div>

        {/* Savings Pots Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-slate-500">
                {t.goalSavings}
              </span>
              <span className="flex items-center gap-1 text-[11px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-full">
                <PiggyBank className="h-3.5 w-3.5 text-teal-700" />
                {pots.length} {pots.length === 1 ? 'Pot' : 'Pots'} Active
              </span>
            </div>

            <div className="mt-2 font-mono text-3xl font-extrabold text-slate-900">
              {formatZAR(totalGoalSavings)}
            </div>

            <p className="mt-1 text-xs text-slate-500">
              Money safely set aside for upcoming needs
            </p>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-100">
            <button
              onClick={onOpenNewPotModal}
              className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-slate-900 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-slate-800 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>{t.newGoalPot}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Micro Savings Pots Section */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900">{t.microSavingsPots}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{t.potsSubtitle}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenNewPotModal}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-700 px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{t.newGoalPot}</span>
            </button>
          </div>
        </div>

        {pots.length === 0 ? (
          <div className="py-10 text-center animate-in fade-in">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
              <PiggyBank className="h-6 w-6" />
            </div>
            <h4 className="mt-3 text-sm font-bold text-slate-800">No savings pots yet</h4>
            <p className="mx-auto mt-1 max-w-sm text-xs text-slate-500">
              {t.emptyPotsMsg}
            </p>
            <div className="mt-4 flex items-center justify-center">
              <button
                onClick={onOpenNewPotModal}
                className="rounded-xl bg-emerald-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-800"
              >
                {t.createFirstPot}
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {pots.map(pot => {
              const progress = Math.min(100, Math.round((pot.currentAmount / pot.targetAmount) * 100));
              const isCompleted = pot.currentAmount >= pot.targetAmount;

              return (
                <div
                  key={pot.id}
                  className={`group relative flex flex-col justify-between rounded-2xl border p-4 shadow-xs transition-all ${
                    isCompleted
                      ? 'border-emerald-300 bg-emerald-50/40 ring-1 ring-emerald-500/20'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-xl shadow-xs">
                          {pot.icon}
                        </span>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">
                            {pot.name}
                          </h4>
                          <span className="text-[10px] text-slate-500">
                            {pot.category}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => deletePot(pot.id)}
                        className="rounded-lg p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                        title="Remove pot"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <div className="mt-4">
                      <div className="flex items-baseline justify-between text-xs">
                        <span className="font-mono text-base font-bold text-slate-900">
                          {formatZAR(pot.currentAmount)}
                        </span>
                        <span className="font-mono text-slate-500">
                          Goal: {formatZAR(pot.targetAmount)}
                        </span>
                      </div>

                      <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isCompleted ? 'bg-emerald-600' : 'bg-emerald-500'
                          }`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>

                      <div className="mt-1 flex items-center justify-between text-[10px] font-semibold text-slate-500">
                        <span>{progress}% saved</span>
                        {isCompleted && (
                          <span className="text-emerald-700 font-bold">
                            ✓ Goal reached!
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex gap-2 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => onSelectPotForAction(pot, 'deposit')}
                      className="flex-1 rounded-xl bg-emerald-700 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 transition-colors"
                    >
                      + Add Money
                    </button>
                    <button
                      onClick={() => onSelectPotForAction(pot, 'withdraw')}
                      disabled={pot.currentAmount <= 0}
                      className="flex-1 rounded-xl border border-slate-200 bg-slate-50 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40 transition-colors"
                    >
                      Take Out
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
