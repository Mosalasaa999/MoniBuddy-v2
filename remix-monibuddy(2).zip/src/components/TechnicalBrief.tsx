import React from 'react';
import {
  HardDrive,
  Radio,
  Phone,
  ShieldCheck,
  DollarSign,
  Lock,
  Target
} from 'lucide-react';

export const TechnicalBrief: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            How MoniBuddy Works Behind The Scenes
          </h2>
          <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-700">
            Plain Language
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-0.5">
          Engineered specifically for South African conditions: low data, weak network signals, and basic button phones.
        </p>
      </div>

      {/* 4 Plain Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pillar 1 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800">
              <HardDrive className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase text-emerald-700">Feature 1</span>
              <h3 className="text-sm font-bold text-slate-900">Works 100% Without Data</h3>
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-600 leading-relaxed">
            All your records, grocery pots, and emergency funds are saved directly inside your phone. You never need an active data bundle just to open the app and log what you spent.
          </p>
        </div>

        {/* Pillar 2 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-800">
              <Radio className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase text-amber-700">Feature 2</span>
              <h3 className="text-sm font-bold text-slate-900">Works on Slow 2G Signal</h3>
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-600 leading-relaxed">
            In areas where internet drops to slow 2G EDGE or 1 bar of signal, MoniBuddy compresses information into tiny packets that update in less than a second without draining airtime.
          </p>
        </div>

        {/* Pillar 3 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-100 text-teal-800">
              <Phone className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase text-teal-700">Feature 3</span>
              <h3 className="text-sm font-bold text-slate-900">Free Button Phone Dialing (*120*6664#)</h3>
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-600 leading-relaxed">
            Users with basic Nokia or feature phones can dial our free USSD shortcode. It does not cost any airtime and lets you check your safe balance in seconds.
          </p>
        </div>

        {/* Pillar 4 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-800">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase text-rose-700">Feature 4</span>
              <h3 className="text-sm font-bold text-slate-900">Private Scam Checker</h3>
            </div>
          </div>
          <p className="mt-3 text-xs text-slate-600 leading-relaxed">
            The scam detector runs entirely on your phone. Your private WhatsApp and SMS messages are never uploaded to any remote server or company.
          </p>
        </div>
      </div>

      {/* Sustainable Community Commitment */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-7 shadow-xs">
        <h3 className="text-sm sm:text-base font-bold text-slate-900">
          Our Promise to Township &amp; Rural Communities
        </h3>
        <p className="text-xs text-slate-500 mt-1">
          How MoniBuddy stays free and protects your dignity
        </p>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1.5 rounded-xl bg-slate-50 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <DollarSign className="h-4 w-4 text-emerald-700" />
              <span>Always Free Core Tools</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              We partner with community NGOs, social development funds, and educational grants so individual families never pay subscription fees.
            </p>
          </div>

          <div className="space-y-1.5 rounded-xl bg-slate-50 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <Lock className="h-4 w-4 text-blue-700" />
              <span>Zero Selling of Data</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              We never sell your financial records, show you popup ads, or let loan companies target you with predatory offers.
            </p>
          </div>

          <div className="space-y-1.5 rounded-xl bg-slate-50 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <Target className="h-4 w-4 text-teal-700" />
              <span>Community Grounded</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Tested directly with spaza shop owners, stokvel groups, and township households to keep everything simple and practical.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
