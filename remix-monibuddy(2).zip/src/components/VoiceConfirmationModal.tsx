import React, { useState } from 'react';
import {
  ShieldAlert,
  Volume2,
  VolumeX,
  X,
  Ban,
  CheckCircle2
} from 'lucide-react';
import {
  ScamDeductionResult,
  SupportedWarningLanguage
} from '../scamDeductionEngine';
import { useApp } from '../context/AppContext';

interface VoiceConfirmationModalProps {
  isOpen: boolean;
  deduction: ScamDeductionResult | null;
  initialLanguage?: SupportedWarningLanguage;
  onCancelAndBlock: () => void;
  onAcknowledgeProceed: () => void;
  onClose: () => void;
}

export const VoiceConfirmationModal: React.FC<VoiceConfirmationModalProps> = ({
  isOpen,
  deduction,
  initialLanguage = 'en',
  onCancelAndBlock,
  onAcknowledgeProceed,
  onClose
}) => {
  const { speakText, stopSpeaking, isSpeaking } = useApp();
  const [selectedLang, setSelectedLang] =
    useState<SupportedWarningLanguage>(initialLanguage);
  const [confirmedUnderstand, setConfirmedUnderstand] =
    useState<boolean>(false);

  if (!isOpen || !deduction) return null;

  const activeScript = deduction.audioWarningScripts[selectedLang];
  const activeTitle = deduction.template.title[selectedLang];
  const activeActions = deduction.template.recommendedActions[selectedLang];

  const handleToggleSpeech = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speakText(activeScript);
    }
  };

  const handleBlockClick = () => {
    stopSpeaking();
    setConfirmedUnderstand(false);
    onCancelAndBlock();
  };

  const handleProceedClick = () => {
    if (!confirmedUnderstand) return;
    stopSpeaking();
    setConfirmedUnderstand(false);
    onAcknowledgeProceed();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in-50">
      <div className="w-full max-w-xl rounded-2xl border border-rose-300 bg-white p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-100 text-rose-700">
              <ShieldAlert className="h-6 w-6" />
            </div>
            <div>
              <div className="text-xs font-mono font-bold text-rose-700 tabular-nums">
                HIGH-RISK INTERCEPT · SCORE {deduction.evaluation.riskScore.toFixed(2)} (
                {Math.round(deduction.evaluation.riskScore * 100)}%)
              </div>
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900 mt-0.5">
                {activeTitle}
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Language Segmented Selector + Spoken Audio Playback */}
        <div className="rounded-xl border border-rose-200 bg-rose-50/70 p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold text-rose-950">
              Listen to Voice Warning Before Acting:
            </span>
            <div className="flex items-center gap-1 rounded-lg bg-white/90 p-0.5 border border-rose-200">
              {(
                [
                  { code: 'en', label: 'English' },
                  { code: 'zu', label: 'isiZulu' },
                  { code: 'nso', label: 'Sepedi' }
                ] as const
              ).map(lang => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => {
                    stopSpeaking();
                    setSelectedLang(lang.code);
                  }}
                  className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    selectedLang === lang.code
                      ? 'bg-rose-700 text-white'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          <p className="text-xs sm:text-sm font-medium text-slate-900 leading-relaxed">
            &ldquo;{activeScript}&rdquo;
          </p>

          <button
            type="button"
            onClick={handleToggleSpeech}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 py-2.5 text-xs font-bold text-white hover:bg-slate-800 transition-colors"
          >
            {isSpeaking ? (
              <>
                <VolumeX className="h-4 w-4 text-rose-400" />
                <span>Stop Spoken Warning</span>
              </>
            ) : (
              <>
                <Volume2 className="h-4 w-4 text-emerald-400" />
                <span>Play Spoken Warning ({selectedLang.toUpperCase()})</span>
              </>
            )}
          </button>
        </div>

        {/* Key Protective Steps */}
        <div className="space-y-1.5">
          <div className="text-xs font-bold text-slate-800">
            Mandatory Safety Checks:
          </div>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-700">
            {activeActions.map((step, i) => (
              <li key={i}>{step}</li>
            ))}
          </ul>
        </div>

        {/* Mandatory Cooling-Off Acknowledgement Checkbox */}
        <label className="flex items-start gap-2.5 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={confirmedUnderstand}
            onChange={e => setConfirmedUnderstand(e.target.checked)}
            className="mt-0.5 rounded border-slate-300 text-rose-700 focus:ring-rose-600"
          />
          <span>
            I have verified this request directly via an official phone call and understand that once cash or a voucher is sent, it cannot be reversed.
          </span>
        </label>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={handleBlockClick}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-800 transition-colors whitespace-nowrap"
          >
            <Ban className="h-4 w-4" />
            <span>Cancel &amp; Block Transfer (Recommended)</span>
          </button>

          <button
            type="button"
            disabled={!confirmedUnderstand}
            onClick={handleProceedClick}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
          >
            <CheckCircle2 className="h-4 w-4 text-slate-500" />
            <span>I Verified Directly — Proceed</span>
          </button>
        </div>
      </div>
    </div>
  );
};
