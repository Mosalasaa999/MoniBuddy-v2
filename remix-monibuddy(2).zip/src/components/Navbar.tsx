import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Language } from '../types';
import {
  Volume2,
  Globe,
  Wifi,
  WifiOff,
  Radio,
  ChevronDown,
  Check,
  LogOut,
  Mic
} from 'lucide-react';

interface NavbarProps {
  onOpenAudioGuideModal: () => void;
  onOpenVoiceModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAudioGuideModal,
  onOpenVoiceModal
}) => {
  const {
    currentUser,
    logout,
    language,
    setLanguage,
    networkMode,
    setNetworkMode,
    isSpeaking,
    stopSpeaking,
    t
  } = useApp();

  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [networkDropdownOpen, setNetworkDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const languages: { code: Language; label: string; shortCode: string }[] = [
    { code: 'en', label: 'English', shortCode: 'EN' },
    { code: 'zu', label: 'isiZulu', shortCode: 'ZU' },
    { code: 'xh', label: 'isiXhosa', shortCode: 'XH' },
    { code: 'st', label: 'Sesotho', shortCode: 'ST' },
    { code: 'af', label: 'Afrikaans', shortCode: 'AF' }
  ];

  const currentLangItem =
    languages.find(l => l.code === language) || languages[0];

  return (
    <header className="shrink-0 z-30 w-full border-b border-slate-200 bg-white/95 px-3 py-1.5 backdrop-blur-md sm:px-6 sm:py-2">
      {/* Primary Responsive Row: Brand Left + Cohesive Utility Actions Right */}
      <div className="flex flex-wrap items-center justify-between gap-2 w-full">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-2.5 min-w-0 shrink-0">
          <div className="flex h-9 w-9 sm:h-10 sm:w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 shadow-xs text-white font-extrabold text-lg sm:text-xl">
            m
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap leading-tight">
                monibuddy
              </span>
              <span className="hidden md:inline-block text-[11px] font-medium text-slate-400 whitespace-nowrap">
                · Free &amp; Offline
              </span>
            </div>
            {/* Desktop / Tablet Subtitle (Single-line truncated) */}
            <p className="hidden sm:block text-xs text-slate-500 font-medium truncate max-w-xs lg:max-w-md">
              {t.tagline}
            </p>
          </div>
        </div>

        {/* Right: Cohesive Audio Cluster + Essential Utility Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 ml-auto">
          {/* Cohesive Audio Action Cluster (Mic + Listen) */}
          <div
            role="group"
            aria-label="Voice and audio controls"
            className="flex items-center rounded-2xl border border-slate-200 bg-slate-50 p-0.5 shadow-2xs"
          >
            {/* Voice Capture Trigger (>= 48x48px touch target on mobile) */}
            <button
              type="button"
              onClick={onOpenVoiceModal}
              aria-label="Log income or expense by voice"
              title="Log income or expense by voice"
              className="flex min-h-[48px] min-w-[48px] sm:min-h-[38px] sm:min-w-0 items-center justify-center gap-1.5 rounded-xl bg-emerald-700 px-2.5 sm:px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 active:scale-[0.98] transition-all whitespace-nowrap shrink-0"
            >
              <Mic className="h-4 w-4 shrink-0" />
              <span className="hidden lg:inline">Voice Log</span>
            </button>

            {/* Audio Guide Spoken Help (>= 48x48px touch target on mobile) */}
            <button
              type="button"
              onClick={() => {
                if (isSpeaking) {
                  stopSpeaking();
                } else {
                  onOpenAudioGuideModal();
                }
              }}
              aria-label="Listen to this page read aloud"
              title="Listen to this page read aloud"
              className={`flex min-h-[48px] min-w-[48px] sm:min-h-[38px] sm:min-w-0 items-center justify-center gap-1.5 rounded-xl px-2.5 sm:px-3 py-1.5 text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
                isSpeaking
                  ? 'bg-emerald-100 text-emerald-900 ring-1 ring-emerald-500/30'
                  : 'text-slate-700 hover:bg-white hover:text-emerald-800'
              }`}
            >
              <Volume2
                className={`h-4 w-4 shrink-0 ${
                  isSpeaking ? 'text-emerald-700 animate-bounce' : 'text-slate-600'
                }`}
              />
              <span className="hidden min-[420px]:inline">
                {isSpeaking ? t.audioGuideActive : t.audioGuide}
              </span>
            </button>
          </div>

          {/* Language Selector (>= 48x48px touch target on mobile, never clips right edge) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              aria-label={`Language: ${currentLangItem.label}`}
              title="Choose your language"
              className="flex min-h-[48px] min-w-[48px] sm:min-h-[38px] sm:min-w-0 items-center justify-center gap-1 sm:gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 sm:px-3 py-1.5 text-xs font-bold text-slate-700 shadow-xs hover:border-slate-300 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              <Globe className="h-4 w-4 sm:h-3.5 sm:w-3.5 text-emerald-600 shrink-0" />
              <span className="sm:hidden font-mono">{currentLangItem.shortCode}</span>
              <span className="hidden sm:inline">{currentLangItem.label}</span>
              <ChevronDown className="h-3 w-3 text-slate-400 shrink-0" />
            </button>

            {langDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setLangDropdownOpen(false)}
                />
                <div className="absolute right-0 z-50 mt-1.5 w-44 rounded-xl border border-slate-200 bg-white py-1.5 shadow-lg ring-1 ring-black/5 animate-in fade-in-50 zoom-in-95">
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Select Language
                  </div>
                  {languages.map(item => (
                    <button
                      key={item.code}
                      type="button"
                      onClick={() => {
                        setLanguage(item.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`flex w-full min-h-[40px] items-center justify-between px-3 py-2 text-xs font-medium transition-colors ${
                        language === item.code
                          ? 'bg-emerald-50 text-emerald-900 font-bold'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span>{item.label}</span>
                      {language === item.code && (
                        <Check className="h-3.5 w-3.5 text-emerald-600" />
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Connection Signal Selector (Desktop & Tablet >= md; moved to secondary strip on mobile to prevent cramming) */}
          <div className="relative hidden md:block">
            <button
              type="button"
              onClick={() => setNetworkDropdownOpen(!networkDropdownOpen)}
              title="Connection signal mode"
              className={`flex min-h-[38px] items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-bold shadow-xs transition-colors whitespace-nowrap shrink-0 ${
                networkMode === '2g'
                  ? 'border-amber-300 bg-amber-50 text-amber-900'
                  : networkMode === 'offline'
                  ? 'border-rose-300 bg-rose-50 text-rose-900'
                  : 'border-emerald-200 bg-emerald-50 text-emerald-900'
              }`}
            >
              {networkMode === '2g' && (
                <Radio className="h-3.5 w-3.5 text-amber-600 shrink-0" />
              )}
              {networkMode === 'offline' && (
                <WifiOff className="h-3.5 w-3.5 text-rose-600 shrink-0" />
              )}
              {networkMode === '4g' && (
                <Wifi className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
              )}

              <span className="hidden lg:inline">
                {networkMode === '2g'
                  ? 'Signal: Weak 2G'
                  : networkMode === 'offline'
                  ? 'No Internet (Offline)'
                  : 'Signal: Good'}
              </span>
              <span className="lg:hidden">
                {networkMode === '2g'
                  ? '2G'
                  : networkMode === 'offline'
                  ? 'Offline'
                  : 'Online'}
              </span>
              <ChevronDown className="h-3 w-3 opacity-60 shrink-0" />
            </button>

            {networkDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setNetworkDropdownOpen(false)}
                />
                <div className="absolute right-0 z-50 mt-1.5 w-56 rounded-xl border border-slate-200 bg-white p-2 shadow-lg ring-1 ring-black/5 animate-in fade-in-50 zoom-in-95">
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Simulate Phone Signal
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setNetworkMode('4g');
                      setNetworkDropdownOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-lg p-2 text-left transition-colors ${
                      networkMode === '4g'
                        ? 'bg-emerald-50 text-emerald-900 font-bold'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Wifi className="h-4 w-4 text-emerald-600 shrink-0" />
                    <div>
                      <div className="text-xs">Normal Internet</div>
                      <div className="text-[11px] text-slate-500 font-normal">
                        When you have normal data/Wi-Fi
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNetworkMode('2g');
                      setNetworkDropdownOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-lg p-2 text-left transition-colors mt-1 ${
                      networkMode === '2g'
                        ? 'bg-amber-50 text-amber-900 font-bold'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Radio className="h-4 w-4 text-amber-600 shrink-0" />
                    <div>
                      <div className="text-xs">Weak 2G Signal</div>
                      <div className="text-[11px] text-slate-500 font-normal">
                        Slow network or low airtime
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNetworkMode('offline');
                      setNetworkDropdownOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-lg p-2 text-left transition-colors mt-1 ${
                      networkMode === 'offline'
                        ? 'bg-rose-50 text-rose-900 font-bold'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <WifiOff className="h-4 w-4 text-rose-600 shrink-0" />
                    <div>
                      <div className="text-xs">No Internet (Airplane Mode)</div>
                      <div className="text-[11px] text-slate-500 font-normal">
                        Saves everything on your phone
                      </div>
                    </div>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* User Profile & Logout Button (Desktop & wider mobile >= 400px; also accessible in mobile drawer) */}
          {currentUser && (
            <div className="relative hidden min-[400px]:block">
              <button
                type="button"
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                aria-label="Account and security"
                title="Account & Security"
                className="flex min-h-[48px] min-w-[48px] sm:min-h-[38px] sm:min-w-0 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 shadow-xs hover:border-emerald-300 hover:bg-slate-50 transition-colors shrink-0"
              >
                <div className="flex h-6 w-6 sm:h-5 sm:w-5 items-center justify-center rounded-full bg-emerald-700 text-white text-[11px] sm:text-[10px] font-extrabold uppercase shrink-0">
                  {currentUser.name.charAt(0)}
                </div>
                <span className="hidden lg:inline max-w-[90px] truncate">
                  {currentUser.name.split(' ')[0]}
                </span>
                <ChevronDown className="hidden sm:inline h-3 w-3 text-slate-400 shrink-0" />
              </button>

              {userDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setUserDropdownOpen(false)}
                  />
                  <div className="absolute right-0 z-50 mt-1.5 w-56 rounded-2xl border border-slate-200 bg-white p-3 shadow-xl ring-1 ring-black/5 animate-in fade-in-50 zoom-in-95">
                    <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                      <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800 text-xs font-extrabold uppercase">
                        {currentUser.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900 truncate">
                          {currentUser.name}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {currentUser.phone}
                        </div>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setUserDropdownOpen(false);
                          logout();
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50 transition-colors"
                      >
                        <LogOut className="h-4 w-4 text-rose-600" />
                        <span>Lock Ledger &amp; Sign Out</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Optional Bottom Subtitle Row: Hidden on narrow phones (< 380px), single-line truncated between 380px and sm */}
      <p className="hidden min-[380px]:block sm:hidden mt-1 text-[11px] text-slate-500 font-medium truncate">
        {t.tagline}
      </p>
    </header>
  );
};
