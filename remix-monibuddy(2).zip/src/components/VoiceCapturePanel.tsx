import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Check, RotateCcw, AlertCircle, BookOpen, ChevronDown, ChevronUp } from 'lucide-react';
import { recognizeSpeech, VoiceRecognitionLanguage } from '../VoiceRecorder';
import {
  PHONETIC_ALIAS_MATRIX,
  ParsedVoiceEntry,
  parseVernacularTransaction
} from '../SlangDictionary';
import { useApp } from '../context/AppContext';

interface VoiceCapturePanelProps {
  selectedDate: string;
  onPopulateManualForm?: (entry: ParsedVoiceEntry) => void;
}

const LANGUAGE_OPTIONS: { code: VoiceRecognitionLanguage; label: string }[] = [
  { code: 'en-ZA', label: 'English (SA)' },
  { code: 'zu-ZA', label: 'isiZulu' },
  { code: 'nso-ZA', label: 'Sepedi' }
];

const SAMPLE_PHRASES = [
  'Two choco for taxi and one clipa for airtime',
  'Spaza sales R350 and three tiger for taxi',
  'Wages one grand and two choco for data',
  'Four tiger for transport'
];

export const VoiceCapturePanel: React.FC<VoiceCapturePanelProps> = ({
  selectedDate,
  onPopulateManualForm
}) => {
  const { addTransaction, language } = useApp();

  const [voiceLang, setVoiceLang] = useState<VoiceRecognitionLanguage>(
    language === 'zu' ? 'zu-ZA' : 'en-ZA'
  );
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [parsedEntries, setParsedEntries] = useState<ParsedVoiceEntry[]>([]);
  const [detectedSlang, setDetectedSlang] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [showSlangGuide, setShowSlangGuide] = useState<boolean>(false);

  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (language === 'zu') {
      setVoiceLang('zu-ZA');
    } else if (language === 'en') {
      setVoiceLang('en-ZA');
    }
  }, [language]);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const applyTranscript = (rawText: string) => {
    setTranscript(rawText);
    setErrorMessage(null);
    setSavedNotice(null);

    if (!rawText.trim()) {
      setParsedEntries([]);
      setDetectedSlang([]);
      return;
    }

    const result = parseVernacularTransaction(rawText);
    setParsedEntries(result.entries);
    setDetectedSlang(result.slangTags);

    if (result.entries.length === 0) {
      setErrorMessage(
        'No amount or vernacular term was recognized in that phrase. Try mentioning an amount like "two choco for taxi" or "R50 airtime".'
      );
    }
  };

  const handleStartRecording = async () => {
    setErrorMessage(null);
    setSavedNotice(null);

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    setIsRecording(true);

    try {
      const spokenText = await recognizeSpeech(voiceLang, controller.signal);
      setIsRecording(false);
      applyTranscript(spokenText);
    } catch (err) {
      setIsRecording(false);
      if (err instanceof DOMException && err.name === 'AbortError') {
        return;
      }
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Unable to capture voice right now. Please try again or type what you said below.'
      );
    }
  };

  const handleStopRecording = () => {
    abortControllerRef.current?.abort();
    setIsRecording(false);
  };

  const handleUpdateEntry = (
    index: number,
    patch: Partial<ParsedVoiceEntry>
  ) => {
    setParsedEntries(prev =>
      prev.map((entry, idx) => (idx === index ? { ...entry, ...patch } : entry))
    );
  };

  const handleRemoveEntry = (index: number) => {
    setParsedEntries(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleSaveParsedEntries = () => {
    const validEntries = parsedEntries.filter(
      item => item.title.trim().length > 0 && Number.isFinite(item.amount) && item.amount > 0
    );
    if (validEntries.length === 0) return;

    for (const entry of validEntries) {
      addTransaction({
        type: entry.type,
        title: entry.title.trim(),
        amount: entry.amount,
        category: entry.category,
        date: selectedDate,
        tags: entry.tags.length > 0 ? entry.tags : undefined,
        transcript: transcript.trim() || undefined
      });
    }

    const count = validEntries.length;
    setSavedNotice(
      `Saved ${count} voice ${count === 1 ? 'entry' : 'entries'} to your ledger.`
    );
    setTranscript('');
    setParsedEntries([]);
    setDetectedSlang([]);
  };

  const handleClear = () => {
    abortControllerRef.current?.abort();
    setIsRecording(false);
    setTranscript('');
    setParsedEntries([]);
    setDetectedSlang([]);
    setErrorMessage(null);
    setSavedNotice(null);
  };

  const formatZAR = (num: number) => {
    return (
      'R ' +
      num.toLocaleString('en-ZA', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    );
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
      {/* Header & Language Control */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            Voice Capture &amp; Vernacular Slang Parser
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Speak naturally in SA English, isiZulu, or Sepedi — understands tiger (R10), choco (R20), clipa (R100), and grand (R1 000)
          </p>
        </div>

        {/* Segmented Language Control */}
        <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1 self-start sm:self-auto">
          {LANGUAGE_OPTIONS.map(opt => (
            <button
              key={opt.code}
              type="button"
              disabled={isRecording}
              onClick={() => setVoiceLang(opt.code)}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                voiceLang === opt.code
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              } disabled:opacity-50`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Capture Row */}
      <div className="mt-4 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left: Mic Action & Transcript Box */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex flex-wrap items-center gap-2.5">
            {!isRecording ? (
              <button
                type="button"
                onClick={handleStartRecording}
                className="flex items-center gap-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 transition-colors whitespace-nowrap shrink-0"
              >
                <Mic className="h-4 w-4" />
                <span>Speak Transaction</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStopRecording}
                className="flex items-center gap-2 rounded-xl bg-rose-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-rose-800 transition-colors whitespace-nowrap shrink-0"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>Stop Listening...</span>
              </button>
            )}

            {(transcript || parsedEntries.length > 0 || errorMessage) && (
              <button
                type="button"
                onClick={handleClear}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Clear</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowSlangGuide(prev => !prev)}
              className="ml-auto flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 whitespace-nowrap shrink-0"
            >
              <BookOpen className="h-3.5 w-3.5" />
              <span>{showSlangGuide ? 'Hide slang dictionary' : 'Slang dictionary'}</span>
              {showSlangGuide ? (
                <ChevronUp className="h-3.5 w-3.5" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5" />
              )}
            </button>
          </div>

          {/* Live / Editable Transcript Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700">
              Spoken phrase (or type to test offline slang parser)
            </label>
            <div className="mt-1 flex gap-2">
              <input
                type="text"
                value={transcript}
                onChange={e => applyTranscript(e.target.value)}
                placeholder='e.g. "Two choco for taxi and one clipa for airtime"'
                className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden focus:ring-2 focus:ring-emerald-600/20"
              />
            </div>
          </div>

          {/* Quick Test Phrases */}
          <div>
            <span className="text-[11px] font-semibold text-slate-500">
              Try sample voice phrases:
            </span>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {SAMPLE_PHRASES.map(phrase => (
                <button
                  key={phrase}
                  type="button"
                  onClick={() => applyTranscript(phrase)}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-900 transition-colors text-left"
                >
                  &ldquo;{phrase}&rdquo;
                </button>
              ))}
            </div>
          </div>

          {/* Collapsible Slang Reference Table */}
          {showSlangGuide && (
            <div className="pt-3 border-t border-slate-100">
              <div className="text-xs font-bold text-slate-800 mb-2">
                Supported Township &amp; Vernacular Slang Matrix
              </div>
              <div className="divide-y divide-slate-100 text-xs">
                {PHONETIC_ALIAS_MATRIX.map(group => (
                  <div
                    key={group.term}
                    className="py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-1"
                  >
                    <div>
                      <span className="font-bold text-slate-900 capitalize">
                        {group.term}
                      </span>
                      <span className="text-slate-400 mx-1.5">·</span>
                      <span className="text-slate-500">
                        {group.aliases.slice(0, 5).join(', ')}
                      </span>
                    </div>
                    <div className="font-mono font-semibold text-slate-700 tabular-nums shrink-0">
                      {group.amount !== undefined
                        ? formatZAR(group.amount)
                        : group.category}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Error or Confirmation Messages */}
          {errorMessage && (
            <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50/70 p-3 text-xs text-rose-800">
              <AlertCircle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {savedNotice && (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 p-3 text-xs font-semibold text-emerald-900">
              <Check className="h-4 w-4 text-emerald-700 shrink-0" />
              <span>{savedNotice}</span>
            </div>
          )}
        </div>

        {/* Right: Parsed Entries Preview & Confirm */}
        <div className="lg:col-span-5 lg:border-l lg:border-slate-100 lg:pl-5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900">
              Parsed Ledger Entries ({parsedEntries.length})
            </h4>
            {detectedSlang.length > 0 && (
              <span className="text-[11px] text-slate-500">
                Slang: {detectedSlang.join(' · ')}
              </span>
            )}
          </div>

          {parsedEntries.length === 0 ? (
            <div className="mt-3 py-6 text-center border border-dashed border-slate-200 rounded-xl px-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Tap <strong>Speak Transaction</strong> or pick a sample phrase to preview how MoniBuddy converts spoken slang into Rand amounts.
              </p>
            </div>
          ) : (
            <div className="mt-3 space-y-3">
              <div className="divide-y divide-slate-100">
                {parsedEntries.map((entry, idx) => (
                  <div key={`${entry.title}-${idx}`} className="py-2.5 first:pt-0 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <input
                        type="text"
                        value={entry.title}
                        onChange={e =>
                          handleUpdateEntry(idx, { title: e.target.value })
                        }
                        className="flex-1 rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-semibold text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          handleUpdateEntry(idx, {
                            type: entry.type === 'expense' ? 'income' : 'expense'
                          })
                        }
                        className={`rounded-lg px-2 py-1 text-[11px] font-bold transition-colors whitespace-nowrap shrink-0 ${
                          entry.type === 'income'
                            ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                            : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
                        }`}
                      >
                        {entry.type === 'income' ? '+ Money In' : '- Money Out'}
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="text-[11px] text-slate-500 truncate">
                        {entry.category}
                        {entry.tags.length > 0 && ` · ${entry.tags.join(', ')}`}
                      </span>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="relative w-28">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-2 text-xs font-bold text-slate-400">
                            R
                          </span>
                          <input
                            type="number"
                            step="any"
                            min="1"
                            value={entry.amount}
                            onChange={e =>
                              handleUpdateEntry(idx, {
                                amount: Number(e.target.value)
                              })
                            }
                            className="w-full rounded-lg border border-slate-200 pl-6 pr-2 py-1 text-xs font-mono font-bold text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-hidden"
                          />
                        </div>

                        {onPopulateManualForm && parsedEntries.length === 1 && (
                          <button
                            type="button"
                            onClick={() => onPopulateManualForm(entry)}
                            className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 whitespace-nowrap"
                          >
                            Edit in form
                          </button>
                        )}

                        {parsedEntries.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveEntry(idx)}
                            className="text-[11px] font-semibold text-slate-400 hover:text-rose-600 whitespace-nowrap"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={handleSaveParsedEntries}
                className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-emerald-700 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 transition-colors"
              >
                <Check className="h-4 w-4" />
                <span>
                  Save {parsedEntries.length}{' '}
                  {parsedEntries.length === 1 ? 'Entry' : 'Entries'} to Ledger
                </span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
