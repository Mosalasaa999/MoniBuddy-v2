import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight
} from 'lucide-react';

interface BufferCreditProps {
  onOpenBufferModal: () => void;
}

export const BufferCredit: React.FC<BufferCreditProps> = ({ onOpenBufferModal }) => {
  const {
    emergencyBuffer,
    addToBuffer,
    burnRate,
    setBurnRate,
    weeksBufferCovers
  } = useApp();

  const [loanAmount, setLoanAmount] = useState<number>(1000);

  const formatZAR = (num: number) => {
    return 'R ' + num.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  // Typical township loan shark (mashonisa): 40% per month over 3 months + penalty
  const mashonisaInterest = loanAmount * 0.40 * 3;
  const mashonisaPenalty = Math.round(loanAmount * 0.544);
  const totalMashonisaRepayment = loanAmount + mashonisaInterest + mashonisaPenalty;
  const moneySaved = totalMashonisaRepayment - loanAmount;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Emergency Fund &amp; Loan Shield
          </h2>
          <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-800 ring-1 ring-emerald-600/20">
            Stay Debt-Free
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-0.5">
          Protect yourself and your family from expensive informal loans with your own emergency cushion.
        </p>
      </div>

      {/* CURRENT EMERGENCY FUND */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-7 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              YOUR EMERGENCY SAVINGS
            </span>
            <div className="mt-1 font-mono text-4xl sm:text-5xl font-extrabold text-slate-900">
              {formatZAR(emergencyBuffer)}
            </div>
            <p className="mt-1 text-xs text-slate-600">
              {weeksBufferCovers > 0 ? (
                <span>
                  Covers about <strong className="text-emerald-700">{weeksBufferCovers} weeks</strong> of essential groceries &amp; transport at your {formatZAR(burnRate)}/week budget.
                </span>
              ) : (
                'You have not added to your emergency fund yet. Even R50 gives you peace of mind.'
              )}
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-2">
            <button
              onClick={() => addToBuffer(100, 'Saved R100 for emergencies')}
              className="rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-bold text-emerald-800 hover:bg-emerald-100 transition-colors shadow-2xs"
            >
              + Deposit R100
            </button>
            <button
              onClick={() => addToBuffer(250, 'Saved R250 for emergencies')}
              className="rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-bold text-emerald-800 hover:bg-emerald-100 transition-colors shadow-2xs"
            >
              + Deposit R250
            </button>
            <button
              onClick={onOpenBufferModal}
              className="rounded-xl bg-emerald-700 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-800 transition-colors shadow-2xs"
            >
              Custom Amount
            </button>
          </div>
        </div>

        {/* Weekly Living Costs Slider */}
        <div className="mt-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                How much does your home need each week?
              </h4>
              <p className="text-xs text-slate-500">
                Minimum weekly spending for food, taxi fare, and basic electricity
              </p>
            </div>
            <div className="font-mono text-base sm:text-lg font-bold text-slate-900">
              {formatZAR(burnRate)} / week
            </div>
          </div>

          <div className="flex items-center gap-4">
            <input
              type="range"
              min="100"
              max="1500"
              step="25"
              value={burnRate}
              onChange={e => setBurnRate(Number(e.target.value))}
              className="h-2 w-full cursor-pointer appearance-none rounded-lg bg-slate-200 accent-emerald-600"
            />
          </div>

          <div className="flex gap-2">
            {[250, 500, 750, 1000].map(val => (
              <button
                key={val}
                onClick={() => setBurnRate(val)}
                className={`rounded-lg px-2.5 py-1 text-xs font-mono font-medium transition-colors ${
                  burnRate === val
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                R {val}
              </button>
            ))}
          </div>

          {/* Simple Shock Explanation */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="rounded-xl bg-slate-50 p-3.5 border border-slate-100">
              <span className="text-[11px] font-bold text-slate-500 uppercase">
                If Work Stops for 2 Weeks:
              </span>
              <p className="mt-1 text-xs text-slate-700 leading-relaxed">
                You will need <strong className="text-emerald-800 font-mono">{formatZAR(burnRate * 2)}</strong> to get through without taking a loan.
              </p>
            </div>

            <div className="rounded-xl bg-slate-50 p-3.5 border border-slate-100">
              <span className="text-[11px] font-bold text-slate-500 uppercase">
                If Work Stops for 1 Month:
              </span>
              <p className="mt-1 text-xs text-slate-700 leading-relaxed">
                You will need <strong className="text-emerald-800 font-mono">{formatZAR(burnRate * 4)}</strong> to feed your family without going into debt.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* LOAN SHARK VS EMERGENCY SAVINGS COMPARISON */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-7 shadow-xs">
        <div className="pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-rose-600" />
            <h3 className="text-base font-bold text-slate-900">
              Why Saving Beats Borrowing from a Mashonisa
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            Township micro-lenders (omashonisa) often charge 40% interest every month and may hold your SASSA card or ID. See how much money you save by having your own buffer.
          </p>
        </div>

        {/* Loan Amount Chooser */}
        <div className="my-5 rounded-2xl bg-slate-50 p-4 border border-slate-100">
          <div className="flex items-center justify-between gap-3">
            <div>
              <label className="text-xs font-bold text-slate-900">
                Choose an unexpected emergency amount:
              </label>
              <p className="text-[11px] text-slate-500">
                e.g. Broken phone, clinic visit, or urgent family travel
              </p>
            </div>
            <div className="font-mono text-xl font-bold text-slate-900">
              {formatZAR(loanAmount)}
            </div>
          </div>

          <div className="mt-3">
            <input
              type="range"
              min="500"
              max="3000"
              step="100"
              value={loanAmount}
              onChange={e => setLoanAmount(Number(e.target.value))}
              className="h-2 w-full cursor-pointer appearance-none rounded-lg bg-slate-200 accent-rose-600"
            />
          </div>

          <div className="mt-2 flex gap-2">
            {[500, 1000, 1500, 2000].map(amt => (
              <button
                key={amt}
                onClick={() => setLoanAmount(amt)}
                className={`rounded-lg px-2 py-0.5 text-xs font-mono font-medium transition-colors ${
                  loanAmount === amt ? 'bg-rose-100 text-rose-900 font-bold' : 'bg-white border text-slate-600'
                }`}
              >
                R {amt}
              </button>
            ))}
          </div>
        </div>

        {/* Clean Side-by-Side Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          {/* Mashonisa Card */}
          <div className="rounded-2xl border-2 border-rose-200 bg-rose-50/40 p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-950 uppercase">
                Informal Loan (Mashonisa)
              </span>
              <span className="rounded-full bg-rose-200 px-2.5 py-0.5 text-[10px] font-bold text-rose-900">
                High Risk
              </span>
            </div>

            <div className="mt-4 space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-rose-100">
                <span className="text-slate-600">Amount you get:</span>
                <span className="font-mono font-bold text-slate-900">{formatZAR(loanAmount)}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-rose-100">
                <span className="text-slate-600">Interest after 3 months (40%/mo):</span>
                <span className="font-mono font-bold text-rose-700">+{formatZAR(mashonisaInterest)}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-rose-100">
                <span className="text-slate-600">Late admin fees:</span>
                <span className="font-mono font-bold text-rose-700">+{formatZAR(mashonisaPenalty)}</span>
              </div>

              <div className="flex justify-between pt-2 text-sm font-bold">
                <span className="text-slate-900">Total You Pay Back:</span>
                <span className="font-mono text-base font-extrabold text-rose-700">
                  {formatZAR(totalMashonisaRepayment)}
                </span>
              </div>
            </div>

            <p className="mt-4 text-[11px] text-rose-900 leading-snug bg-rose-100/70 p-2.5 rounded-xl">
              ⚠️ You pay back nearly <strong>three times</strong> what you borrowed. If you fall behind, fees multiply fast.
            </p>
          </div>

          {/* MoniBuddy Emergency Cushion */}
          <div className="rounded-2xl border-2 border-emerald-300 bg-emerald-50/50 p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-950 uppercase">
                Your MoniBuddy Cushion
              </span>
              <span className="rounded-full bg-emerald-200 px-2.5 py-0.5 text-[10px] font-bold text-emerald-900">
                100% Free
              </span>
            </div>

            <div className="mt-4 space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Amount you get:</span>
                <span className="font-mono font-bold text-slate-900">{formatZAR(loanAmount)}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Interest &amp; fees:</span>
                <span className="font-mono font-bold text-emerald-700">R 0,00 (0%)</span>
              </div>

              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Money kept in your pocket:</span>
                <span className="font-mono font-bold text-emerald-700">+{formatZAR(moneySaved)}</span>
              </div>

              <div className="flex justify-between pt-2 text-sm font-bold">
                <span className="text-slate-900">Total Cost To You:</span>
                <span className="font-mono text-base font-extrabold text-emerald-700">
                  R 0,00
                </span>
              </div>
            </div>

            <p className="mt-4 text-[11px] text-emerald-900 leading-snug bg-emerald-100/80 p-2.5 rounded-xl">
              ✓ <strong>Zero debt trap:</strong> This is your own hard-earned money. No one can threaten you, no interest, and you keep an extra {formatZAR(moneySaved)} safe.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
