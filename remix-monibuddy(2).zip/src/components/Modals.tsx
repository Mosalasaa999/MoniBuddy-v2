import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GoalPot } from '../types';
import { X, ShieldCheck, Mic } from 'lucide-react';
import { VoiceCapturePanel } from './VoiceCapturePanel';

interface NewPotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewPotModal: React.FC<NewPotModalProps> = ({ isOpen, onClose }) => {
  const { createPot } = useApp();
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [category, setCategory] = useState('Groceries');
  const [icon, setIcon] = useState('🍚');

  const presetIcons = ['🍚', '📦', '🎒', '⚡', '🚗', '💊', '🥩', '📱', '🏠', '🎉'];
  const categories = ['Groceries', 'Business', 'School', 'Transport', 'Electricity', 'Family', 'Emergency'];

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(targetAmount);
    if (!name.trim() || isNaN(amountNum) || amountNum <= 0) return;

    createPot({
      name: name.trim(),
      icon,
      targetAmount: amountNum,
      category,
      color: 'emerald'
    });

    setName('');
    setTargetAmount('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-sm sm:text-base font-bold text-slate-900">Create a New Savings Pot</h3>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700">Choose an Icon</label>
            <div className="mt-1.5 flex flex-wrap gap-2">
              {presetIcons.map(ic => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setIcon(ic)}
                  className={`flex h-9 w-9 items-center justify-center rounded-lg text-lg transition-transform ${
                    icon === ic ? 'bg-emerald-100 ring-2 ring-emerald-600 scale-105' : 'bg-slate-100 hover:bg-slate-200'
                  }`}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700">What are you saving for?</label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Groceries, Spaza stock, School shoes"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700">Target Amount (R)</label>
              <div className="relative mt-1">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm font-bold text-slate-400">R</span>
                <input
                  type="number"
                  step="1"
                  min="1"
                  value={targetAmount}
                  onChange={e => setTargetAmount(e.target.value)}
                  placeholder="500"
                  className="w-full rounded-xl border border-slate-200 pl-8 pr-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700">Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-hidden"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-emerald-700 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-800"
            >
              Create Pot
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface PotActionModalProps {
  pot: GoalPot | null;
  mode: 'deposit' | 'withdraw';
  isOpen: boolean;
  onClose: () => void;
}

export const PotActionModal: React.FC<PotActionModalProps> = ({
  pot,
  mode,
  isOpen,
  onClose
}) => {
  const { depositToPot, withdrawFromPot } = useApp();
  const [amount, setAmount] = useState('');

  if (!isOpen || !pot) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) return;

    if (mode === 'deposit') {
      depositToPot(pot.id, val);
    } else {
      withdrawFromPot(pot.id, val);
    }
    setAmount('');
    onClose();
  };

  const presets = [20, 50, 100, 200];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{pot.icon}</span>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {mode === 'deposit' ? 'Put Money In' : 'Take Money Out'}
              </h3>
              <p className="text-xs text-slate-500">{pot.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="rounded-xl bg-slate-50 p-3 text-xs flex justify-between items-center">
            <span className="text-slate-500">Currently in this pot:</span>
            <span className="font-bold text-slate-900 font-mono text-sm">
              R {pot.currentAmount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700">Amount (R)</label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm font-bold text-slate-400">R</span>
              <input
                type="number"
                step="any"
                min="1"
                max={mode === 'withdraw' ? pot.currentAmount : undefined}
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="50.00"
                className="w-full rounded-xl border border-slate-200 pl-8 pr-3.5 py-2 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden"
                required
                autoFocus
              />
            </div>
          </div>

          <div className="flex gap-2">
            {presets.map(p => (
              <button
                key={p}
                type="button"
                onClick={() => setAmount(p.toString())}
                className="flex-1 rounded-lg border border-slate-200 bg-slate-50 py-1.5 text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-800"
              >
                +R{p}
              </button>
            ))}
          </div>

          <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`rounded-xl px-4 py-2 text-xs font-bold text-white shadow-xs ${
                mode === 'deposit' ? 'bg-emerald-700 hover:bg-emerald-800' : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              {mode === 'deposit' ? 'Save to Pot' : 'Take Out Cash'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface BufferModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BufferModal: React.FC<BufferModalProps> = ({ isOpen, onClose }) => {
  const { emergencyBuffer, addToBuffer, withdrawFromBuffer } = useApp();
  const [amount, setAmount] = useState('');
  const [mode, setMode] = useState<'deposit' | 'withdraw'>('deposit');
  const [note, setNote] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) return;

    if (mode === 'deposit') {
      addToBuffer(val, note.trim() || undefined);
    } else {
      withdrawFromBuffer(val, note.trim() || undefined);
    }
    setAmount('');
    setNote('');
    onClose();
  };

  const presets = [50, 100, 250, 500];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 text-emerald-800">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Emergency Fund</h3>
              <p className="text-xs text-slate-500">Your self-funded cushion</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-bold">
            <button
              type="button"
              onClick={() => setMode('deposit')}
              className={`flex-1 rounded-lg py-1.5 transition-all ${
                mode === 'deposit' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              + Add to Emergency Fund
            </button>
            <button
              type="button"
              onClick={() => setMode('withdraw')}
              className={`flex-1 rounded-lg py-1.5 transition-all ${
                mode === 'withdraw' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              - Use Emergency Money
            </button>
          </div>

          <div className="rounded-xl bg-emerald-50/70 p-3 text-xs flex justify-between items-center border border-emerald-100">
            <span className="text-emerald-900 font-semibold">Current Emergency Fund:</span>
            <span className="font-bold text-emerald-950 font-mono text-sm">
              R {emergencyBuffer.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700">Amount (R)</label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm font-bold text-slate-400">R</span>
              <input
                type="number"
                step="any"
                min="1"
                max={mode === 'withdraw' ? emergencyBuffer : undefined}
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="100.00"
                className="w-full rounded-xl border border-slate-200 pl-8 pr-3.5 py-2 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden"
                required
                autoFocus
              />
            </div>
          </div>

          <div className="flex gap-2">
            {presets.map(p => (
              <button
                key={p}
                type="button"
                onClick={() => setAmount(p.toString())}
                className="flex-1 rounded-lg border border-slate-200 bg-slate-50 py-1.5 text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-800"
              >
                +R{p}
              </button>
            ))}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700">Reason (Optional)</label>
            <input
              type="text"
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="e.g. Clinic visit, family emergency, rainy day"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden"
            />
          </div>

          <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`rounded-xl px-4 py-2 text-xs font-bold text-white shadow-xs ${
                mode === 'deposit' ? 'bg-emerald-700 hover:bg-emerald-800' : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              {mode === 'deposit' ? 'Save to Fund' : 'Withdraw Cash'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface VoiceCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoiceCaptureModal: React.FC<VoiceCaptureModalProps> = ({
  isOpen,
  onClose
}) => {
  if (!isOpen) return null;

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
      <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-700 text-white">
              <Mic className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                Voice Capture
              </h3>
              <p className="text-xs text-slate-500">
                Log cash in or out using natural speech and South African slang
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <VoiceCapturePanel selectedDate={today} />
      </div>
    </div>
  );
};

