import React from 'react';
import { useApp } from '../context/AppContext';
import { TabType } from '../types';
import { Volume2, Play, Square, X, Headphones } from 'lucide-react';

interface AudioGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTab: TabType;
}

export const AudioGuideModal: React.FC<AudioGuideModalProps> = ({
  isOpen,
  onClose,
  currentTab
}) => {
  const {
    speakText,
    stopSpeaking,
    isSpeaking
  } = useApp();

  const guidesByTab: Record<TabType, { title: string; content: string; keyAdvice: string }> = {
    overview: {
      title: 'Safe to Spend & Savings Pots',
      content: 'Welcome to MoniBuddy! Your Safe to Spend number at the top shows the real cash you can spend today without touching your grocery money or emergency fund. Tap New Pot to set aside money for food or school fees.',
      keyAdvice: 'Tip: Even putting R20 a week into a pot keeps your family safe from emergency debt.'
    },
    income_expenses: {
      title: 'Tracking Money In and Out',
      content: 'Here you can write down money you receive and money you spend. Even small daily things like taxi fare, bread, and airtime add up fast. You can log them quickly without using any mobile data.',
      keyAdvice: 'Tip: Tap any quick button like Taxi Fare or Bread to record a cost in two seconds.'
    },
    buffer_credit: {
      title: 'Emergency Fund & Avoiding Loan Sharks',
      content: 'Township loan sharks, or mashonisas, charge forty percent interest every single month. By saving your own small emergency fund of two to four weeks of expenses, you keep hundreds of rands in your own pocket instead of paying debt traps.',
      keyAdvice: 'Tip: Saving your own R1,000 saves you over R1,700 compared to borrowing from a mashonisa.'
    },
    scam_guard: {
      title: 'Checking Suspicious Messages',
      content: 'Paste any WhatsApp message, job offer, or SMS here to test if it is a scam. It works directly on your phone without using data. Remember: Never share your bank PIN or OTP with anyone.',
      keyAdvice: 'Tip: If anyone asks you for an upfront fee before giving you a loan or job, it is a scam.'
    },
    sync_2g: {
      title: 'Using Without Data',
      content: 'MoniBuddy works even if you have no data bundle. You can also dial star 120 star 6664 hash on any basic button phone for free to check your balance anytime without airtime.',
      keyAdvice: 'Tip: Try out the interactive button phone dialer to see how it works.'
    },
    technical_brief: {
      title: 'How It Works Behind The Scenes',
      content: 'MoniBuddy is built to work without internet bundles, works on slow 2G mobile signal, and is accessible on basic feature phones so everyone can track their money with dignity.',
      keyAdvice: 'Tip: Your information always stays private on your own device.'
    },
    privacy_legal: {
      title: 'Your Privacy Guarantee',
      content: 'Your financial information belongs only to you. MoniBuddy does not require passwords or bank logins, does not upload your numbers to the cloud, and will never sell your information.',
      keyAdvice: 'Tip: You can download or erase your numbers anytime with one click.'
    }
  };

  const currentGuide = guidesByTab[currentTab] || guidesByTab.overview;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800">
              <Headphones className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Spoken Guide</h3>
              <p className="text-xs text-slate-500">Listen to this page read aloud</p>
            </div>
          </div>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="mt-4 space-y-3">
          <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
            <div className="flex items-center justify-between pb-1.5">
              <span className="text-xs font-bold text-emerald-800">
                {currentGuide.title}
              </span>
              {isSpeaking && (
                <span className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-600">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
                  Playing audio...
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm leading-relaxed text-slate-700">
              {currentGuide.content}
            </p>
          </div>

          <div className="rounded-xl bg-emerald-50 p-3 text-xs font-semibold text-emerald-900 border border-emerald-100">
            {currentGuide.keyAdvice}
          </div>
        </div>

        {/* Action Controls */}
        <div className="mt-5 flex items-center justify-between pt-3 border-t border-slate-100">
          <div>
            {isSpeaking ? (
              <button
                onClick={stopSpeaking}
                className="flex items-center gap-1.5 rounded-xl bg-rose-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-rose-700"
              >
                <Square className="h-3.5 w-3.5" />
                <span>Stop Voice</span>
              </button>
            ) : (
              <button
                onClick={() => speakText(`${currentGuide.title}. ${currentGuide.content}. ${currentGuide.keyAdvice}`)}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-700 px-3.5 py-2 text-xs font-bold text-white hover:bg-emerald-800"
              >
                <Play className="h-3.5 w-3.5 fill-white" />
                <span>Play Voice</span>
              </button>
            )}
          </div>

          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="rounded-xl border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
