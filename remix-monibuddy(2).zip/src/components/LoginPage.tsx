import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Lock,
  Phone,
  User as UserIcon,
  Eye,
  EyeOff,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Globe,
  Volume2,
  Check,
  KeyRound,
  AlertCircle
} from 'lucide-react';
import { Language } from '../types';

interface LoginPageProps {
  onOpenAudioGuideModal?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onOpenAudioGuideModal }) => {
  const {
    login,
    register,
    language,
    setLanguage,
    speakText,
    isSpeaking,
    stopSpeaking,
    t
  } = useApp();

  const [mode, setMode] = useState<'signin' | 'register'>('signin');
  
  // Sign in form state
  const [signInIdentifier, setSignInIdentifier] = useState('082 555 4321');
  const [signInPin, setSignInPin] = useState('1234');
  const [showPin, setShowPin] = useState(false);
  const [signInError, setSignInError] = useState<string | null>(null);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPin, setRegPin] = useState('');
  const [regConfirmPin, setRegConfirmPin] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regError, setRegError] = useState<string | null>(null);

  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'zu', label: 'isiZulu' },
    { code: 'xh', label: 'isiXhosa' },
    { code: 'st', label: 'Sesotho' },
    { code: 'af', label: 'Afrikaans' },
  ];

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setSignInError(null);
    const result = login(signInIdentifier, signInPin);
    if (!result.success) {
      setSignInError(result.message || 'Incorrect mobile number or security PIN.');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (regPin !== regConfirmPin) {
      setRegError('The two security PINs do not match.');
      return;
    }

    const result = register(regName, regPhone, regPin, regEmail || undefined);
    if (!result.success) {
      setRegError(result.message || 'Could not create account. Please check your details.');
    }
  };

  const handleQuickDemoLogin = () => {
    setSignInIdentifier('082 555 4321');
    setSignInPin('1234');
    login('082 555 4321', '1234');
  };

  const playLoginAudioHelp = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speakText(
        'Welcome to MoniBuddy. Please enter your mobile number and four digit security PIN to access your offline money ledger. Your details stay safely locked on this phone.'
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-950 flex flex-col justify-between p-4 sm:p-6 text-white font-sans">
      {/* Top Bar on Login Page */}
      <div className="max-w-md w-full mx-auto flex items-center justify-between pb-4">
        {/* MoniBuddy Brand Mark */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 font-extrabold text-white text-lg shadow-md shadow-emerald-900/30">
            m
          </div>
          <div>
            <span className="font-bold text-lg tracking-tight text-white">monibuddy</span>
            <span className="ml-2 rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-semibold text-emerald-300 ring-1 ring-emerald-500/30">
              Offline-First
            </span>
          </div>
        </div>

        {/* Controls: Audio & Language */}
        <div className="flex items-center gap-2">
          <button
            onClick={playLoginAudioHelp}
            className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-semibold transition-all ${
              isSpeaking
                ? 'border-emerald-400 bg-emerald-500/30 text-emerald-200 animate-pulse'
                : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
            title="Listen to login instructions"
          >
            <Volume2 className="h-3.5 w-3.5 text-emerald-400" />
            <span className="hidden sm:inline">{isSpeaking ? 'Playing' : 'Listen'}</span>
          </button>

          <select
            value={language}
            onChange={e => setLanguage(e.target.value as Language)}
            className="rounded-xl border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:bg-white/10 focus:outline-hidden"
          >
            {languages.map(l => (
              <option key={l.code} value={l.code} className="bg-slate-900 text-white">
                {l.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Login Card Container */}
      <div className="w-full max-w-md mx-auto my-auto animate-in fade-in-50 zoom-in-95">
        <div className="rounded-3xl border border-white/10 bg-slate-900/85 backdrop-blur-xl p-6 sm:p-8 shadow-2xl ring-1 ring-black/40">
          {/* Header Title */}
          <div className="text-center pb-5">
            <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              {mode === 'signin' ? 'Sign in to Your Ledger' : 'Create Your Account'}
            </h1>
            <p className="mt-1 text-xs text-slate-400 leading-relaxed">
              {mode === 'signin'
                ? 'Enter your mobile number and security PIN to unlock your budget.'
                : 'Takes 10 seconds. Stored privately on your phone without internet.'}
            </p>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex rounded-2xl bg-white/5 p-1 border border-white/10 mb-6 text-xs font-bold">
            <button
              type="button"
              onClick={() => {
                setMode('signin');
                setSignInError(null);
              }}
              className={`flex-1 rounded-xl py-2 transition-all ${
                mode === 'signin'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setRegError(null);
              }}
              className={`flex-1 rounded-xl py-2 transition-all ${
                mode === 'register'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Create Account
            </button>
          </div>

          {/* SIGN IN FORM */}
          {mode === 'signin' ? (
            <form onSubmit={handleSignIn} className="space-y-4">
              {signInError && (
                <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
                  <span>{signInError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Mobile Number or Email
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Phone className="h-4 w-4" />
                  </span>
                  <input
                    type="text"
                    value={signInIdentifier}
                    onChange={e => setSignInIdentifier(e.target.value)}
                    placeholder="082 123 4567"
                    className="w-full rounded-xl border border-white/10 bg-white/5 pl-10 pr-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-300">
                    4-Digit Security PIN
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-emerald-300"
                  >
                    {showPin ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    <span>{showPin ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <KeyRound className="h-4 w-4" />
                  </span>
                  <input
                    type={showPin ? 'text' : 'password'}
                    maxLength={8}
                    value={signInPin}
                    onChange={e => setSignInPin(e.target.value)}
                    placeholder="••••"
                    className="w-full rounded-xl border border-white/10 bg-white/5 pl-10 pr-3.5 py-2.5 text-sm font-mono tracking-widest text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="rounded bg-white/10 border-white/20 text-emerald-600 focus:ring-0"
                  />
                  <span>Remember me on this phone</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-700/30 hover:from-emerald-500 hover:to-teal-500 transition-all"
              >
                <span>Unlock &amp; Sign In</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              {/* Quick Demo Login Option */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleQuickDemoLogin}
                  className="w-full flex items-center justify-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 py-2.5 text-xs font-bold text-emerald-300 hover:bg-emerald-500/20 transition-colors"
                >
                  <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                  <span>1-Click Demo Login as Sipho (PIN: 1234)</span>
                </button>
              </div>
            </form>
          ) : (
            /* CREATE ACCOUNT FORM */
            <form onSubmit={handleRegister} className="space-y-3.5">
              {regError && (
                <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
                  <span>{regError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <UserIcon className="h-4 w-4" />
                  </span>
                  <input
                    type="text"
                    value={regName}
                    onChange={e => setRegName(e.target.value)}
                    placeholder="e.g. Sipho Dlamini"
                    className="w-full rounded-xl border border-white/10 bg-white/5 pl-10 pr-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Mobile Number (South Africa)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Phone className="h-4 w-4" />
                  </span>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={e => setRegPhone(e.target.value)}
                    placeholder="082 123 4567"
                    className="w-full rounded-xl border border-white/10 bg-white/5 pl-10 pr-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Security PIN (4-digits)
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    value={regPin}
                    onChange={e => setRegPin(e.target.value)}
                    placeholder="••••"
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm font-mono tracking-widest text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Confirm PIN
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    value={regConfirmPin}
                    onChange={e => setRegConfirmPin(e.target.value)}
                    placeholder="••••"
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm font-mono tracking-widest text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Email (Optional)
                </label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={e => setRegEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-700/30 hover:from-emerald-500 hover:to-teal-500 transition-all"
              >
                <span>Create Account &amp; Start</span>
                <Check className="h-4 w-4" />
              </button>
            </form>
          )}

          {/* Privacy Footnote */}
          <div className="mt-6 pt-4 border-t border-white/10 flex items-start gap-2.5 text-[11px] text-slate-400 leading-relaxed">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
            <p>
              <strong>Zero cloud transmission:</strong> Your login credentials and personal records are encrypted and stored only inside this device&apos;s browser.
            </p>
          </div>
        </div>
      </div>

      {/* Footer Branding */}
      <div className="max-w-md w-full mx-auto text-center pt-4 text-[11px] text-slate-500">
        MoniBuddy · Offline-First Financial Inclusion · POPIA Data Sovereign
      </div>
    </div>
  );
};
