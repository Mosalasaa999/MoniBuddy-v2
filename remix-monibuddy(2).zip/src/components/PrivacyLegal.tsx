import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  Download,
  Trash2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const PrivacyLegal: React.FC = () => {
  const {
    startingBalance,
    emergencyBuffer,
    burnRate,
    pots,
    transactions,
    resetAllData
  } = useApp();

  const [confirmClearOpen, setConfirmClearOpen] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownloadBackup = () => {
    const backupData = {
      app: 'MoniBuddy',
      version: '1.0',
      exportedAt: new Date().toISOString(),
      financialState: {
        startingBalance,
        emergencyBuffer,
        burnRate,
        pots,
        transactions
      }
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `monibuddy-backup-${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleClearData = () => {
    resetAllData();
    setConfirmClearOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-800 ring-1 ring-emerald-600/20">
            POPIA Compliant
          </span>
        </div>
        <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">
          Your Privacy &amp; Safety
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Plain language transparency regarding your personal numbers and data rights.
        </p>
      </div>

      {/* Main Guarantee Card */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-8 shadow-xs">
        <div className="flex items-start gap-4 pb-6 border-b border-slate-100">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-800">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              Your Money Stays in Your Hands
            </h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              MoniBuddy is built on the principle of <strong>data sovereignty</strong>. Unlike banks and fintech apps that require ID uploads, credit checks, and bank statements:
            </p>
          </div>
        </div>

        {/* 3 Clear Guarantees */}
        <div className="mt-6 space-y-3">
          <div className="rounded-2xl bg-slate-50 p-4 border border-slate-100">
            <h4 className="text-xs font-bold text-slate-900">1. Stored Only On Your Phone</h4>
            <p className="mt-0.5 text-xs text-slate-600 leading-relaxed">
              Your balances, savings pots, and expenses are saved inside your own device. They are never sent to external servers or cloud databases.
            </p>
          </div>

          <div className="rounded-2xl bg-slate-50 p-4 border border-slate-100">
            <h4 className="text-xs font-bold text-slate-900">2. No Ads &amp; No Tracking</h4>
            <p className="mt-0.5 text-xs text-slate-600 leading-relaxed">
              There are no marketing cookies, tracking scripts, or advertising brokers watching what you spend or offering you predatory loans.
            </p>
          </div>

          <div className="rounded-2xl bg-slate-50 p-4 border border-slate-100">
            <h4 className="text-xs font-bold text-slate-900">3. Total Control Anytime</h4>
            <p className="mt-0.5 text-xs text-slate-600 leading-relaxed">
              You can download a clean backup of your information, or wipe all records with a single click.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-7 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-5 border-t border-slate-100">
          <button
            onClick={handleDownloadBackup}
            className="flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-slate-800 transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Download My Data (Backup)</span>
          </button>

          <button
            onClick={() => setConfirmClearOpen(true)}
            className="flex items-center justify-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-xs font-bold text-rose-800 hover:bg-rose-100 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span>Clear All My Data</span>
          </button>
        </div>

        {downloadSuccess && (
          <div className="mt-3 text-xs font-semibold text-emerald-700 flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4" />
            <span>Backup file downloaded safely to your downloads folder.</span>
          </div>
        )}
      </div>

      {/* Confirmation Modal */}
      {confirmClearOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-100 text-rose-700">
                <AlertCircle className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Clear All Records?</h4>
                <p className="text-xs text-slate-500">This cannot be undone</p>
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-600 leading-relaxed">
              Are you sure you want to permanently erase your savings pots, emergency buffer, and transaction history from this phone?
            </p>

            <div className="mt-6 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setConfirmClearOpen(false)}
                className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"
              >
                Keep My Data
              </button>
              <button
                onClick={handleClearData}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-rose-700"
              >
                Yes, Erase Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
