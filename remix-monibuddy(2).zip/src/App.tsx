/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { TabType, GoalPot } from './types';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { PotsOverview } from './components/PotsOverview';
import { IncomeExpenses } from './components/IncomeExpenses';
import { BufferCredit } from './components/BufferCredit';
import { ScamGuard } from './components/ScamGuard';
import { Sync2G } from './components/Sync2G';
import { TechnicalBrief } from './components/TechnicalBrief';
import { PrivacyLegal } from './components/PrivacyLegal';
import { AudioGuideModal } from './components/AudioGuideModal';
import { NewPotModal, PotActionModal, BufferModal, VoiceCaptureModal } from './components/Modals';
import { LoginPage } from './components/LoginPage';
import { Menu } from 'lucide-react';

const MainLayout: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<TabType>('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);

  // Modals state
  const [audioGuideOpen, setAudioGuideOpen] = useState<boolean>(false);
  const [voiceModalOpen, setVoiceModalOpen] = useState<boolean>(false);
  const [newPotModalOpen, setNewPotModalOpen] = useState<boolean>(false);
  const [bufferModalOpen, setBufferModalOpen] = useState<boolean>(false);
  const [potActionState, setPotActionState] = useState<{
    isOpen: boolean;
    pot: GoalPot | null;
    mode: 'deposit' | 'withdraw';
  }>({
    isOpen: false,
    pot: null,
    mode: 'deposit'
  });

  const handleOpenPotAction = (pot: GoalPot, mode: 'deposit' | 'withdraw') => {
    setPotActionState({
      isOpen: true,
      pot,
      mode
    });
  };

  return (
    <div className="h-screen w-full overflow-x-hidden overflow-y-hidden bg-slate-50 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        onOpenAudioGuideModal={() => setAudioGuideOpen(true)}
        onOpenVoiceModal={() => setVoiceModalOpen(true)}
      />

      {/* Mobile subheader bar with hamburger trigger */}
      <div className="shrink-0 flex md:hidden items-center justify-between gap-2 border-b border-slate-200 bg-white px-3 py-1.5">
        <button
          type="button"
          onClick={() => setMobileSidebarOpen(true)}
          className="flex min-h-[44px] items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 active:bg-slate-100 transition-colors whitespace-nowrap shrink-0"
        >
          <Menu className="h-4 w-4 shrink-0" />
          <span>Menu &amp; Tools</span>
        </button>

        <span className="text-xs font-bold capitalize text-slate-800 truncate">
          {currentTab.replace('_', ' ')}
        </span>
      </div>

      {/* Main Body */}
      <div className="flex-1 min-h-0 flex max-w-7xl w-full mx-auto overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          mobileOpen={mobileSidebarOpen}
          setMobileOpen={setMobileSidebarOpen}
        />

        {/* Scrollable Content Area */}
        <main className="flex-1 min-w-0 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {currentTab === 'overview' && (
            <PotsOverview
              onOpenNewPotModal={() => setNewPotModalOpen(true)}
              onOpenBufferModal={() => setBufferModalOpen(true)}
              onSelectPotForAction={handleOpenPotAction}
            />
          )}

          {currentTab === 'income_expenses' && <IncomeExpenses />}

          {currentTab === 'buffer_credit' && (
            <BufferCredit onOpenBufferModal={() => setBufferModalOpen(true)} />
          )}

          {currentTab === 'scam_guard' && <ScamGuard />}

          {currentTab === 'sync_2g' && <Sync2G />}

          {currentTab === 'technical_brief' && <TechnicalBrief />}

          {currentTab === 'privacy_legal' && <PrivacyLegal />}
        </main>
      </div>

      {/* Global Modals */}
      <AudioGuideModal
        isOpen={audioGuideOpen}
        onClose={() => setAudioGuideOpen(false)}
        currentTab={currentTab}
      />

      <NewPotModal
        isOpen={newPotModalOpen}
        onClose={() => setNewPotModalOpen(false)}
      />

      <PotActionModal
        isOpen={potActionState.isOpen}
        pot={potActionState.pot}
        mode={potActionState.mode}
        onClose={() => setPotActionState(prev => ({ ...prev, isOpen: false }))}
      />

      <BufferModal
        isOpen={bufferModalOpen}
        onClose={() => setBufferModalOpen(false)}
      />

      <VoiceCaptureModal
        isOpen={voiceModalOpen}
        onClose={() => setVoiceModalOpen(false)}
      />
    </div>
  );
};

const RootNavigation: React.FC = () => {
  const { isAuthenticated } = useApp();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return <MainLayout />;
};

export default function App() {
  return (
    <AppProvider>
      <RootNavigation />
    </AppProvider>
  );
}
