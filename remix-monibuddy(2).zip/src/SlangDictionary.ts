export interface SlangAliasGroup {
  readonly term: string;
  readonly aliases: readonly string[];
  readonly amount?: number;
  readonly category: string;
}

export const PHONETIC_ALIAS_MATRIX: readonly SlangAliasGroup[] = [
  { term: 'tiger', aliases: ['tiger', 'taiga', 'tiga', 'tyger', 'tigers'], amount: 10, category: 'General Expense / Income' },
  { term: 'choco', aliases: ['choko', 'choc', 'chock', 'chalk', 'chocolate', 'shock', 'chok', 'ichoko', 'i-choko'], amount: 20, category: 'General Expense / Income' },
  { term: 'clipa', aliases: ['clipper', 'clippers', 'clipa', 'klipa', 'kliper', 'iclipa', 'i-clipa', 'stikka', 'steka', 'sticker', 'clip'], amount: 100, category: 'General Expense / Income' },
  { term: 'grand', aliases: ['grand', 'thousand', 'k', 'nkani', 'grands'], amount: 1000, category: 'General Expense / Income' },
  { term: 'stokvel', aliases: ['stokvel', 'stokfele', 'society', 'umgalelo'], category: 'Group Savings' },
  { term: 'mashonisa', aliases: ['mashonisa', 'umashonisa', 'bomashonisa', 'machonisa', 'skopper', 'skoper'], category: 'Unregistered Credit / Loan' },
  { term: 'tjotjo', aliases: ['tjotjo', 'tjo-tjo', 'cooldrink money', 'cold drink fee', 'inyoba'], category: 'Bribe / Upfront Fee' }
];

/**
 * Expands South African phonetic/vernacular money and fraud slang terms into canonical
 * tokens so downstream security parsers (`scamParser.ts`) can match evasive slang phrases
 * such as "send 2 clipa tjotjo to unlock loan" -> "send 2 R100 upfront release fee to unlock loan".
 */
export const expandVernacularAliasesForSecurity = (input: string): string => {
  if (!input) return '';
  return input
    .replace(/\b(tjotjo|tjo[\s-]?tjo|cooldrink\s+money|cold\s+drink\s+fee|inyoba)\b/giu, 'upfront release fee')
    .replace(/\b(umashonisa|bomashonisa|machonisa|skopper|skoper)\b/giu, 'mashonisa')
    .replace(/\b(\d+|one|two|three|four|five)\s+(tiger|taiga|tiga|tyger|tigers)\b/giu, 'R10')
    .replace(/\b(\d+|one|two|three|four|five)\s+(choko|choco|choc|ichoko)\b/giu, 'R20')
    .replace(/\b(\d+|one|two|three|four|five)\s+(clipa|clipper|klipa|iclipa|stikka|steka)\b/giu, 'R100');
};

export interface ParsedVoiceEntry {
  type: 'income' | 'expense';
  title: string;
  amount: number;
  category: string;
  tags: string[];
}

export interface ParsedVoiceTransaction {
  entries: ParsedVoiceEntry[];
  slangTags: string[];
}

interface AliasMatch {
  group: SlangAliasGroup;
  alias: string;
  index: number;
  end: number;
}

interface NumberMatch {
  value: number;
  index: number;
  end: number;
}

interface CategoryMatch {
  category: string;
  type: ParsedVoiceEntry['type'];
  index: number;
  end: number;
}

const NUMBER_WORDS: Readonly<Record<string, number>> = {
  zero: 0,
  one: 1,
  won: 1,
  two: 2,
  to: 2,
  too: 2,
  ku: 2,
  three: 3,
  four: 4,
  for: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10
};

const CATEGORY_PATTERNS: readonly {
  pattern: RegExp;
  category: string;
  type: ParsedVoiceEntry['type'];
}[] = [
  { pattern: /\b(salaries|salary|wage|wages|pay)\b/giu, category: 'Salary / Income', type: 'income' },
  { pattern: /\b(spaza|market|emakethe)\b/giu, category: 'Market Sales Income', type: 'income' },
  { pattern: /\b(taxi|transport)\b/giu, category: 'Transport / Taxi Expense', type: 'expense' },
  { pattern: /\b(data|airtime|internet|wifi|wi-fi)\b/giu, category: 'Connectivity', type: 'expense' }
];

const escapeRegex = (value: string): string => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const findAliases = (text: string): AliasMatch[] => {
  const aliases = PHONETIC_ALIAS_MATRIX
    .flatMap(group => group.aliases.map(alias => ({ group, alias })))
    .sort((left, right) => right.alias.length - left.alias.length);
  const aliasPattern = aliases.map(item => escapeRegex(item.alias)).join('|');
  const regex = new RegExp(`(^|[^\\p{L}\\p{N}])(${aliasPattern})(?=$|[^\\p{L}\\p{N}])`, 'giu');
  const matches: AliasMatch[] = [];

  for (const match of text.matchAll(regex)) {
    const alias = match[2].toLocaleLowerCase();
    const definition = aliases.find(item => item.alias === alias);
    if (!definition || match.index === undefined) continue;
    const aliasOffset = match[0].length - match[2].length;
    const index = match.index + aliasOffset;
    matches.push({
      group: definition.group,
      alias,
      index,
      end: index + match[2].length
    });
  }

  return matches;
};

const findNumberMatches = (text: string): NumberMatch[] => {
  const pattern = /\b(\d+(?:[.,]\d{1,2})?|zero|one|won|two|to|too|ku|three|four|for|five|six|seven|eight|nine|ten)\b/giu;
  const matches: NumberMatch[] = [];

  for (const match of text.matchAll(pattern)) {
    if (match.index === undefined) continue;
    const token = match[1].toLocaleLowerCase();
    const value = /^\d/.test(token)
      ? Number(token.replace(',', '.'))
      : NUMBER_WORDS[token];
    if (Number.isFinite(value)) {
      matches.push({ value, index: match.index, end: match.index + match[0].length });
    }
  }

  return matches;
};

const findCategoryMatches = (text: string): CategoryMatch[] => {
  const matches: CategoryMatch[] = [];
  for (const definition of CATEGORY_PATTERNS) {
    for (const match of text.matchAll(definition.pattern)) {
      if (match.index === undefined) continue;
      matches.push({
        category: definition.category,
        type: definition.type,
        index: match.index,
        end: match.index + match[0].length
      });
    }
  }
  return matches;
};

const isSameClause = (text: string, firstIndex: number, secondIndex: number): boolean => {
  const start = Math.min(firstIndex, secondIndex);
  const end = Math.max(firstIndex, secondIndex);
  return !/[,;.!?]|\b(?:and|kanye)\b/iu.test(text.slice(start, end));
};

const categoryForAlias = (text: string, match: AliasMatch, categories: readonly CategoryMatch[]) => {
  let nearest: { match: CategoryMatch; distance: number } | null = null;
  for (const category of categories) {
    if (!isSameClause(text, category.index, match.index)) continue;
    const distance = category.end <= match.index
      ? match.index - category.end
      : category.index >= match.end
        ? category.index - match.end
        : 0;
    if (!nearest || distance < nearest.distance) {
      nearest = { match: category, distance };
    }
  }
  return nearest?.match;
};

const quantityBeforeAlias = (
  transcript: string,
  match: AliasMatch,
  numberMatches: readonly NumberMatch[],
  previousAliasEnd: number
): number => {
  const candidate = [...numberMatches]
    .reverse()
    .find(number =>
      number.end <= match.index &&
      number.index >= previousAliasEnd &&
      match.index - number.end <= 28
    );
  if (!candidate) return 1;

  const between = transcript.slice(candidate.end, match.index);
  if (!/^[\s,.'’\-]*(?:(?:u|i|ku|a|an|the)[\s.'’\-]*)*$/iu.test(between)) return 1;
  return candidate.value;
};

const extractCurrencyAmounts = (text: string): NumberMatch[] => {
  const matches: NumberMatch[] = [];
  const patterns = [
    /\b(?:u)?R\s*(\d+(?:[.,]\d{1,2})?)(?!\d)/giu,
    /\b(\d+(?:[.,]\d{1,2})?)\s*(?:rand|rands|zar)\b/giu
  ];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      if (match.index === undefined) continue;
      const numericText = match[1];
      const value = Number(numericText.replace(',', '.'));
      if (Number.isFinite(value) && value > 0) {
        const offset = match[0].lastIndexOf(numericText);
        matches.push({
          value,
          index: match.index + offset,
          end: match.index + offset + numericText.length
        });
      }
    }
  }
  return matches.sort((left, right) => left.index - right.index);
};

export const parseVernacularTransaction = (transcript: string): ParsedVoiceTransaction => {
  const aliases = findAliases(transcript);
  const numbers = findNumberMatches(transcript);
  const categories = findCategoryMatches(transcript);
  const slangTags = [...new Set(aliases.map(match => match.group.term))];
  const entries: ParsedVoiceEntry[] = [];
  let previousAliasEnd = 0;

  for (const alias of aliases) {
    const categoryMatch = categoryForAlias(transcript, alias, categories);
    if (alias.group.amount !== undefined) {
      const quantity = quantityBeforeAlias(transcript, alias, numbers, previousAliasEnd);
      const amount = alias.group.amount * quantity;
      const category = categoryMatch?.category ?? alias.group.category;
      entries.push({
        type: categoryMatch?.type ?? 'expense',
        title: `${alias.group.term} (${quantity} x R${alias.group.amount})`,
        amount,
        category,
        tags: [alias.group.term]
      });
    }
    previousAliasEnd = alias.end;
  }

  const currencyAmounts = extractCurrencyAmounts(transcript);
  for (const currency of currencyAmounts) {
    const nearestCategory = categories
      .filter(category => isSameClause(transcript, category.index, currency.index))
      .map(category => ({
        category,
        distance: category.end <= currency.index
          ? currency.index - category.end
          : category.index >= currency.end
            ? category.index - currency.end
            : 0
      }))
      .sort((left, right) => left.distance - right.distance)[0]?.category;
    const hasSlangAmount = aliases.some(alias =>
      alias.group.amount !== undefined &&
      Math.abs(alias.group.amount - currency.value) < 0.001
    );
    const hasIncomeCategory = nearestCategory?.type === 'income';

    if (aliases.length > 0 && !hasIncomeCategory) continue;
    if (hasSlangAmount && !hasIncomeCategory) continue;

    entries.unshift({
      type: nearestCategory?.type ?? 'expense',
      title: nearestCategory?.category ?? 'Voice-recorded entry',
      amount: currency.value,
      category: nearestCategory?.category ?? 'General Expense / Income',
      tags: slangTags
    });
  }

  if (aliases.length === 0 && currencyAmounts.length === 0) {
    const number = numbers.find(match => match.value > 0);
    if (number) {
      const category = categories.find(item =>
        Math.abs(item.index - number.index) <= 48 || Math.abs(item.end - number.index) <= 48
      );
      entries.push({
        type: category?.type ?? 'expense',
        title: category?.category ?? 'Voice-recorded entry',
        amount: number.value,
        category: category?.category ?? 'General Expense / Income',
        tags: []
      });
    }
  }

  return { entries, slangTags };
};
