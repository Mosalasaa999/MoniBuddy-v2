import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { Transaction, GoalPot, Language, NetworkMode, CarrierSimulation, User } from '../types';
import { translations } from '../translations';
import confetti from 'canvas-confetti';

interface AppContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (phoneOrEmail: string, pin: string) => { success: boolean; message?: string };
  register: (name: string, phone: string, pin: string, email?: string) => { success: boolean; message?: string };
  logout: () => void;

  language: Language;
  setLanguage: (lang: Language) => void;
  networkMode: NetworkMode;
  setNetworkMode: (mode: NetworkMode) => void;
  carrierSimulation: CarrierSimulation;
  syncLedger: () => Promise<void>;
  
  startingBalance: number;
  setStartingBalance: (val: number) => void;
  
  emergencyBuffer: number;
  addToBuffer: (amount: number, note?: string) => void;
  withdrawFromBuffer: (amount: number, note?: string) => void;
  
  burnRate: number;
  setBurnRate: (val: number) => void;
  
  pots: GoalPot[];
  createPot: (pot: Omit<GoalPot, 'id' | 'createdAt' | 'currentAmount'>) => void;
  depositToPot: (potId: string, amount: number) => void;
  withdrawFromPot: (potId: string, amount: number) => void;
  deletePot: (potId: string) => void;
  
  transactions: Transaction[];
  addTransaction: (tx: Omit<Transaction, 'id' | 'timestamp' | 'synced'>) => void;
  deleteTransaction: (id: string) => void;
  
  // Computed values
  totalIncome: number;
  totalExpenses: number;
  totalGoalSavings: number;
  safeToSpend: number;
  weeksBufferCovers: number;
  estimatedMonthEndSafe: number | null;
  
  // Audio Guide
  isSpeaking: boolean;
  activeSpeechText: string | null;
  speakText: (text: string) => void;
  stopSpeaking: () => void;
  
  // Demo State
  prototypeMode: boolean;
  setPrototypeMode: (val: boolean) => void;
  resetAllData: () => void;
  loadDemoData: () => void;
  t: (typeof translations)['en'];
}

const AppContext = createContext<AppContextType | null>(null);

const STORAGE_KEY = 'monibuddy_state_v1';
const AUTH_USER_KEY = 'monibuddy_current_user_v1';
const USERS_STORAGE_KEY = 'monibuddy_registered_users_v1';

const DEFAULT_DEMO_USER: User = {
  id: 'user_sipho',
  name: 'Sipho Dlamini',
  phone: '082 555 4321',
  email: 'sipho@monibuddy.za',
  pin: '1234',
  createdAt: '2026-01-15T08:00:00.000Z'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [registeredUsers, setRegisteredUsers] = useState<User[]>([DEFAULT_DEMO_USER]);

  const [language, setLanguage] = useState<Language>('en');
  const [networkMode, setNetworkMode] = useState<NetworkMode>('2g');
  const [prototypeMode, setPrototypeMode] = useState<boolean>(true);

  const [startingBalance, setStartingBalanceState] = useState<number>(0);
  const [emergencyBuffer, setEmergencyBufferState] = useState<number>(0);
  const [burnRate, setBurnRateState] = useState<number>(250);
  const [pots, setPotsState] = useState<GoalPot[]>([]);
  const [transactions, setTransactionsState] = useState<Transaction[]>([]);

  // Audio Guide state
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [activeSpeechText, setActiveSpeechText] = useState<string | null>(null);

  // Carrier Simulation State
  const [carrierSimulation, setCarrierSimulation] = useState<CarrierSimulation>({
    mode: '2g',
    name: '2G EDGE',
    latencyMs: 950,
    payloadLimitBytes: '600 - 2400 Bytes',
    description: 'High latency (600-1500ms), 2G/EDGE network. Packets micro-compressed.',
    lastSyncedAt: null,
    pendingBytes: 0,
    isSyncing: false,
    syncLog: ['Local SQLite ledger initialized.', 'Ready for 2G sync session.']
  });

  // Load from local storage
  useEffect(() => {
    try {
      const savedUser = localStorage.getItem(AUTH_USER_KEY);
      if (savedUser) {
        setCurrentUser(JSON.parse(savedUser));
      }
      const savedUsersList = localStorage.getItem(USERS_STORAGE_KEY);
      if (savedUsersList) {
        setRegisteredUsers(JSON.parse(savedUsersList));
      }

      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.startingBalance !== undefined) setStartingBalanceState(parsed.startingBalance);
        if (parsed.emergencyBuffer !== undefined) setEmergencyBufferState(parsed.emergencyBuffer);
        if (parsed.burnRate !== undefined) setBurnRateState(parsed.burnRate);
        if (parsed.pots) setPotsState(parsed.pots);
        if (parsed.transactions) setTransactionsState(parsed.transactions);
        if (parsed.language) setLanguage(parsed.language);
      }
    } catch {
      // Local storage fallback
    }
  }, []);

  // Sync to local storage
  useEffect(() => {
    try {
      const stateToSave = {
        startingBalance,
        emergencyBuffer,
        burnRate,
        pots,
        transactions,
        language
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
    } catch {
      // Ignore
    }
  }, [startingBalance, emergencyBuffer, burnRate, pots, transactions, language]);

  // Update pending bytes whenever transactions or changes occur
  useEffect(() => {
    const unsyncedCount = transactions.filter(t => !t.synced).length;
    // roughly 48 bytes per compressed transaction diff
    const pendingSize = Math.max(unsyncedCount * 54 + (pots.length > 0 ? 128 : 0), unsyncedCount > 0 ? 140 : 0);
    setCarrierSimulation(prev => ({
      ...prev,
      pendingBytes: pendingSize
    }));
  }, [transactions, pots]);

  // Update network simulation mode details
  useEffect(() => {
    if (networkMode === '2g') {
      setCarrierSimulation(prev => ({
        ...prev,
        mode: '2g',
        name: '2G EDGE',
        latencyMs: 1100,
        payloadLimitBytes: '600 - 2400 Bytes',
        description: 'High latency, micro-compressed delta sync under 2.4KB.'
      }));
    } else if (networkMode === '4g') {
      setCarrierSimulation(prev => ({
        ...prev,
        mode: '4g',
        name: '3G / 4G Fast',
        latencyMs: 45,
        payloadLimitBytes: 'Broadband Cellular',
        description: 'Broadband connection, instant cloud sync.'
      }));
    } else {
      setCarrierSimulation(prev => ({
        ...prev,
        mode: 'offline',
        name: 'Offline (Airplane)',
        latencyMs: 0,
        payloadLimitBytes: 'Zero Connectivity',
        description: 'Zero network access. All reads & writes queue to local offline ledger.'
      }));
    }
  }, [networkMode]);

  // Calculations
  const totalIncome = useMemo(() => {
    return transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [transactions]);

  const totalExpenses = useMemo(() => {
    return transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [transactions]);

  const totalGoalSavings = useMemo(() => {
    return pots.reduce((sum, p) => sum + p.currentAmount, 0);
  }, [pots]);

  // Safe to spend: Starting balance + Income - Expenses - Pots - Emergency Buffer
  const safeToSpend = useMemo(() => {
    return Math.max(0, startingBalance + totalIncome - totalExpenses - totalGoalSavings - emergencyBuffer);
  }, [startingBalance, totalIncome, totalExpenses, totalGoalSavings, emergencyBuffer]);

  // Weeks buffer covers
  const weeksBufferCovers = useMemo(() => {
    if (burnRate <= 0) return 0;
    return Number((emergencyBuffer / burnRate).toFixed(1));
  }, [emergencyBuffer, burnRate]);

  // Estimate safe to spend at month end
  const estimatedMonthEndSafe = useMemo(() => {
    const expenseTx = transactions.filter(t => t.type === 'expense');
    if (expenseTx.length < 3) return null;
    
    // Check span of days
    const timestamps = expenseTx.map(t => new Date(t.date).getTime()).sort((a, b) => a - b);
    const daySpan = Math.max(1, (timestamps[timestamps.length - 1] - timestamps[0]) / (1000 * 60 * 60 * 24));
    
    if (daySpan < 5) return null; // requires spanning days
    
    const dailyExpenseRate = totalExpenses / daySpan;
    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const daysRemaining = Math.max(1, daysInMonth - now.getDate());
    const projectedRemainingExpenses = dailyExpenseRate * daysRemaining;
    
    return Math.max(0, Number((safeToSpend - projectedRemainingExpenses).toFixed(2)));
  }, [transactions, totalExpenses, safeToSpend]);

  // Auth Handlers
  const login = (phoneOrEmail: string, pin: string) => {
    const cleanQuery = phoneOrEmail.trim().toLowerCase().replace(/\s+/g, '');
    const cleanPin = pin.trim();

    const matched = registeredUsers.find(
      u => (u.phone.replace(/\s+/g, '') === cleanQuery || (u.email && u.email.toLowerCase() === cleanQuery)) && u.pin === cleanPin
    );

    if (matched) {
      setCurrentUser(matched);
      try {
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(matched));
      } catch {
        // ignore
      }
      return { success: true };
    }
    return { success: false, message: 'Incorrect mobile number or security PIN.' };
  };

  const register = (name: string, phone: string, pin: string, email?: string) => {
    const cleanName = name.trim();
    const cleanPhone = phone.trim();
    const cleanPin = pin.trim();

    if (!cleanName) return { success: false, message: 'Please enter your full name.' };
    if (cleanPhone.length < 8) return { success: false, message: 'Please enter a valid mobile number.' };
    if (cleanPin.length < 4) return { success: false, message: 'Security PIN must be at least 4 digits.' };

    const cleanDigits = cleanPhone.replace(/\s+/g, '');
    const existing = registeredUsers.find(u => u.phone.replace(/\s+/g, '') === cleanDigits);
    if (existing) {
      return { success: false, message: 'An account with this phone number already exists. Please sign in.' };
    }

    const newUser: User = {
      id: 'user_' + Date.now(),
      name: cleanName,
      phone: cleanPhone,
      pin: cleanPin,
      email: email?.trim() || undefined,
      createdAt: new Date().toISOString()
    };

    const updated = [...registeredUsers, newUser];
    setRegisteredUsers(updated);
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }

    setCurrentUser(newUser);
    try {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(newUser));
    } catch {
      // ignore
    }

    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem(AUTH_USER_KEY);
    } catch {
      // ignore
    }
  };

  // Handlers
  const setStartingBalance = (val: number) => {
    setStartingBalanceState(Math.max(0, val));
  };

  const setBurnRate = (val: number) => {
    setBurnRateState(Math.max(10, val));
  };

  const addTransaction = (tx: Omit<Transaction, 'id' | 'timestamp' | 'synced'>) => {
    const newTx: Transaction = {
      ...tx,
      id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: Date.now(),
      synced: false
    };
    setTransactionsState(prev => [newTx, ...prev]);
  };

  const deleteTransaction = (id: string) => {
    setTransactionsState(prev => prev.filter(t => t.id !== id));
  };

  const addToBuffer = (amount: number, note?: string) => {
    if (amount <= 0) return;
    setEmergencyBufferState(prev => prev + amount);
    addTransaction({
      type: 'buffer_deposit',
      title: note ? `Buffer deposit: ${note}` : 'Emergency buffer deposit',
      amount,
      category: 'Buffer',
      date: new Date().toISOString().split('T')[0]
    });
  };

  const withdrawFromBuffer = (amount: number, note?: string) => {
    if (amount <= 0) return;
    setEmergencyBufferState(prev => Math.max(0, prev - amount));
    addTransaction({
      type: 'buffer_withdraw',
      title: note ? `Buffer emergency withdrawal: ${note}` : 'Buffer emergency withdrawal',
      amount,
      category: 'Buffer',
      date: new Date().toISOString().split('T')[0]
    });
  };

  const createPot = (potData: Omit<GoalPot, 'id' | 'createdAt' | 'currentAmount'>) => {
    const newPot: GoalPot = {
      ...potData,
      id: 'pot_' + Date.now(),
      currentAmount: 0,
      createdAt: new Date().toISOString()
    };
    setPotsState(prev => [...prev, newPot]);
  };

  const depositToPot = (potId: string, amount: number) => {
    if (amount <= 0) return;
    setPotsState(prev =>
      prev.map(p => {
        if (p.id === potId) {
          const updatedAmount = p.currentAmount + amount;
          if (updatedAmount >= p.targetAmount && p.currentAmount < p.targetAmount) {
            try {
              confetti({
                particleCount: 80,
                spread: 70,
                origin: { y: 0.6 }
              });
            } catch {
              // ignore
            }
          }
          return { ...p, currentAmount: updatedAmount };
        }
        return p;
      })
    );

    const targetPot = pots.find(p => p.id === potId);
    addTransaction({
      type: 'pot_deposit',
      title: `Deposit to ${targetPot?.name || 'Goal Pot'}`,
      amount,
      category: 'Pots',
      potId,
      date: new Date().toISOString().split('T')[0]
    });
  };

  const withdrawFromPot = (potId: string, amount: number) => {
    if (amount <= 0) return;
    setPotsState(prev =>
      prev.map(p => {
        if (p.id === potId) {
          return { ...p, currentAmount: Math.max(0, p.currentAmount - amount) };
        }
        return p;
      })
    );

    const targetPot = pots.find(p => p.id === potId);
    addTransaction({
      type: 'pot_withdraw',
      title: `Withdraw from ${targetPot?.name || 'Goal Pot'}`,
      amount,
      category: 'Pots',
      potId,
      date: new Date().toISOString().split('T')[0]
    });
  };

  const deletePot = (potId: string) => {
    setPotsState(prev => prev.filter(p => p.id !== potId));
  };

  // Sync Ledger over 2G / 4G
  const syncLedger = async () => {
    if (networkMode === 'offline') {
      setCarrierSimulation(prev => ({
        ...prev,
        syncLog: ['Sync blocked: Device is currently in Airplane / Offline mode.', ...prev.syncLog]
      }));
      return;
    }

    setCarrierSimulation(prev => ({
      ...prev,
      isSyncing: true,
      syncLog: [
        `Initiating ${networkMode.toUpperCase()} sync session...`,
        `Compressing ${transactions.filter(t => !t.synced).length} pending ledger events...`,
        ...prev.syncLog
      ]
    }));

    const delay = networkMode === '2g' ? 1200 : 300;
    await new Promise(r => setTimeout(r, delay));

    const totalSyncedBytes = carrierSimulation.pendingBytes || 248;

    setTransactionsState(prev => prev.map(t => ({ ...t, synced: true })));

    const nowFormatted = new Date().toLocaleTimeString();

    setCarrierSimulation(prev => ({
      ...prev,
      isSyncing: false,
      lastSyncedAt: nowFormatted,
      pendingBytes: 0,
      syncLog: [
        `[${nowFormatted}] Sync successful! ${totalSyncedBytes} bytes exchanged via ${prev.name}.`,
        'Ledger state reconciled with local encrypted storage.',
        ...prev.syncLog.slice(0, 8)
      ]
    }));
  };

  // Audio Guide Web Speech
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    setIsSpeaking(true);
    setActiveSpeechText(text);

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95; // Clear pace for accessibility
    utterance.pitch = 1.0;

    // Pick appropriate voice if available
    const voices = window.speechSynthesis.getVoices();
    const englishVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('South Africa') || v.name.includes('Natural') || v.name.includes('Google')));
    if (englishVoice) {
      utterance.voice = englishVoice;
    }

    utterance.onend = () => {
      setIsSpeaking(false);
      setActiveSpeechText(null);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setActiveSpeechText(null);
    };

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setActiveSpeechText(null);
  };

  // Demo Data Injection
  const loadDemoData = () => {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const twoDaysAgo = new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0];
    const fourDaysAgo = new Date(Date.now() - 86400000 * 4).toISOString().split('T')[0];
    const sixDaysAgo = new Date(Date.now() - 86400000 * 6).toISOString().split('T')[0];

    setStartingBalanceState(1500);
    setEmergencyBufferState(350);
    setBurnRateState(250);

    setPotsState([
      {
        id: 'pot_1',
        name: 'Bulk Food & Maize Meal',
        icon: '🍚',
        targetAmount: 600,
        currentAmount: 420,
        category: 'Food',
        color: 'emerald',
        createdAt: sixDaysAgo
      },
      {
        id: 'pot_2',
        name: 'Spaza Shop Cold Drink Stock',
        icon: '📦',
        targetAmount: 1000,
        currentAmount: 650,
        category: 'Business',
        color: 'amber',
        createdAt: fourDaysAgo
      },
      {
        id: 'pot_3',
        name: 'School Uniform & Stationery',
        icon: '🎒',
        targetAmount: 500,
        currentAmount: 200,
        category: 'Education',
        color: 'blue',
        createdAt: twoDaysAgo
      }
    ]);

    setTransactionsState([
      {
        id: 'tx_demo_1',
        type: 'income',
        title: 'Weekly Wages (Spaza Assistant)',
        amount: 850,
        category: 'Wages',
        date: yesterday,
        timestamp: Date.now() - 86400000,
        synced: true
      },
      {
        id: 'tx_demo_2',
        type: 'expense',
        title: 'Taxi Commute to Town',
        amount: 32,
        category: 'Transport',
        date: today,
        timestamp: Date.now() - 10000000,
        synced: false
      },
      {
        id: 'tx_demo_3',
        type: 'expense',
        title: 'Prepaid Electricity Token',
        amount: 100,
        category: 'Utilities',
        date: yesterday,
        timestamp: Date.now() - 80000000,
        synced: true
      },
      {
        id: 'tx_demo_4',
        type: 'expense',
        title: 'Fresh Bread and Milk',
        amount: 45,
        category: 'Groceries',
        date: twoDaysAgo,
        timestamp: Date.now() - 160000000,
        synced: true
      },
      {
        id: 'tx_demo_5',
        type: 'income',
        title: 'Casual Hair Braiding Piece Job',
        amount: 300,
        category: 'Side Hustle',
        date: fourDaysAgo,
        timestamp: Date.now() - 320000000,
        synced: true
      },
      {
        id: 'tx_demo_6',
        type: 'expense',
        title: 'Airtime & WhatsApp Data Bundle',
        amount: 29,
        category: 'Connectivity',
        date: sixDaysAgo,
        timestamp: Date.now() - 480000000,
        synced: true
      }
    ]);
  };

  const resetAllData = () => {
    setStartingBalanceState(0);
    setEmergencyBufferState(0);
    setBurnRateState(250);
    setPotsState([]);
    setTransactionsState([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const t = translations[language];

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isAuthenticated: Boolean(currentUser),
        login,
        register,
        logout,
        language,
        setLanguage,
        networkMode,
        setNetworkMode,
        carrierSimulation,
        syncLedger,
        startingBalance,
        setStartingBalance,
        emergencyBuffer,
        addToBuffer,
        withdrawFromBuffer,
        burnRate,
        setBurnRate,
        pots,
        createPot,
        depositToPot,
        withdrawFromPot,
        deletePot,
        transactions,
        addTransaction,
        deleteTransaction,
        totalIncome,
        totalExpenses,
        totalGoalSavings,
        safeToSpend,
        weeksBufferCovers,
        estimatedMonthEndSafe,
        isSpeaking,
        activeSpeechText,
        speakText,
        stopSpeaking,
        prototypeMode,
        setPrototypeMode,
        resetAllData,
        loadDemoData,
        t
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
