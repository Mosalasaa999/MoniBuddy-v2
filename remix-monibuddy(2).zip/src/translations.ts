import { Language } from './types';

export interface TranslationStrings {
  appName: string;
  tagline: string;
  safeToSpend: string;
  safeToSpendDesc: string;
  startingBalance: string;
  saveStartingBalance: string;
  startingBalanceHelper: string;
  startingTotal: string;
  income: string;
  expenses: string;
  goalSavings: string;
  emergencyBuffer: string;
  audioGuide: string;
  audioGuideActive: string;
  audioGuideTranscript: string;
  localDemo: string;
  goodDayBanner: string;
  goodDayBannerSub: string;
  microSavingsPots: string;
  potsSubtitle: string;
  newGoalPot: string;
  loadStarterPots: string;
  createFirstPot: string;
  loadExamplePots: string;
  emptyPotsMsg: string;
  howItWorks: string;
  hide: string;
  show: string;
  addToBuffer: string;
  deposit: string;
  withdraw: string;
  burnRateTitle: string;
  burnRateSub: string;
  mashonisaComparison: string;
  scamGuardTitle: string;
  scamGuardSub: string;
  syncTitle: string;
  syncSub: string;
  technicalBriefTitle: string;
  privacyGuaranteeTitle: string;
  resetDemoData: string;
  prototypeMode: string;
  navOverview: string;
  navIncomeExpenses: string;
  navBufferCredit: string;
  navScamGuard: string;
  nav2gSync: string;
  navTechnicalBrief: string;
  navPrivacyLegal: string;
}

export const translations: Record<Language, TranslationStrings> = {
  en: {
    appName: 'MoniBuddy',
    tagline: 'Simple Money Tracking That Works Without Data',
    safeToSpend: 'SAFE TO SPEND TODAY',
    safeToSpendDesc: 'This is the money you can spend freely today. Your food savings, school money, and emergency cash are already kept safe.',
    startingBalance: 'Your starting cash (R)',
    saveStartingBalance: 'Save starting cash',
    startingBalanceHelper: 'How much total cash or bank balance do you have right now?',
    startingTotal: 'STARTING CASH',
    income: 'MONEY IN',
    expenses: 'MONEY OUT',
    goalSavings: 'SAVINGS POTS',
    emergencyBuffer: 'EMERGENCY FUND',
    audioGuide: 'Listen',
    audioGuideActive: 'Reading aloud...',
    audioGuideTranscript: 'MoniBuddy Spoken Guide',
    localDemo: 'PRIVATE DEMO',
    goodDayBanner: 'Welcome! Your money information stays strictly on your phone.',
    goodDayBannerSub: 'No passwords needed, no internet required, and no one else can see your numbers.',
    microSavingsPots: 'My Savings Pots',
    potsSubtitle: 'Keep money set aside for food, spaza stock, school uniforms, or family events',
    newGoalPot: '+ New Pot',
    loadStarterPots: 'Add Starter Pots (Food, Stock, School)',
    createFirstPot: 'Create Your First Savings Pot',
    loadExamplePots: 'Load Example Pots',
    emptyPotsMsg: 'You have not added any savings pots yet. Even setting aside R10 for food helps protect your family.',
    howItWorks: 'How MoniBuddy Helps You',
    hide: 'Hide tips',
    show: 'Show tips',
    addToBuffer: '+ Add to Emergency Fund',
    deposit: 'Add Money',
    withdraw: 'Take Out',
    burnRateTitle: 'Weekly Living Expenses',
    burnRateSub: 'How much your household needs each week for food, taxi fare, and essentials',
    mashonisaComparison: 'Loan Sharks (Mashonisa) vs Your Own Emergency Cushion',
    scamGuardTitle: 'Scam & Fake Message Checker',
    scamGuardSub: 'Paste any WhatsApp message, SMS, or job offer here. We check it right on your phone without using data.',
    syncTitle: 'Use Without Data (USSD & 2G)',
    syncSub: 'See how you can dial *120*6664# on any button phone for free to check your balance without airtime.',
    technicalBriefTitle: 'How It Works Behind The Scenes',
    privacyGuaranteeTitle: 'Your Privacy Guarantee',
    resetDemoData: 'Reset Demo Data',
    prototypeMode: 'Demo mode',
    navOverview: 'Overview & Pots',
    navIncomeExpenses: 'Money In & Out',
    navBufferCredit: 'Emergency & Loan Shield',
    navScamGuard: 'Check Scams',
    nav2gSync: 'No-Data Mode (USSD)',
    navTechnicalBrief: 'How It Works',
    navPrivacyLegal: 'Privacy & Safety'
  },
  zu: {
    appName: 'MoniBuddy',
    tagline: 'Ukubala Imali Okulula Ngaphandle Kwe-inthanethi',
    safeToSpend: 'IMALI OKUPROPHELE UKUYISEBENZISA',
    safeToSpendDesc: 'Lena imali ongayisebenzisa namhlanje. Imali yokudla, eyengane nesikhwama esiphuthumayo zivikelekile.',
    startingBalance: 'Imali oqala ngayo (R)',
    saveStartingBalance: 'Gcina imali yokuqala',
    startingBalanceHelper: 'Unemali engakanani esandleni noma ebhange njengamanje?',
    startingTotal: 'IMALINI YOKUQALA',
    income: 'IMALI ENGENAYO',
    expenses: 'IMALI EPHUMAYO',
    goalSavings: 'IZIMBIZA ZOKONGA',
    emergencyBuffer: 'ISIKHWAMA ESIBHUKE',
    audioGuide: 'Lalela',
    audioGuideActive: 'Iyafunda ngokuzwakalayo...',
    audioGuideTranscript: 'Umhlahlandlela Wezwi We-MoniBuddy',
    localDemo: 'IDEMO YASENDAWENI',
    goodDayBanner: 'Sawubona! Imali yakho ihlala ezandleni zakho kuphela.',
    goodDayBannerSub: 'Ayikho i-inthanethi edingekayo, futhi akekho omunye obona izinombolo zakho.',
    microSavingsPots: 'Izimbiza Zami Zokonga',
    potsSubtitle: 'Imali ebekelwe eceleni yokudla, isitoko sase-spaza nemfundo',
    newGoalPot: '+ Imbiza Entsha',
    loadStarterPots: 'Faka Izimbiza Zokuqala',
    createFirstPot: 'Qala Imbiza Yakho Yokuqala',
    loadExamplePots: 'Layisha Izimbiza Zesibonelo',
    emptyPotsMsg: 'Awukabi nazo izimbiza. Qala ngisho ngo-R10 kuphela.',
    howItWorks: 'Indlela I-MoniBuddy Ekusiza Ngayo',
    hide: 'Fihla amathiphu',
    show: 'Veza amathiphu',
    addToBuffer: '+ Engeza Esikhwameni Esiphuthumayo',
    deposit: 'Faka Imali',
    withdraw: 'Khipha Imali',
    burnRateTitle: 'Izindleko ZeKhaya Ngeviki',
    burnRateSub: 'Imali edingekayo ngeviki yokudla, itekisi nogesi',
    mashonisaComparison: 'Omashonisa vs Isikhwama Sakho Esiphuthumayo',
    scamGuardTitle: 'Umlindi Wezinkohliso (Scams)',
    scamGuardSub: 'Bheka imilayezo esolisayo ye-SMS noma WhatsApp ngaphandle kokusebenzisa idatha.',
    syncTitle: 'Sebenzisa Ngaphandle Kwedatha (*120*6664#)',
    syncSub: 'Shaya inombolo yamahhala ocingweni lwenkinobho ukubona imali yakho.',
    technicalBriefTitle: 'Indlela Uhlelo Olusebenza Ngayo',
    privacyGuaranteeTitle: 'Ukuvikeleka Kwemininingwane',
    resetDemoData: 'Setha Kabusha Idatha',
    prototypeMode: 'Imodi Yokuhlola',
    navOverview: 'Ukubuka Konke & Izimbiza',
    navIncomeExpenses: 'Imali Engenayo & Ephumayo',
    navBufferCredit: 'Isikhwama & Omashonisa',
    navScamGuard: 'Bheka Izinkohliso',
    nav2gSync: 'Imodi Engenadatha',
    navTechnicalBrief: 'Indlela Ekwakhiwe Ngayo',
    navPrivacyLegal: 'Ubumfihlo Bakho'
  },
  xh: {
    appName: 'MoniBuddy',
    tagline: 'Ukubala Imali Okulula Ngaphandle Kwe-intanethi',
    safeToSpend: 'IMALI EKHUSELEKILEYO UKUSETYENZISWA',
    safeToSpendDesc: 'Yimali ongayisebenzisa namhlanje ungachukumisi imali yokutya okanye eyonxunguphalo.',
    startingBalance: 'Imali oqala ngayo (R)',
    saveStartingBalance: 'Gcina imali',
    startingBalanceHelper: 'Unamali engakanani esandleni ngoku?',
    startingTotal: 'IMALINI YOKUQALA',
    income: 'IMALI ENGENAYO',
    expenses: 'IMALI EPHUMAYO',
    goalSavings: 'IIMBIZA ZOKONGA',
    emergencyBuffer: 'ISIKHUSELI SIKAXAKEKA',
    audioGuide: 'Mamela',
    audioGuideActive: 'Iyafunda...',
    audioGuideTranscript: 'Isikhokelo Selizwi',
    localDemo: 'IDEMO YASEKHAYA',
    goodDayBanner: 'Molo! Imali yakho ihlala ifihlekile kwifowuni yakho kuphela.',
    goodDayBannerSub: 'Akukho intanethi ifunekayo kwaye akukho mntu ubona amanani akho.',
    microSavingsPots: 'Iimbiza Zam Zokonga',
    potsSubtitle: 'Imali ebekelwe ecaleni yokutya, isitokhwe, kunye nezikolo',
    newGoalPot: '+ Imbiza Entsha',
    loadStarterPots: 'Layisha Iimbiza Zokuqala',
    createFirstPot: 'Yenza Imbiza Yokuqala',
    loadExamplePots: 'Layisha Iimbiza Zomzekelo',
    emptyPotsMsg: 'Awukabinazo iimbiza. Qala nangama-R10 kuphela.',
    howItWorks: 'Indlela Ekunceda Ngayo i-MoniBuddy',
    hide: 'Fihla amacebiso',
    show: 'Bonisa amacebiso',
    addToBuffer: '+ Yongeza kuXakeka',
    deposit: 'Faka Imali',
    withdraw: 'Khupha Imali',
    burnRateTitle: 'Iindleko ZeKhaya Ngeviki',
    burnRateSub: 'Imali edingwa likhaya lakho ngeviki ukuthenga ukutya neteksi',
    mashonisaComparison: 'Oomashonisa vs Isikhuseli Sakho SeMali',
    scamGuardTitle: 'Umlindi Wobuqhophololo',
    scamGuardSub: 'Khangela imiyalezo erhanelwayo ngaphakathi kwifowuni yakho ngaphandle kwe-intanethi.',
    syncTitle: 'Sebenzisa Ngaphandle Kwedatha (*120*6664#)',
    syncSub: 'Fowunela ikhowudi yamahala kwifowuni yeqhosha.',
    technicalBriefTitle: 'Indlela EsiSebenza Ngayo',
    privacyGuaranteeTitle: 'Ukhuseleko Lwedatha',
    resetDemoData: 'Cima Idatha',
    prototypeMode: 'Indlela Yovavanyo',
    navOverview: 'Iimbiza & Isishwankathelo',
    navIncomeExpenses: 'Imali Engenayo & Ephumayo',
    navBufferCredit: 'Uxakeka & Oomashonisa',
    navScamGuard: 'Khangela Ubuqhophololo',
    nav2gSync: 'Imo Engenadatha',
    navTechnicalBrief: 'Ulwazi Oluthe vetshe',
    navPrivacyLegal: 'Ubumfihlo'
  },
  st: {
    appName: 'MoniBuddy',
    tagline: 'Ho Bala Chelete ho Bonolo Ntle le Marang-rang',
    safeToSpend: 'CHELETE E BOLOKEHILENG HO SEBELISWA',
    safeToSpendDesc: 'Ena ke chelete eo u ka e sebelisang kajeno ntle le ho tšoara ea lijo kapa ea tšohanyetso.',
    startingBalance: 'Chelete eo u qalang ka eona (R)',
    saveStartingBalance: 'Boloka chelete',
    startingBalanceHelper: 'U na le chelete e kae hona joale?',
    startingTotal: 'KAKARETSO EA PELE',
    income: 'CHELETE E TSENYENG',
    expenses: 'CHELETE E TSOILENG',
    goalSavings: 'LIPITSA TSA POLOKO',
    emergencyBuffer: 'LETLENENG LA TŠOHANYETSO',
    audioGuide: 'Mamela',
    audioGuideActive: 'E ntse e bala...',
    audioGuideTranscript: 'Tataiso ea Mantsoe',
    localDemo: 'DEMO EA MONA',
    goodDayBanner: 'Dumela! Ditaba tsa chelete ya hao di dula fonong ya hao feela.',
    goodDayBannerSub: 'Ha ho hlokahale marang-rang ebile ha ho motho ea bonang linomboro tsa hau.',
    microSavingsPots: 'Lipitsa tsa Ka tsa Poloko',
    potsSubtitle: 'Chelete e beetsweng lijo tsa lapeng, thepa ea spaza le sekolo',
    newGoalPot: '+ Pitsa e Ncha',
    loadStarterPots: 'Kenya Lipitsa tsa Motheo',
    createFirstPot: 'Etsa Pitsa ea Pele',
    loadExamplePots: 'Kenya Lipitsa tsa Mehlala',
    emptyPotsMsg: 'Ha o so be le dipitsa. Qala ka R10 feela.',
    howItWorks: 'Kamoo MoniBuddy e o Thusang Kateng',
    hide: 'Pata likeletso',
    show: 'Bontsha likeletso',
    addToBuffer: '+ Kenya Tšohanyetsong',
    deposit: 'Kenya Chelete',
    withdraw: 'Ntša Chelete',
    burnRateTitle: 'Litsenyehelo tsa Beke tsa Lelapa',
    burnRateSub: 'Chelete e hlokahalang bekeng bakeng sa lijo le thekesi',
    mashonisaComparison: 'Bomashonisa vs Letlole la Hao la Tšohanyetso',
    scamGuardTitle: 'Molebeli oa Bomenemene',
    scamGuardSub: 'Hlahloba melaetsa e belaetsang ya SMS kapa WhatsApp ntle le datha.',
    syncTitle: 'Sebedisa Ntle le Datha (*120*6664#)',
    syncSub: 'Shaya khoutu ya mahala fonong ya dinotlolo.',
    technicalBriefTitle: 'Kamoo e Sebetsang Kateng',
    privacyGuaranteeTitle: 'Tshireletso ya Lekunutu',
    resetDemoData: 'Seta Bocha',
    prototypeMode: 'Mokhoa oa Teko',
    navOverview: 'Lipitsa & Kakaretso',
    navIncomeExpenses: 'Chelete e Kenang le e Tsoang',
    navBufferCredit: 'Tšohanyetso & Bomashonisa',
    navScamGuard: 'Hlahloba Bomenemene',
    nav2gSync: 'Sebedisa Ntle le Datha',
    navTechnicalBrief: 'Kamoo e Ahilweng Kateng',
    navPrivacyLegal: 'Lekunutu'
  },
  af: {
    appName: 'MoniBuddy',
    tagline: 'Maklike Geldbestuur Wat Sonder Data Werk',
    safeToSpend: 'VEILIG OM VANDAG TE SPANDEER',
    safeToSpendDesc: 'Hierdie is die geld wat jy vandag vrylik kan spandeer. Jou kosgeld en noodfondse is reeds veilig eenkant gesit.',
    startingBalance: 'Jou begingeld (R)',
    saveStartingBalance: 'Stoor begingeld',
    startingBalanceHelper: 'Hoeveel totale kontant of bankbalans het jy tans?',
    startingTotal: 'BEGINGELD',
    income: 'GELD IN',
    expenses: 'GELD UIT',
    goalSavings: 'SPAARPOTTE',
    emergencyBuffer: 'NOODFONDS',
    audioGuide: 'Luister',
    audioGuideActive: 'Lees hardop...',
    audioGuideTranscript: 'MoniBuddy Oudiogids',
    localDemo: 'PRIVAAT DEMO',
    goodDayBanner: 'Welkom! Jou geldinligting bly veilig net op jou eie foon.',
    goodDayBannerSub: 'Geen wagwoorde nodig nie, geen data nodig nie, en niemand anders sien jou syfers nie.',
    microSavingsPots: 'My Spaarpotte',
    potsSubtitle: 'Hou geld eenkant vir kos, spaza-voorraad, skool of familiegebeure',
    newGoalPot: '+ Nuwe Pot',
    loadStarterPots: 'Laai Aanvangspotte (Kos, Voorraad, Skool)',
    createFirstPot: 'Skep Jou Eerste Spaarpot',
    loadExamplePots: 'Laai Voorbeeldpotte',
    emptyPotsMsg: 'Jy het nog nie enige spaarpotte nie. Selfs net R10 eenkant sit help jou gesin.',
    howItWorks: 'Hoe MoniBuddy Jou Help',
    hide: 'Versteek wenke',
    show: 'Wys wenke',
    addToBuffer: '+ Voeg by Noodfonds',
    deposit: 'Sit Geld In',
    withdraw: 'Trek Geld Uit',
    burnRateTitle: 'Weeklikse Lewenskoste',
    burnRateSub: 'Hoeveel jou huishouding elke week benodig vir kos, taxi en basiese dinge',
    mashonisaComparison: 'Woekerleners (Mashonisas) vs Jou Eie Noodkussing',
    scamGuardTitle: 'Kroek- en Vervalste Boodskap-toetser',
    scamGuardSub: 'Plak enige verdagte WhatsApp of SMS hier. Ons toets dit direk op jou foon sonder datakoste.',
    syncTitle: 'Gebruik Sonder Data (USSD & 2G)',
    syncSub: 'Kyk hoe jy *120*6664# op enige knoppiefoon gratis kan bel sonder lugtyd.',
    technicalBriefTitle: 'Hoe Dit Agter Die Skerms Werk',
    privacyGuaranteeTitle: 'Jou Privaatheidswaarborg',
    resetDemoData: 'Herstel Data',
    prototypeMode: 'Demo-modus',
    navOverview: 'Oorsig & Potte',
    navIncomeExpenses: 'Geld In & Uit',
    navBufferCredit: 'Noodfonds & Woekerleners',
    navScamGuard: 'Toets Kroekery',
    nav2gSync: 'Geen-Data Modus',
    navTechnicalBrief: 'Hoe Dit Werk',
    navPrivacyLegal: 'Privaatheid & Veiligheid'
  }
};
