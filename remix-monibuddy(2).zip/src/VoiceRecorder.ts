export type VoiceRecognitionLanguage = 'en-ZA' | 'zu-ZA' | 'nso-ZA';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  readonly 0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  readonly results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionErrorEventLike {
  readonly error: string;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface SpeechRecognitionConstructor {
  new (): SpeechRecognitionLike;
}

interface SpeechRecognitionWindow extends Window {
  SpeechRecognition?: SpeechRecognitionConstructor;
  webkitSpeechRecognition?: SpeechRecognitionConstructor;
}

const abortError = () => new DOMException('Voice recording was cancelled.', 'AbortError');

const recognitionErrorMessage = (error: string): string => {
  switch (error) {
    case 'not-allowed':
    case 'service-not-allowed':
      return 'Microphone or speech recognition permission was denied. Check your browser permissions and try again.';
    case 'audio-capture':
      return 'No microphone is available. Connect or enable a microphone and try again.';
    case 'no-speech':
      return 'No speech was detected. Move closer to the microphone and try again.';
    case 'network':
      return 'Speech recognition could not reach its recognition service. Check your connection and try again.';
    case 'language-not-supported':
      return 'This browser does not support speech recognition for the selected language.';
    default:
      return `Speech recognition failed (${error}). Please try again or enter the amount manually.`;
  }
};

export const recognizeSpeech = (
  language: VoiceRecognitionLanguage,
  signal: AbortSignal
): Promise<string> => {
  const speechWindow = window as SpeechRecognitionWindow;
  const Recognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;

  if (!Recognition) {
    return Promise.reject(
      new Error('Speech recognition is not supported in this browser. Try a supported browser or enter the amount manually.')
    );
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    return Promise.reject(
      new Error('Microphone access is not available in this browser. Use HTTPS or enter the amount manually.')
    );
  }

  if (signal.aborted) {
    return Promise.reject(abortError());
  }

  return new Promise((resolve, reject) => {
    let stream: MediaStream | null = null;
    let recognition: SpeechRecognitionLike | null = null;
    let settled = false;
    let transcript = '';

    const cleanup = () => {
      signal.removeEventListener('abort', handleAbort);
      stream?.getTracks().forEach(track => track.stop());
      stream = null;
      if (recognition) {
        recognition.onresult = null;
        recognition.onerror = null;
        recognition.onend = null;
      }
    };

    const finish = (error?: Error, result?: string) => {
      if (settled) return;
      settled = true;
      cleanup();
      if (error) {
        reject(error);
      } else if (result) {
        resolve(result);
      } else {
        reject(new Error('No speech was transcribed. Please try again or enter the amount manually.'));
      }
    };

    const handleAbort = () => {
      try {
        recognition?.stop();
      } finally {
        finish(abortError());
      }
    };

    signal.addEventListener('abort', handleAbort, { once: true });

    // Web Speech API cannot accept this stream as input. These constraints explicitly
    // apply to this microphone request, but cannot configure the recognition engine.
    navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false
      }
    }).then(rawStream => {
      stream = rawStream;
      if (signal.aborted) {
        rawStream.getTracks().forEach(track => track.stop());
        return;
      }

      recognition = new Recognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = language;
      recognition.onresult = event => {
        transcript = event.results[0]?.[0]?.transcript.trim() ?? '';
        finish(undefined, transcript);
      };
      recognition.onerror = event => finish(new Error(recognitionErrorMessage(event.error)));
      recognition.onend = () => {
        if (!settled) finish(undefined, transcript);
      };

      try {
        recognition.start();
      } catch (error) {
        finish(error instanceof Error ? error : new Error('Unable to start speech recognition.'));
      }
    }).catch(error => {
      const message = error instanceof DOMException && error.name === 'NotAllowedError'
        ? 'Microphone permission was denied. Allow microphone access in your browser and try again.'
        : error instanceof DOMException && error.name === 'NotFoundError'
          ? 'No microphone is available. Connect or enable a microphone and try again.'
          : error instanceof Error
            ? error.message
            : 'Unable to access the microphone. Please try again.';
      finish(new Error(message));
    });
  });
};
