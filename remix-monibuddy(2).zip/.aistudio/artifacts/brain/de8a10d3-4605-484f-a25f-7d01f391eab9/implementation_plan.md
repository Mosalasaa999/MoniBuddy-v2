# Context-Aware Defensive Shield — Negative Testing & Rule Hardening Plan

Deliver a comprehensive negative testing and rule-refinement suite for MoniBuddy's offline Scam Detector, combining an anti-evasion text sanitizer, false-positive allowlist guards, tiered confidence friction (`VoiceConfirmationModal` for $\ge 0.7$), automated regression runners (CLI + in-app), and an interactive step-by-step manual QA walkthrough.

## User Review & Critical Decisions

> [!IMPORTANT]
> Please review the confirmed negative-testing categories and rule-refinement thresholds below before we implement the test harness and parser hardening.

- **Confirmed Scope (All 4 Negative Test Categories)**:
  1. *False-Positive Resilience*: Legitimate bank OTP self-warnings ("Never share your OTP with anyone"), official SASSA grant payment notifications, standard NCR loan statements, and compliant agent cash-out fees within tariff tiers must not trigger high-risk blocks.
  2. *Adversarial Evasion & Obfuscation*: Leetspeak (`p@y pr0c3ss1ng f33`, `S@SS@`), zero-width Unicode characters (`f\u200be\u200be`), punctuation splitting (`f-e-e`, `O.T.P`), and vernacular slang variants must be caught via pre-parse sanitization + expanded alias matching.
  3. *Malformed & Extreme Telemetry*: Empty/whitespace inputs, `NaN`, `Infinity`, negative ZAR amounts, negative account ages, and huge integer spikes must degrade safely without runtime exceptions or out-of-range scores outside `[0.0, 1.0]`.
  4. *Long-Payload Stress & Unicode Boundaries*: 25KB+ padded messages, repeated emoji clusters, and mixed isiZulu/Sepedi diacritics must execute deterministically in `< 25ms` without ReDoS backtracking.
- **Confirmed Execution Surface (Recommended Default)**: Provide **both** an automated CLI + in-app negative/positive regression runner **and** a collapsible step-by-step manual negative-testing guide inside **Check Scams** so anyone can reproduce and audit every test case by hand.
- **Confirmed Rule-Refinement Strategy**:
  - *Compound Proximity & Allowlists*: Require compound threat context, suppress alerts on defensive bank warnings ("never share your PIN/OTP"), and cross-check agent fee mentions against official tariff tiers before flagging extortion.
  - *Tiered Friction Scale (`0.0 – 1.0`)*:
    - `0.00 – 0.29` (**Safe**): Clean pass with quiet educational reminder.
    - `0.30 – 0.69` (**Low / Caution Risk**): Passive inline micro-copy (e.g., *"Check official cash-out fee schedule"*) without blocking the user.
    - `0.70 – 1.00` (**High / Critical Risk**): Trigger a dedicated **`VoiceConfirmationModal`** requiring explicit user acknowledgement + localized spoken warning playback (English, isiZulu, Sepedi) before proceeding, alongside optional **Shadow Mode** rule logging for newly staged rules.

---

## 1. Overview & Core Concept

- **What It Does**: Systematically stress-tests the offline scam detector against benign lookalikes, adversarial obfuscation, corrupted telemetry, and oversized Unicode inputs—while hardening the parser so genuine township users never suffer false alarms on real bank/SASSA SMSs and scammers cannot slip past filters using `f.e.e` or `0TP` tricks.
- **Target Audience / Persona**:
  - *Everyday MoniBuddy Users*: Protected from panic scams and advance-fee mashonisa traps without getting blocked when checking real Capitec, FNB, Boxer, or SASSA messages.
  - *Security / QA Reviewers*: Equipped with 1-click automated negative test suites and a clear step-by-step manual verification playbook right inside the workspace.
- **Key Value**: Eliminates brittle single-keyword false positives while closing common leetspeak/punctuation evasion gaps—all 100% offline and POPIA-aligned.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Real-Time Tiered Scam Check**: As the user pastes a message or adjusts transaction telemetry, the analyzer normalizes the input and renders one of three distinct postures:
     - *Safe (`< 0.30`)*: Calm emerald confirmation card.
     - *Passive Caution (`0.30 – 0.69`)*: Non-blocking amber guidance strip with specific tariff/verification micro-copy.
     - *High-Risk Intercept (`>= 0.70`)*: Prominent rose alert banner + interactive **"Test High-Risk Transfer Intercept"** action that launches the **`VoiceConfirmationModal`** with spoken warning playback and mandatory cooling-off confirmation.
  2. **Automated Negative & Regression Test Runner**: Users click **"Run Full Positive & Negative Suite"** to execute all positive threat checks and all 4 negative test categories live, filterable by category (*All*, *False Positives*, *Evasion & Leetspeak*, *Malformed Inputs*, *Stress & Latency*) with tabular execution times (`ms`) and expected-vs-actual risk scores.
  3. **Shadow Mode Toggle**: A clean segmented switch lets reviewers toggle staged experimental rules between *Shadow (Log-Only)* and *Active Enforcement* to inspect flag rates without altering live risk blocks.
  4. **Step-by-Step Manual Negative Testing Guide**: A structured, collapsible QA playbook with 1-click **"Load into Inspector"** buttons for each manual step so the user can also perform and verify negative tests manually.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: High-trust, utilitarian financial-inclusion dashboard matching MoniBuddy's crisp workspace layout.
  - *Color Palette & Mood*:
    - Dominant 60% neutral canvas (`bg-slate-50` workspace, `bg-white` single-elevation cards).
    - 30% structural slate borders and muted hierarchy (`border-slate-200`, `text-slate-600`).
    - 10% semantic state accents paired with explicit text labels and icons: Emerald (`#047857`) for verified safe/pass, Amber (`#D97706`) for passive `0.30–0.69` caution micro-copy, and Rose (`#BE123C`) for `>= 0.70` high-risk blocks.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` for crisp headers, controls, and plain-language guidance; `JetBrains Mono` (`font-mono tabular-nums`) strictly enforced on all risk scores (`0.00`–`1.00`), tariff caps, execution latencies (`ms`), and test IDs. Zero pill enclosures on static metadata—using clean inline `·` typographic separators.
  - *Component Styling & Layout*: Single-elevation bordered surfaces (`rounded-2xl border border-slate-200 bg-white`), compact high-density test result rows (`36px–44px`), and clean segmented filter tabs with `whitespace-nowrap shrink-0`.

- **Interactive Feedback & Motion**:
  - Instant `< 150ms` client-side evaluation and filter switching.
  - `VoiceConfirmationModal` enters smoothly via opacity/transform transition, immediately offering 1-tap trilingual Web Speech API playback (`en`, `zu`, `nso`) and explicit *"Cancel & Block Scam"* vs *"I Verified Directly — Proceed"* actions.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Track Text Evaluation (Raw + De-Obfuscated Stream)**
  - *Chosen Approach*: Run a deterministic pre-processing sanitizer (`normalizeObfuscatedText`) that strips zero-width characters, collapses intra-word punctuation (`f-e-e`, `O.T.P` $\rightarrow$ `fee`, `otp`), maps leetspeak (`0`$\rightarrow$`o`, `1`$\rightarrow$`i`, `3`$\rightarrow$`e`, `@`$\rightarrow$`a`, `$`$\rightarrow$`s`), and expands vernacular slang aliases (`SlangDictionary`) before matching compound proximity rules—while bounded to a safe character window per clause so regexes never backtrack catastrophically on 25KB+ inputs.
  - *Why*: Catches adversarial spelling tricks without corrupting numeric ZAR currency parsing on the original text.
  - *Alternatives Considered*: Fuzzy Levenshtein matching on every word, which increases CPU cost on low-end budget Android phones and raises false-positive collisions on short isiZulu/Sepedi words.

- **Decision 2: Negative Context Allowlists Over Raw Keyword Suppression**
  - *Chosen Approach*: Introduce explicit defensive-context filters (e.g., bank security footers stating *"Capitec will NEVER ask for your PIN or OTP"* or *"Do not share your OTP"*) and compliant agent fee verification (`agentFeeChargedZar <= officialMaxFeeZar`) so educational warnings and fair fees subtract/suppress false triggers rather than blinding the OTP or agent-fee detectors globally.
  - *Why*: Real South African bank SMSs almost always contain the words *"OTP"*, *"PIN"*, or *"fraud helpline"*; naive keyword rules falsely flag legitimate bank alerts.

- **Decision 3: Tiered Friction (`0.30–0.69` Passive vs `>= 0.70` VoiceConfirmationModal) + Shadow Mode**
  - *Chosen Approach*: Align severity thresholds directly to the `0.0–1.0` confidence scale (`< 0.30` Safe, `0.30–0.69` Low/Passive Micro-Copy, `>= 0.70` High-Risk `VoiceConfirmationModal`), plus an optional `shadowRules` telemetry log array on every evaluation.
  - *Why*: Prevents alert fatigue on borderline single-signal anomalies (such as paying a newly added spaza contact R350) while enforcing unmistakable spoken + modal friction on high-confidence scams.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌────────────────────────────────────────────────────────────────────────────┐
│                   Input & Telemetry Sanitization Layer                     │
│  ┌──────────────────────────────┐    ┌──────────────────────────────────┐  │
│  │ Text De-Obfuscator           │    │ Telemetry Boundary Guard         │  │
│  │ • Strip zero-width Unicode   │    │ • Sanitize NaN / Infinity / < 0  │  │
│  │ • Collapse f.e.e / O-T-P     │    │ • Clamp extreme numeric spikes   │  │
│  │ • Map leetspeak (@->a, 0->o) │    │ • Validate official fee tiers    │  │
│  │ • Expand SlangDictionary     │    └─────────────────┬────────────────┘  │
│  └──────────────┬───────────────┘                      │                   │
└─────────────────┼──────────────────────────────────────┼───────────────────┘
                  ▼                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│              Hardened Offline Scam Parser & Deduction Engine               │
│  • Compound Proximity Rules (fee + advance/release/voucher)                │
│  • Benign Context Allowlist (Bank "NEVER share OTP" & compliant tariffs)   │
│  • Shadow-Mode Rule Observer (log-only flag tracking without blocking)     │
│  • Tiered Confidence Scoring:                                              │
│      [0.00 - 0.29] SAFE  ──► Clean Pass                                    │
│      [0.30 - 0.69] LOW   ──► Passive UI Micro-Copy ("Check fee schedule")  │
│      [0.70 - 1.00] HIGH  ──► Trigger VoiceConfirmationModal + Dispute JSON │
└─────────────────┬──────────────────────────────────────┬───────────────────┘
                  ▼                                      ▼
┌─────────────────────────────────────┐  ┌───────────────────────────────────┐
│   Check Scams Interactive Shield    │  │ Negative & Regression Test Suite  │
│  • Live Message + Telemetry Lab     │  │ • False-Positive Bank/SASSA Cases │
│  • Shadow Mode Toggle               │  │ • Leetspeak / Zero-Width Evasion  │
│  • VoiceConfirmationModal (>= 0.7)  │  │ • Malformed / NaN / Negative Data │
│  • Step-by-Step Manual QA Playbook  │  │ • 25KB+ Stress & Emoji Latency    │
└─────────────────────────────────────┘  └───────────────────────────────────┘
```

- **Data Model & State**:
  - **Sanitized Normalization Output**: Preserves both `rawText` and `deobfuscatedText` alongside detected obfuscation tactics (e.g., zero-width injection or leetspeak substitution, which themselves contribute a subtle evasion signal when paired with financial requests).
  - **Tiered Evaluation Contract**: Extends parser evaluation with `frictionTier` (`'NONE' | 'PASSIVE_MICROCOPY' | 'VOICE_CONFIRMATION_MODAL'`), `passiveMicroCopy`, `shadowSignals` (for rules running in passive log-only mode), and `executionTimeMs`.
  - **Categorized Test Case Schema**: Each automated test case records `id`, `category` (`'positive_baseline' | 'false_positive' | 'evasion_bypass' | 'malformed_telemetry' | 'stress_unicode'`), `inputSummary`, `expectedOutcome`, `actualOutcome`, `durationMs`, and `passed`.

- **Interactive Component & State Mapping**:
  - **Live Inspector & Shadow Mode Toggle**: Editing text, toggling telemetry checkboxes, or enabling *Shadow Mode Promotion* immediately recomputes `deduceScamAndBuildIncidentReport` and updates the inline passive banner or high-risk trigger state.
  - **VoiceConfirmationModal (`>= 0.70` Risk)**: Opens when simulating a transfer on high-risk inputs, displaying deduced scam template, matched triggers, trilingual audio warning button (`Play Warning in English / isiZulu / Sepedi`), and explicit confirmation state transitions (*Block & Report* vs *Acknowledge Risk*).
  - **Categorized Test Runner & Manual QA Playbook**: Clicking *Run Suite* executes all ~20 positive + negative unit tests synchronously with `performance.now()` timing, populates filterable category tabs, and lets users click *"Load Case"* on any test or manual guide step to inspect its exact behavior in the live form.
