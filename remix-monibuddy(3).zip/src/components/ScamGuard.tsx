import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  TransactionOperationType,
  TransactionTelemetryPayload,
  getOfficialMaxAgentFeeZar
} from '../scamParser';
import {
  SupportedWarningLanguage,
  deduceScamAndBuildIncidentReport
} from '../scamDeductionEngine';
import { VoiceConfirmationModal } from './VoiceConfirmationModal';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  PhoneCall,
  Copy,
  Check,
  Volume2,
  VolumeX,
  FileWarning,
  SlidersHorizontal,
  Download
} from 'lucide-react';

interface ThreatPreset {
  readonly title: string;
  readonly text: string;
  readonly telemetry: TransactionTelemetryPayload;
}

interface InspectableScenarioPayload {
  readonly transcript: string;
  readonly telemetry?: TransactionTelemetryPayload;
}

const PRESET_SCENARIOS: readonly ThreatPreset[] = [
  {
    title: 'Predatory Loan "Admin Fee"',
    text: 'Guaranteed instant loan of R10,000 approved with no credit check! Deposit R150 processing fee first via 1Voucher / Shoprite MoneyMarket to release your cash today.',
    telemetry: {
      transactionId: 'TX-LOAN-901',
      recipientId: '071 999 8821',
      recipientName: 'QuickCash Micro-Loans',
      amountZar: 150,
      recipientAccountAgeDays: 2,
      isNewlyAddedRecipient: true,
      recentTransferCountLastHour: 1,
      operationType: 'loan_fee_payment',
      isRegisteredCreditProvider: false
    }
  },
  {
    title: 'Leetspeak Evasion Scam',
    text: 'Gu@r@nt33d 1nst@nt l0@n! P@y R150 pr0c3ss1ng f-e-e f1rst via 1Voucher to r3l3@s3 your R5000 cash.',
    telemetry: {
      transactionId: 'TX-EV-201',
      recipientId: '060 771 8821',
      recipientName: 'FastLend SA',
      amountZar: 150,
      recipientAccountAgeDays: 1,
      isNewlyAddedRecipient: true,
      recentTransferCountLastHour: 1,
      operationType: 'loan_fee_payment',
      isRegisteredCreditProvider: false
    }
  },
  {
    title: 'Legitimate Bank OTP (False-Positive Test)',
    text: 'Capitec: Your One-Time PIN (OTP) for electricity purchase of R100.00 is 482910. Capitec will NEVER ask for your PIN or OTP. Never share your OTP with anyone.',
    telemetry: {
      transactionId: 'TX-SAFE-OTP',
      recipientId: 'ESKOM-PREPAID',
      recipientName: 'Prepaid Electricity',
      amountZar: 100,
      recipientAccountAgeDays: 900,
      isNewlyAddedRecipient: false,
      recentTransferCountLastHour: 1,
      operationType: 'merchant_payment'
    }
  },
  {
    title: 'Compliant R10 Agent Cash-Out (Allowlist)',
    text: 'Withdrew R400 at spaza kiosk agent, standard R10 cash-out fee charged on receipt.',
    telemetry: {
      transactionId: 'TX-SAFE-CSH',
      recipientId: 'AGENT-REGISTERED-08',
      recipientName: 'Registered Spaza Till',
      amountZar: 400,
      recipientAccountAgeDays: 420,
      isNewlyAddedRecipient: false,
      recentTransferCountLastHour: 1,
      operationType: 'cash_out',
      agentFeeChargedZar: 10
    }
  },
  {
    title: 'Newly Added Stokvel (Passive Tier 0.32)',
    text: 'Monthly stokvel contribution for November groceries.',
    telemetry: {
      transactionId: 'TX-PASSIVE-01',
      recipientId: '083 555 1290',
      recipientName: 'MaMkhize Stokvel Treasurer',
      amountZar: 350,
      recipientAccountAgeDays: 400,
      isNewlyAddedRecipient: true,
      recentTransferCountLastHour: 1,
      operationType: 'p2p_transfer'
    }
  },
  {
    title: 'Agent Fee & PIN Extortion',
    text: 'Spaza kiosk agent says system offline fee applies: pay R45 extra cash-out fee to withdraw and read out your Cash-Send PIN to the teller.',
    telemetry: {
      transactionId: 'TX-CSH-772',
      recipientId: 'AGENT-KIOSK-19',
      recipientName: 'Corner Kiosk Cash-Out',
      amountZar: 400,
      recipientAccountAgeDays: 180,
      isNewlyAddedRecipient: false,
      recentTransferCountLastHour: 1,
      operationType: 'cash_out',
      agentFeeChargedZar: 45
    }
  }
];

export const ScamGuard: React.FC = () => {
  const { t, language, speakText, stopSpeaking, isSpeaking } = useApp();

  const [inputText, setInputText] = useState<string>(PRESET_SCENARIOS[0].text);
  const [showTelemetryControls, setShowTelemetryControls] = useState<boolean>(true);
  const [promoteShadowRules, setPromoteShadowRules] = useState<boolean>(false);

  // Transaction Telemetry State
  const [recipientId, setRecipientId] = useState<string>(PRESET_SCENARIOS[0].telemetry.recipientId);
  const [recipientName, setRecipientName] = useState<string>(
    PRESET_SCENARIOS[0].telemetry.recipientName ?? ''
  );
  const [amountZar, setAmountZar] = useState<number>(PRESET_SCENARIOS[0].telemetry.amountZar);
  const [recipientAccountAgeDays, setRecipientAccountAgeDays] = useState<number>(
    PRESET_SCENARIOS[0].telemetry.recipientAccountAgeDays
  );
  const [isNewlyAddedRecipient, setIsNewlyAddedRecipient] = useState<boolean>(
    PRESET_SCENARIOS[0].telemetry.isNewlyAddedRecipient
  );
  const [recentTransferCountLastHour, setRecentTransferCountLastHour] = useState<number>(
    PRESET_SCENARIOS[0].telemetry.recentTransferCountLastHour
  );
  const [operationType, setOperationType] = useState<TransactionOperationType>(
    PRESET_SCENARIOS[0].telemetry.operationType ?? 'p2p_transfer'
  );
  const [agentFeeChargedZar, setAgentFeeChargedZar] = useState<number>(0);
  const [isRegisteredCreditProvider, setIsRegisteredCreditProvider] = useState<boolean>(false);

  // Audio script language, Modals & Incident Report visibility
  const [warningLang, setWarningLang] = useState<SupportedWarningLanguage>(
    language === 'zu' ? 'zu' : 'en'
  );
  const [voiceModalOpen, setVoiceModalOpen] = useState<boolean>(false);
  const [transferDecisionBanner, setTransferDecisionBanner] = useState<string | null>(null);
  const [showIncidentReport, setShowIncidentReport] = useState<boolean>(false);
  const [incidentSubmitted, setIncidentSubmitted] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const loadInspectablePayload = (payload: InspectableScenarioPayload) => {
    setInputText(payload.transcript);
    const tel = payload.telemetry;
    if (tel) {
      setRecipientId(tel.recipientId || 'UNSPECIFIED');
      setRecipientName(tel.recipientName ?? '');
      setAmountZar(Number.isFinite(tel.amountZar) ? Math.max(0, tel.amountZar) : 0);
      setRecipientAccountAgeDays(
        Number.isFinite(tel.recipientAccountAgeDays) && tel.recipientAccountAgeDays >= 0
          ? tel.recipientAccountAgeDays
          : 365
      );
      setIsNewlyAddedRecipient(Boolean(tel.isNewlyAddedRecipient));
      setRecentTransferCountLastHour(
        Number.isFinite(tel.recentTransferCountLastHour)
          ? Math.max(0, tel.recentTransferCountLastHour)
          : 0
      );
      setOperationType(tel.operationType ?? 'p2p_transfer');
      setAgentFeeChargedZar(
        typeof tel.agentFeeChargedZar === 'number' && Number.isFinite(tel.agentFeeChargedZar)
          ? Math.max(0, tel.agentFeeChargedZar)
          : 0
      );
      setIsRegisteredCreditProvider(tel.isRegisteredCreditProvider ?? true);
    } else {
      setAmountZar(0);
      setIsNewlyAddedRecipient(false);
      setRecentTransferCountLastHour(0);
      setOperationType('p2p_transfer');
      setAgentFeeChargedZar(0);
    }
    setIncidentSubmitted(false);
    setTransferDecisionBanner(null);
  };

  const telemetryPayload = useMemo((): TransactionTelemetryPayload => {
    return {
      recipientId: recipientId.trim() || 'UNSPECIFIED',
      recipientName: recipientName.trim() || undefined,
      amountZar: Number.isFinite(amountZar) ? Math.max(0, amountZar) : 0,
      recipientAccountAgeDays: Math.max(0, recipientAccountAgeDays),
      isNewlyAddedRecipient,
      recentTransferCountLastHour: Math.max(0, recentTransferCountLastHour),
      operationType,
      agentFeeChargedZar:
        operationType === 'cash_out' || operationType === 'cash_in'
          ? Math.max(0, agentFeeChargedZar)
          : undefined,
      isRegisteredCreditProvider:
        operationType === 'loan_fee_payment' ? isRegisteredCreditProvider : undefined
    };
  }, [
    recipientId,
    recipientName,
    amountZar,
    recipientAccountAgeDays,
    isNewlyAddedRecipient,
    recentTransferCountLastHour,
    operationType,
    agentFeeChargedZar,
    isRegisteredCreditProvider
  ]);

  const deduction = useMemo(() => {
    return deduceScamAndBuildIncidentReport({
      transcriptOrMessage: inputText,
      telemetry: telemetryPayload,
      preferredLanguage: warningLang,
      evaluationOptions: { promoteShadowRules }
    });
  }, [inputText, telemetryPayload, warningLang, promoteShadowRules]);

  const handleSimulateTransferGate = () => {
    setTransferDecisionBanner(null);
    if (deduction.requiresVoiceConfirmationModal) {
      setVoiceModalOpen(true);
    } else if (deduction.frictionTier === 'PASSIVE_MICROCOPY') {
      setTransferDecisionBanner(
        `Allowed with passive caution (${deduction.evaluation.riskScore.toFixed(
          2
        )}): ${deduction.evaluation.passiveMicroCopy}`
      );
    } else {
      setTransferDecisionBanner(
        `Clean pass (${deduction.evaluation.riskScore.toFixed(
          2
        )}): No modal friction triggered for this legitimate input.`
      );
    }
  };

  const copyToClipboard = (key: string, value: string) => {
    navigator.clipboard.writeText(value);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const formatOperationLabel = (op: string): string => {
    switch (op) {
      case 'loan_fee_payment':
        return 'Loan / Advance Fee Request';
      case 'cash_out':
        return 'Agent Cash-Out';
      case 'cash_in':
        return 'Agent Cash-In';
      case 'merchant_payment':
        return 'Retail Merchant Payment';
      default:
        return 'Person-to-Person Transfer';
    }
  };

  const formatProtectionLabel = (tier: string): string => {
    if (tier === 'VOICE_CONFIRMATION_MODAL') return 'Spoken warning & payment hold';
    if (tier === 'PASSIVE_MICROCOPY') return 'Caution notice';
    return 'No restrictions';
  };

  const formatObfuscationLabel = (indicator: string): string => {
    switch (indicator) {
      case 'zero_width_characters':
        return 'Hidden invisible characters used to disguise words';
      case 'delimited_char_splitting':
        return 'Broken-up letters (such as f-e-e or O T P) used to hide scam words';
      case 'leetspeak_homoglyph_substitution':
        return 'Numbers or symbols swapped for letters (such as l0@n or p@y)';
      default:
        return indicator.replace(/_/g, ' ');
    }
  };

  const formatZAR = (amount: number) =>
    'R ' +
    amount.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });

  const buildPlainTextReport = (): string => {
    const r = deduction.incidentReport;
    const formattedDate = new Date(r.createdAtIso).toLocaleString('en-ZA', {
      dateStyle: 'medium',
      timeStyle: 'short'
    });
    const lines = [
      'MONIBUDDY FRAUD & DISPUTE REPORT',
      `Reference: ${r.reportId}`,
      `Date: ${formattedDate}`,
      '',
      '1. INCIDENT SUMMARY',
      `Assessment: ${r.deducedScamTitle}`,
      `Risk Level: ${Math.round(r.riskScore * 100)}% (${r.severity})`,
      `Recommendation: ${
        r.recommendedBlockTransfer
          ? 'DO NOT SEND MONEY — Block this payment immediately'
          : 'Proceed with normal verification'
      }`,
      '',
      '2. PAYMENT & RECIPIENT DETAILS',
      `Recipient Name: ${r.transactionMetadata.recipientName}`,
      `Recipient Number / ID: ${r.transactionMetadata.recipientId}`,
      `Amount Involved: ${formatZAR(r.transactionMetadata.amountZar)}`,
      ...(r.transactionMetadata.agentFeeChargedZar !== null
        ? [`Agent Fee Requested: ${formatZAR(r.transactionMetadata.agentFeeChargedZar)}`]
        : []),
      `Payment Type: ${formatOperationLabel(r.transactionMetadata.operationType)}`,
      `Account History: ${
        r.transactionMetadata.isNewlyAddedRecipient ? 'Newly added (<24 hours)' : 'Existing contact'
      }, ${r.transactionMetadata.recipientAccountAgeDays} days old`,
      '',
      '3. WHY THIS WAS FLAGGED',
      ...(deduction.evaluation.signals.length > 0
        ? deduction.evaluation.signals.map((s, idx) => `${idx + 1}. ${s.description}`)
        : ['No high-risk scam patterns were detected in this message.']),
      '',
      '4. RECOMMENDED NEXT STEPS',
      ...r.localizedActionSteps.map((step, idx) => `${idx + 1}. ${step}`),
      '',
      `Official Authority: ${r.reportingAuthority}`,
      `Free Helpline: ${r.reportingHotline}`
    ];
    return lines.join('\n');
  };

  const handleDownloadReportSlip = () => {
    const textContent = buildPlainTextReport();
    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${deduction.incidentReport.reportId.toLowerCase()}-report.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const officialMaxFee = getOfficialMaxAgentFeeZar(amountZar);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            {t.scamGuardTitle}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Context-Aware Defensive Shield · Offline Scam, Loan Fee &amp; Agent Protection
          </p>
        </div>

        {/* Controls: Shadow Mode & Warning Language */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setPromoteShadowRules(false)}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                !promoteShadowRules
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Shadow (Log-Only)
            </button>
            <button
              type="button"
              onClick={() => setPromoteShadowRules(true)}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                promoteShadowRules
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Promote Shadow Rules
            </button>
          </div>

          <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1">
            {(
              [
                { code: 'en', label: 'English' },
                { code: 'zu', label: 'isiZulu' },
                { code: 'nso', label: 'Sepedi' }
              ] as const
            ).map(item => (
              <button
                key={item.code}
                type="button"
                onClick={() => setWarningLang(item.code)}
                className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  warningLang === item.code
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Defensive Shield Evaluator */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs space-y-5">
        {/* Preset Scenarios */}
        <div>
          <span className="text-xs font-semibold text-slate-600">
            Check common message examples:
          </span>
          <div className="mt-2 flex flex-wrap gap-2">
            {PRESET_SCENARIOS.map(preset => (
              <button
                key={preset.title}
                type="button"
                onClick={() =>
                  loadInspectablePayload({
                    transcript: preset.text,
                    telemetry: preset.telemetry
                  })
                }
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-900 transition-colors whitespace-nowrap"
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        {/* Message / Transcript Input */}
        <div>
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-800">
              SMS, WhatsApp Message, or Spoken Transcript
            </label>
            {inputText && (
              <button
                type="button"
                onClick={() => {
                  setInputText('');
                  setTransferDecisionBanner(null);
                }}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                Clear text
              </button>
            )}
          </div>
          <textarea
            rows={3}
            value={inputText}
            onChange={e => {
              setInputText(e.target.value);
              setIncidentSubmitted(false);
              setTransferDecisionBanner(null);
            }}
            placeholder="Paste suspicious SMS, benign bank OTP notice, or leetspeak obfuscated scam..."
            className="mt-1.5 w-full rounded-xl border border-slate-200 p-3.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden focus:ring-2 focus:ring-emerald-600/20 leading-relaxed"
          />
        </div>

        {/* Transaction Telemetry Inspector */}
        <div className="pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-slate-600" />
              <span className="text-xs font-bold text-slate-900">
                Transaction Telemetry Context (Offline Heuristic Inputs)
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowTelemetryControls(prev => !prev)}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
            >
              {showTelemetryControls ? 'Hide telemetry' : 'Edit telemetry'}
            </button>
          </div>

          {showTelemetryControls && (
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Recipient ID / Phone
                </label>
                <input
                  type="text"
                  value={recipientId}
                  onChange={e => setRecipientId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Transfer / Cash-Out Amount (ZAR)
                </label>
                <input
                  type="number"
                  min="0"
                  step="10"
                  value={amountZar}
                  onChange={e => setAmountZar(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Recipient Account Age (Days)
                </label>
                <input
                  type="number"
                  min="0"
                  value={recipientAccountAgeDays}
                  onChange={e => setRecipientAccountAgeDays(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Transfers in Last Hour (Velocity)
                </label>
                <input
                  type="number"
                  min="0"
                  value={recentTransferCountLastHour}
                  onChange={e => setRecentTransferCountLastHour(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Operation Type
                </label>
                <select
                  value={operationType}
                  onChange={e => setOperationType(e.target.value as TransactionOperationType)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                >
                  <option value="p2p_transfer">Person-to-Person Transfer</option>
                  <option value="loan_fee_payment">Loan / Advance Fee Request</option>
                  <option value="cash_out">Agent Cash-Out</option>
                  <option value="cash_in">Agent Cash-In</option>
                  <option value="merchant_payment">Retail Merchant Payment</option>
                </select>
              </div>

              {(operationType === 'cash_out' || operationType === 'cash_in') && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600">
                    Agent Fee Demanded (Official max: R{officialMaxFee})
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={agentFeeChargedZar}
                    onChange={e => setAgentFeeChargedZar(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                  />
                </div>
              )}

              {operationType === 'loan_fee_payment' && (
                <div className="flex items-end pb-1.5">
                  <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!isRegisteredCreditProvider}
                      onChange={e => setIsRegisteredCreditProvider(!e.target.checked)}
                      className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-600"
                    />
                    <span>Unregistered Lender (Non-NCR)</span>
                  </label>
                </div>
              )}

              <div className="flex items-end pb-1.5">
                <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isNewlyAddedRecipient}
                    onChange={e => setIsNewlyAddedRecipient(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-600"
                  />
                  <span>Newly added recipient (&lt;24h)</span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Tiered Deduction Result Banner */}
        <div
          className={`rounded-2xl border p-5 space-y-4 ${
            deduction.frictionTier === 'VOICE_CONFIRMATION_MODAL'
              ? 'border-rose-300 bg-rose-50/70'
              : deduction.frictionTier === 'PASSIVE_MICROCOPY'
              ? 'border-amber-300 bg-amber-50/70'
              : 'border-emerald-300 bg-emerald-50/70'
          }`}
        >
          {/* Top Status Row */}
          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              {deduction.frictionTier === 'VOICE_CONFIRMATION_MODAL' ? (
                <ShieldAlert className="h-6 w-6 text-rose-600 shrink-0 mt-0.5" />
              ) : deduction.frictionTier === 'PASSIVE_MICROCOPY' ? (
                <AlertTriangle className="h-6 w-6 text-amber-600 shrink-0 mt-0.5" />
              ) : (
                <ShieldCheck className="h-6 w-6 text-emerald-600 shrink-0 mt-0.5" />
              )}
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                  {deduction.localizedTitle}
                </h3>
                <div className="mt-0.5 text-xs text-slate-600 font-mono tabular-nums">
                  Risk: {Math.round(deduction.evaluation.riskScore * 100)}% ·{' '}
                  {formatProtectionLabel(deduction.frictionTier)}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleSimulateTransferGate}
                className={`rounded-xl px-3.5 py-2 text-xs font-bold text-white transition-colors whitespace-nowrap shrink-0 ${
                  deduction.requiresVoiceConfirmationModal
                    ? 'bg-rose-700 hover:bg-rose-800'
                    : 'bg-emerald-700 hover:bg-emerald-800'
                }`}
              >
                {deduction.requiresVoiceConfirmationModal
                  ? 'Simulate Transfer (Triggers Voice Modal)'
                  : 'Simulate Transfer Gate'}
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isSpeaking) {
                    stopSpeaking();
                  } else {
                    speakText(deduction.activeAudioScript);
                  }
                }}
                className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
              >
                {isSpeaking ? (
                  <>
                    <VolumeX className="h-4 w-4 text-rose-600" />
                    <span>Stop Voice</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="h-4 w-4 text-emerald-700" />
                    <span>Play Warning ({warningLang.toUpperCase()})</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setShowIncidentReport(prev => !prev)}
                className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              >
                <FileWarning className="h-4 w-4" />
                <span>{showIncidentReport ? 'Hide Report' : 'Report Issue'}</span>
              </button>
            </div>
          </div>

          {/* Transfer Gate Simulation Outcome */}
          {transferDecisionBanner && (
            <div className="rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-slate-800">
              {transferDecisionBanner}
            </div>
          )}

          {/* Passive Micro-Copy Strip (0.30 - 0.69 or Verified Compliant Fee) */}
          {deduction.evaluation.passiveMicroCopy && (
            <div className="rounded-xl bg-white/90 border border-black/10 px-3.5 py-2.5 text-xs font-semibold text-slate-900">
              {deduction.evaluation.passiveMicroCopy}
            </div>
          )}

          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
            {deduction.localizedSummary}
          </p>

          {/* Suppressed Allowlist Notes (False-Positive Guards) */}
          {deduction.evaluation.suppressedAllowlistNotes.length > 0 && (
            <div className="pt-2.5 border-t border-black/10 text-xs text-emerald-900 space-y-1">
              <div className="font-bold">Allowlist False-Positive Suppression Active:</div>
              {deduction.evaluation.suppressedAllowlistNotes.map((note, idx) => (
                <div key={idx}>· {note}</div>
              ))}
            </div>
          )}

          {/* Shadow Mode Log-Only Signals */}
          {deduction.evaluation.shadowSignals.length > 0 && (
            <div className="pt-2.5 border-t border-black/10 text-xs text-slate-700 space-y-1">
              <div className="font-bold">
                Shadow Mode Log-Only Observations (0 user friction added):
              </div>
              {deduction.evaluation.shadowSignals.map(sig => (
                <div key={sig.ruleId} className="font-mono text-[11px]">
                  {sig.ruleId} (+{sig.weight.toFixed(2)} if promoted) · {sig.description}
                </div>
              ))}
            </div>
          )}

          {/* Warning Reasons in Plain Language */}
          {deduction.evaluation.signals.length > 0 && (
            <div className="pt-3 border-t border-black/10 space-y-1.5">
              <div className="text-xs font-bold text-slate-800">
                Warning Signs Spotted ({deduction.evaluation.signals.length})
              </div>
              <ul className="space-y-1.5 text-xs text-slate-800">
                {deduction.evaluation.signals.map(sig => (
                  <li key={sig.ruleId} className="flex items-baseline justify-between gap-3">
                    <span>· {sig.description}</span>
                    <span className="font-mono text-[11px] font-semibold text-slate-500 tabular-nums shrink-0">
                      +{Math.round(sig.weight * 100)}% risk
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* User-Friendly Fraud & Dispute Report */}
          {showIncidentReport && (
            <div className="pt-4 border-t border-black/10 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    Fraud &amp; Dispute Report
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Ref: <span className="font-mono font-semibold">{deduction.incidentReport.reportId}</span> ·{' '}
                    {new Date(deduction.incidentReport.createdAtIso).toLocaleString('en-ZA', {
                      dateStyle: 'medium',
                      timeStyle: 'short'
                    })}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      copyToClipboard('plain_report', buildPlainTextReport())
                    }
                    className="flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap"
                  >
                    {copiedKey === 'plain_report' ? (
                      <Check className="h-3.5 w-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                    <span>
                      {copiedKey === 'plain_report' ? 'Copied Report' : 'Copy Report'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadReportSlip}
                    className="flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap"
                  >
                    <Download className="h-3.5 w-3.5 text-emerald-700" />
                    <span>Download Slip</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIncidentSubmitted(true)}
                    className="min-h-[40px] rounded-xl bg-emerald-700 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-emerald-800 transition-colors whitespace-nowrap"
                  >
                    Save Report Offline
                  </button>
                </div>
              </div>

              {incidentSubmitted && (
                <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-xs font-semibold text-emerald-950">
                  Saved report {deduction.incidentReport.reportId} on your phone for{' '}
                  {deduction.incidentReport.reportingAuthority}. Zero airtime used.
                </div>
              )}

              {/* Structured Human-Readable Report Sheet */}
              <div className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5 space-y-4 text-slate-800">
                {/* Summary Row */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pb-4 border-b border-slate-100">
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500">
                      What Was Detected
                    </div>
                    <div className="mt-0.5 text-xs font-bold text-slate-900">
                      {deduction.incidentReport.deducedScamTitle}
                    </div>
                  </div>

                  <div>
                    <div className="text-[11px] font-semibold text-slate-500">
                      Safety Advice
                    </div>
                    <div
                      className={`mt-0.5 text-xs font-bold ${
                        deduction.incidentReport.recommendedBlockTransfer
                          ? 'text-rose-700'
                          : 'text-emerald-700'
                      }`}
                    >
                      {deduction.incidentReport.recommendedBlockTransfer
                        ? 'Do NOT send money — Block payment'
                        : 'Safe — Verify details as normal'}
                    </div>
                  </div>

                  <div>
                    <div className="text-[11px] font-semibold text-slate-500">
                      Amount Involved
                    </div>
                    <div className="mt-0.5 font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {formatZAR(deduction.incidentReport.transactionMetadata.amountZar)}
                      {deduction.incidentReport.transactionMetadata.agentFeeChargedZar !== null &&
                        deduction.incidentReport.transactionMetadata.agentFeeChargedZar > 0 && (
                          <span className="ml-1.5 text-xs font-normal text-slate-500">
                            (Fee: {formatZAR(deduction.incidentReport.transactionMetadata.agentFeeChargedZar)})
                          </span>
                        )}
                    </div>
                  </div>
                </div>

                {/* Payment & Recipient Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2.5 pb-4 border-b border-slate-100 text-xs">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-slate-500">Recipient / Till Name</span>
                    <span className="font-semibold text-slate-900 text-right">
                      {deduction.incidentReport.transactionMetadata.recipientName}
                    </span>
                  </div>

                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-slate-500">Phone / Account ID</span>
                    <span className="font-mono font-semibold text-slate-900 tabular-nums text-right">
                      {deduction.incidentReport.transactionMetadata.recipientId}
                    </span>
                  </div>

                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-slate-500">Payment Type</span>
                    <span className="font-semibold text-slate-900 text-right">
                      {formatOperationLabel(
                        deduction.incidentReport.transactionMetadata.operationType
                      )}
                    </span>
                  </div>

                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-slate-500">Recipient History</span>
                    <span className="font-semibold text-slate-900 text-right">
                      {deduction.incidentReport.transactionMetadata.isNewlyAddedRecipient
                        ? 'Added today (<24h)'
                        : 'Saved contact'}{' '}
                      · {deduction.incidentReport.transactionMetadata.recipientAccountAgeDays}d old
                    </span>
                  </div>
                </div>

                {/* Red Flags & Disguised Spelling */}
                {(deduction.incidentReport.detectedTriggerKeywords.length > 0 ||
                  deduction.incidentReport.obfuscationIndicators.length > 0) && (
                  <div className="pb-4 border-b border-slate-100 space-y-2 text-xs">
                    <div className="font-bold text-slate-900">
                      Red-Flag Clues in Message
                    </div>
                    {deduction.incidentReport.detectedTriggerKeywords.length > 0 && (
                      <p className="text-slate-600 leading-relaxed">
                        <span className="font-semibold text-slate-700">Suspicious phrases: </span>
                        {deduction.incidentReport.detectedTriggerKeywords.join(' · ')}
                      </p>
                    )}
                    {deduction.incidentReport.obfuscationIndicators.length > 0 && (
                      <ul className="space-y-1 text-amber-900">
                        {deduction.incidentReport.obfuscationIndicators.map(item => (
                          <li key={item}>· {formatObfuscationLabel(item)}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}

                {/* Action Steps & Official Authority */}
                <div className="space-y-3 text-xs">
                  <div>
                    <div className="font-bold text-slate-900 mb-1.5">
                      What You Should Do Right Now
                    </div>
                    <ol className="space-y-1.5 text-slate-700 list-decimal list-inside leading-relaxed">
                      {deduction.incidentReport.localizedActionSteps.map((step, idx) => (
                        <li key={idx}>{step}</li>
                      ))}
                    </ol>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="text-[11px] font-semibold text-slate-500">
                        Where to Report Officially
                      </span>
                      <div className="font-bold text-slate-900">
                        {deduction.incidentReport.reportingAuthority}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <PhoneCall className="h-3.5 w-3.5 text-emerald-700 shrink-0" />
                      <span className="font-mono font-bold text-slate-900 tabular-nums">
                        {deduction.incidentReport.reportingHotline}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Official South African Fraud Hotlines */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
        <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
          <PhoneCall className="h-5 w-5 text-emerald-700" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Verified South African Fraud &amp; Credit Helplines
            </h3>
            <p className="text-xs text-slate-500">
              Free official numbers to report banking scams, mashonisa card retention, or SASSA fraud
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              category: 'Bank & Card Fraud',
              name: 'SABRIC Banking Helpline',
              desc: 'Report ATM skimming, fake bank SMSs, and unauthorized deductions.',
              phone: '0860 101 248'
            },
            {
              category: 'Predatory Lenders',
              name: 'National Credit Regulator (NCR)',
              desc: 'Report unregistered lenders demanding upfront fees or holding SASSA cards.',
              phone: '0860 627 627'
            },
            {
              category: 'Police & Extortion',
              name: 'SAPS Crime Stop',
              desc: 'Report threats, extortion, or physical confiscation of ID books and grant cards.',
              phone: '08600 10111'
            }
          ].map(line => (
            <div
              key={line.phone}
              className="rounded-xl border border-slate-200 p-4 flex flex-col justify-between"
            >
              <div>
                <div className="text-[11px] font-semibold text-slate-500">
                  {line.category}
                </div>
                <h4 className="mt-1 text-xs sm:text-sm font-bold text-slate-900">
                  {line.name}
                </h4>
                <p className="text-xs text-slate-500 mt-1">{line.desc}</p>
              </div>
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                  {line.phone}
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(line.phone, line.phone)}
                  className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  {copiedKey === line.phone ? (
                    <Check className="h-3 w-3 text-emerald-600" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                  <span>{copiedKey === line.phone ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* High-Risk (>= 0.70) Mandatory Voice Confirmation Modal */}
      <VoiceConfirmationModal
        isOpen={voiceModalOpen}
        deduction={deduction}
        initialLanguage={warningLang}
        onCancelAndBlock={() => {
          setVoiceModalOpen(false);
          setTransferDecisionBanner(
            `Transfer BLOCKED (${deduction.evaluation.riskScore.toFixed(
              2
            )}): Protected your funds from ${deduction.localizedTitle}.`
          );
          setShowIncidentReport(true);
        }}
        onAcknowledgeProceed={() => {
          setVoiceModalOpen(false);
          setTransferDecisionBanner(
            'User explicitly acknowledged warning and confirmed independent phone verification.'
          );
        }}
        onClose={() => setVoiceModalOpen(false)}
      />
    </div>
  );
};
