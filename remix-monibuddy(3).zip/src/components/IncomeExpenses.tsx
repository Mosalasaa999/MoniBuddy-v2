import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  TrendingUp,
  Tag,
  ArrowUpRight,
  ArrowDownRight,
  ShoppingBag,
  Bus,
  Zap,
  Briefcase,
  Smartphone,
  Trash2,
  Mic
} from 'lucide-react';
import { VoiceCapturePanel } from './VoiceCapturePanel';
import { ParsedVoiceEntry } from '../SlangDictionary';

export const IncomeExpenses: React.FC = () => {
  const {
    transactions,
    addTransaction,
    deleteTransaction,
    totalIncome,
    totalExpenses
  } = useApp();

  const [entryType, setEntryType] = useState<'expense' | 'income'>('expense');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState('Groceries');
  const [chartView, setChartView] = useState<'expense' | 'income'>('expense');

  const quickPresets = [
    { label: 'Groceries & Bread', category: 'Groceries', type: 'expense' },
    { label: 'Taxi Fare', category: 'Transport', type: 'expense' },
    { label: 'Electricity Token', category: 'Utilities', type: 'expense' },
    { label: 'Spaza Stock', category: 'Business', type: 'expense' },
    { label: 'Airtime / Data', category: 'Connectivity', type: 'expense' },
    { label: 'Wages / Salary', category: 'Wages', type: 'income' },
    { label: 'Piece Job / Selling', category: 'Side Hustle', type: 'income' },
    { label: 'SASSA Grant', category: 'Grant', type: 'income' }
  ];

  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!title.trim() || isNaN(val) || val <= 0) return;

    addTransaction({
      type: entryType,
      title: title.trim(),
      amount: val,
      category,
      date
    });

    setTitle('');
    setAmount('');
  };

  const handlePopulateFromVoice = (entry: ParsedVoiceEntry) => {
    setEntryType(entry.type);
    setTitle(entry.title);
    setAmount(entry.amount.toString());
    setCategory(entry.category);
  };

  const formatZAR = (num: number) => {
    return 'R ' + num.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  // 7-day activity data
  const last7Days = useMemo(() => {
    const days = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-ZA', { weekday: 'short' });

      const dayTotal = transactions
        .filter(t => t.date === dateStr && t.type === chartView)
        .reduce((sum, t) => sum + t.amount, 0);

      days.push({
        dateStr,
        dayName,
        total: dayTotal
      });
    }
    return days;
  }, [transactions, chartView]);

  const maxDayAmount = useMemo(() => {
    return Math.max(...last7Days.map(d => d.total), 100);
  }, [last7Days]);

  const getCategoryIcon = (cat: string) => {
    const normalized = cat.toLowerCase();
    if (normalized.includes('transport') || normalized.includes('taxi')) {
      return <Bus className="h-4 w-4 text-amber-600" />;
    }
    if (normalized.includes('utilities') || normalized.includes('electricity')) {
      return <Zap className="h-4 w-4 text-yellow-600" />;
    }
    if (normalized.includes('groceries') || normalized.includes('food')) {
      return <ShoppingBag className="h-4 w-4 text-emerald-600" />;
    }
    if (normalized.includes('business') || normalized.includes('market') || normalized.includes('spaza')) {
      return <Briefcase className="h-4 w-4 text-indigo-600" />;
    }
    if (normalized.includes('connectivity') || normalized.includes('airtime') || normalized.includes('data')) {
      return <Smartphone className="h-4 w-4 text-blue-600" />;
    }
    if (
      normalized.includes('wages') ||
      normalized.includes('salary') ||
      normalized.includes('grant') ||
      normalized.includes('side hustle')
    ) {
      return <TrendingUp className="h-4 w-4 text-emerald-600" />;
    }
    return <Tag className="h-4 w-4 text-slate-500" />;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">
          Money In &amp; Money Out
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Track what you earn and spend each day to stay in control
        </p>
      </div>

      {/* Top 2 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              MONEY IN (LAST 7 DAYS)
            </span>
            <div className="mt-1 font-mono text-3xl font-extrabold text-emerald-700">
              +{formatZAR(totalIncome)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Wages, piece jobs, and grants</p>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700">
            <ArrowUpRight className="h-6 w-6" />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              MONEY OUT (LAST 7 DAYS)
            </span>
            <div className="mt-1 font-mono text-3xl font-extrabold text-rose-700">
              -{formatZAR(totalExpenses)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Food, taxi fare, and daily living</p>
          </div>
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-50 text-rose-700">
            <ArrowDownRight className="h-6 w-6" />
          </div>
        </div>
      </div>

      {/* Voice Capture & Vernacular Slang Parser */}
      <VoiceCapturePanel
        selectedDate={date}
        onPopulateManualForm={handlePopulateFromVoice}
      />

      {/* Split Grid: 7-Day Visual & Add Entry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: 7-Day Chart */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-bold text-slate-900">7-Day Spending &amp; Earnings</h4>
                <p className="text-xs text-slate-500">Daily pattern for the last week</p>
              </div>

              <div className="flex rounded-xl bg-slate-100 p-0.5 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setChartView('expense')}
                  className={`rounded-lg px-3 py-1 transition-all ${
                    chartView === 'expense'
                      ? 'bg-white text-rose-800 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Money Out
                </button>
                <button
                  type="button"
                  onClick={() => setChartView('income')}
                  className={`rounded-lg px-3 py-1 transition-all ${
                    chartView === 'income'
                      ? 'bg-white text-emerald-800 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Money In
                </button>
              </div>
            </div>

            {/* Bar Visual */}
            <div className="mt-8 flex h-44 items-end justify-between gap-2 px-2">
              {last7Days.map(d => {
                const heightPercent = maxDayAmount > 0 ? Math.max(10, Math.round((d.total / maxDayAmount) * 100)) : 10;
                return (
                  <div key={d.dateStr} className="group relative flex flex-1 flex-col items-center">
                    <div className="pointer-events-none absolute -top-8 hidden rounded-md bg-slate-900 px-2 py-1 text-[10px] font-mono text-white shadow-md group-hover:block z-10 whitespace-nowrap">
                      {formatZAR(d.total)}
                    </div>

                    <div className="w-full max-w-[38px] overflow-hidden rounded-t-lg bg-slate-100 flex flex-col justify-end h-32">
                      <div
                        className={`w-full rounded-t-lg transition-all duration-300 ${
                          chartView === 'expense'
                            ? 'bg-rose-500 group-hover:bg-rose-600'
                            : 'bg-emerald-500 group-hover:bg-emerald-600'
                        }`}
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>

                    <span className="mt-2 text-xs font-semibold text-slate-500">
                      {d.dayName}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Last 7 days</span>
            <span className="font-mono font-bold text-slate-700">
              Highest day: {formatZAR(maxDayAmount)}
            </span>
          </div>
        </div>

        {/* Right: Add Entry Form */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
          <div className="pb-3 border-b border-slate-100">
            <h4 className="text-sm font-bold text-slate-900">Record a payment or cash</h4>
            <p className="text-xs text-slate-500">Takes only 5 seconds to log</p>
          </div>

          <form onSubmit={handleAddEntry} className="mt-4 space-y-4">
            {/* Type selector */}
            <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  setEntryType('expense');
                  setCategory('Groceries');
                }}
                className={`flex-1 rounded-lg py-2 transition-all ${
                  entryType === 'expense'
                    ? 'bg-white text-rose-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                - Money Out (Expense)
              </button>
              <button
                type="button"
                onClick={() => {
                  setEntryType('income');
                  setCategory('Wages');
                }}
                className={`flex-1 rounded-lg py-2 transition-all ${
                  entryType === 'income'
                    ? 'bg-white text-emerald-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                + Money In (Income)
              </button>
            </div>

            {/* Quick choices */}
            <div>
              <span className="text-[11px] font-semibold text-slate-500">Tap to pick:</span>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {quickPresets
                  .filter(tag => tag.type === entryType)
                  .map(tag => (
                    <button
                      key={tag.label}
                      type="button"
                      onClick={() => {
                        setTitle(tag.label);
                        setCategory(tag.category);
                      }}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-900 transition-colors"
                    >
                      {tag.label}
                    </button>
                  ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-700">What was it for?</label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Taxi to work, Spaza bread, Maize meal"
                className="mt-1 w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden focus:ring-2 focus:ring-emerald-600/20"
                required
              />
            </div>

            {/* Amount and Date */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700">Amount (R)</label>
                <div className="relative mt-1">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-sm font-bold text-slate-400">R</span>
                  <input
                    type="number"
                    step="any"
                    min="1"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    placeholder="30.00"
                    className="w-full rounded-xl border border-slate-200 pl-8 pr-3 py-2 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className={`w-full rounded-xl py-2.5 text-xs font-bold text-white shadow-xs transition-colors ${
                entryType === 'income' ? 'bg-emerald-700 hover:bg-emerald-800' : 'bg-slate-900 hover:bg-slate-800'
              }`}
            >
              Save Entry
            </button>
          </form>
        </div>
      </div>

      {/* Recent Entries List */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h4 className="text-sm font-bold text-slate-900">Recent Records</h4>
            <p className="text-xs text-slate-500">Everything recorded on your phone</p>
          </div>
          <span className="text-xs font-semibold text-slate-500">
            {transactions.length} items
          </span>
        </div>

        {transactions.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-sm font-medium text-slate-500">
              No entries recorded yet. Tap &apos;Save Entry&apos; above to start tracking.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {transactions.map(item => {
              const isIncome = item.type === 'income' || item.type === 'pot_withdraw' || item.type === 'buffer_withdraw';

              return (
                <div key={item.id} className="flex items-center justify-between py-3 group hover:bg-slate-50/50 px-2 rounded-xl transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100">
                      {getCategoryIcon(item.category)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">{item.title}</span>
                        {item.transcript && (
                          <span
                            title={`Voice: "${item.transcript}"`}
                            className="inline-flex shrink-0"
                          >
                            <Mic className="h-3 w-3 text-emerald-600" />
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {item.date} · {item.category}
                        {item.tags && item.tags.length > 0 && ` · Slang: ${item.tags.join(', ')}`}
                        {item.transcript && ` · "${item.transcript}"`}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`font-mono text-sm font-bold ${
                        isIncome ? 'text-emerald-700' : 'text-rose-700'
                      }`}
                    >
                      {item.type === 'income' ? '+' : '-'} {formatZAR(item.amount)}
                    </span>

                    <button
                      onClick={() => deleteTransaction(item.id)}
                      className="opacity-0 group-hover:opacity-100 rounded-lg p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-all"
                      title="Delete entry"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
