import React, { useState } from 'react';
import {
  Bus,
  ShoppingBag,
  Zap,
  Smartphone,
  Briefcase,
  Users,
  TrendingUp,
  HandCoins,
  Landmark,
  Delete,
  Plus,
  RotateCcw
} from 'lucide-react';
import { ParsedVoiceEntry } from '../SlangDictionary';

interface Tier4TouchPadProps {
  onAddEntry: (entry: ParsedVoiceEntry) => void;
  fallbackNotice?: string | null;
}

interface CategoryTile {
  id: string;
  label: string;
  category: string;
  defaultTitle: string;
  type: 'expense' | 'income';
  icon: React.ReactNode;
}

const CATEGORY_TILES: readonly CategoryTile[] = [
  {
    id: 'taxi',
    label: 'Taxi Fare',
    category: 'Transport',
    defaultTitle: 'Taxi Fare',
    type: 'expense',
    icon: <Bus className="h-4 w-4 text-amber-700" />
  },
  {
    id: 'groceries',
    label: 'Groceries',
    category: 'Groceries',
    defaultTitle: 'Groceries & Food',
    type: 'expense',
    icon: <ShoppingBag className="h-4 w-4 text-emerald-700" />
  },
  {
    id: 'electricity',
    label: 'Electricity',
    category: 'Utilities',
    defaultTitle: 'Prepaid Electricity',
    type: 'expense',
    icon: <Zap className="h-4 w-4 text-yellow-700" />
  },
  {
    id: 'airtime',
    label: 'Airtime / Data',
    category: 'Connectivity',
    defaultTitle: 'Airtime & Data',
    type: 'expense',
    icon: <Smartphone className="h-4 w-4 text-blue-700" />
  },
  {
    id: 'spaza',
    label: 'Spaza Stock',
    category: 'Business',
    defaultTitle: 'Spaza Shop Stock',
    type: 'expense',
    icon: <Briefcase className="h-4 w-4 text-indigo-700" />
  },
  {
    id: 'stokvel',
    label: 'Stokvel',
    category: 'Group Savings',
    defaultTitle: 'Stokvel Contribution',
    type: 'expense',
    icon: <Users className="h-4 w-4 text-teal-700" />
  },
  {
    id: 'wages',
    label: 'Wages / Pay',
    category: 'Wages',
    defaultTitle: 'Wages / Salary',
    type: 'income',
    icon: <TrendingUp className="h-4 w-4 text-emerald-700" />
  },
  {
    id: 'hustle',
    label: 'Piece Job',
    category: 'Side Hustle',
    defaultTitle: 'Piece Job / Sales',
    type: 'income',
    icon: <HandCoins className="h-4 w-4 text-emerald-700" />
  },
  {
    id: 'grant',
    label: 'SASSA Grant',
    category: 'Grant',
    defaultTitle: 'SASSA Grant',
    type: 'income',
    icon: <Landmark className="h-4 w-4 text-emerald-700" />
  }
];

const SLANG_QUICK_BUTTONS: readonly {
  term: string;
  label: string;
  amount: number;
}[] = [
  { term: 'tiger', label: 'Tiger', amount: 10 },
  { term: 'choco', label: 'Choco', amount: 20 },
  { term: 'clipa', label: 'Clipa', amount: 100 },
  { term: 'grand', label: 'Grand', amount: 1000 }
];

const QUICK_RAND_INCREMENTS = [10, 20, 50, 100] as const;
const KEYPAD_DIGITS = ['1', '2', '3', '4', '5', '6', '7', '8', '9'] as const;

export const Tier4TouchPad: React.FC<Tier4TouchPadProps> = ({
  onAddEntry,
  fallbackNotice
}) => {
  const [flowType, setFlowType] = useState<'expense' | 'income'>('expense');
  const [selectedTileId, setSelectedTileId] = useState<string>('taxi');
  const [amountValue, setAmountValue] = useState<number>(0);
  const [digitBuffer, setDigitBuffer] = useState<string>('');
  const [slangCounts, setSlangCounts] = useState<Record<string, number>>({});

  const activeTile =
    CATEGORY_TILES.find(t => t.id === selectedTileId) ?? CATEGORY_TILES[0];

  const handleSelectTile = (tile: CategoryTile) => {
    setSelectedTileId(tile.id);
    setFlowType(tile.type);
    if (tile.id === 'stokvel') {
      setSlangCounts(prev => ({ ...prev, stokvel: Math.max(1, prev.stokvel ?? 0) }));
    }
  };

  const handleAddSlang = (term: string, randAmount: number) => {
    const nextAmount = Math.min(999999, amountValue + randAmount);
    setAmountValue(nextAmount);
    setDigitBuffer(String(nextAmount));
    setSlangCounts(prev => ({
      ...prev,
      [term]: (prev[term] ?? 0) + 1
    }));
  };

  const handleAddQuickRand = (increment: number) => {
    const nextAmount = Math.min(999999, amountValue + increment);
    setAmountValue(nextAmount);
    setDigitBuffer(String(nextAmount));
  };

  const handlePressDigit = (digit: string) => {
    const nextStr = (digitBuffer === '0' ? digit : digitBuffer + digit).slice(0, 6);
    const parsed = Number(nextStr || '0');
    setDigitBuffer(nextStr);
    setAmountValue(Number.isFinite(parsed) ? parsed : 0);
  };

  const handleBackspace = () => {
    const nextStr = digitBuffer.slice(0, -1);
    const parsed = Number(nextStr || '0');
    setDigitBuffer(nextStr);
    setAmountValue(Number.isFinite(parsed) ? parsed : 0);
    if (!nextStr) {
      setSlangCounts({});
    }
  };

  const handleClearAmount = () => {
    setAmountValue(0);
    setDigitBuffer('');
    setSlangCounts({});
  };

  const handleCommitToPreview = () => {
    if (amountValue <= 0) return;

    const tags = Object.entries(slangCounts)
      .filter(([, count]) => count > 0)
      .map(([term]) => term);

    const slangSummary = Object.entries(slangCounts)
      .filter(([term, count]) => count > 0 && term !== 'stokvel')
      .map(([term, count]) => `${count}x ${term}`)
      .join(', ');

    const composedTitle = slangSummary
      ? `${activeTile.defaultTitle} (${slangSummary})`
      : activeTile.defaultTitle;

    onAddEntry({
      type: flowType,
      title: composedTitle,
      amount: amountValue,
      category: activeTile.category,
      tags
    });

    handleClearAmount();
  };

  const formatZAR = (num: number) =>
    'R ' +
    num.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });

  const activeSlangSummary = Object.entries(slangCounts)
    .filter(([, count]) => count > 0)
    .map(([term, count]) => (term === 'stokvel' ? 'stokvel' : `${count} × ${term}`))
    .join(' · ');

  return (
    <div className="space-y-4">
      {fallbackNotice && (
        <div className="rounded-xl border border-amber-200 bg-amber-50/70 px-3.5 py-2.5 text-xs text-amber-950">
          {fallbackNotice}
        </div>
      )}

      {/* Flow Direction Selector (- Money Out vs + Money In) */}
      <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-bold">
        <button
          type="button"
          onClick={() => {
            setFlowType('expense');
            if (activeTile.type !== 'expense') {
              setSelectedTileId('taxi');
            }
          }}
          className={`flex-1 min-h-[44px] rounded-lg px-3 py-2 transition-colors whitespace-nowrap ${
            flowType === 'expense'
              ? 'bg-white text-rose-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          - Money Out
        </button>
        <button
          type="button"
          onClick={() => {
            setFlowType('income');
            if (activeTile.type !== 'income') {
              setSelectedTileId('wages');
            }
          }}
          className={`flex-1 min-h-[44px] rounded-lg px-3 py-2 transition-colors whitespace-nowrap ${
            flowType === 'income'
              ? 'bg-white text-emerald-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          + Money In
        </button>
      </div>

      {/* Category Icon Pad */}
      <div>
        <div className="text-xs font-semibold text-slate-600 mb-1.5">
          1. Tap category icon
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {CATEGORY_TILES.map(tile => {
            const isSelected = tile.id === selectedTileId;
            return (
              <button
                key={tile.id}
                type="button"
                onClick={() => handleSelectTile(tile)}
                className={`flex min-h-[52px] flex-col items-center justify-center gap-1 rounded-xl border px-2 py-2 text-center transition-all active:scale-[0.98] ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/70 text-slate-900 font-bold'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 font-medium'
                }`}
              >
                {tile.icon}
                <span className="text-[11px] leading-tight truncate max-w-full">
                  {tile.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Vernacular Slang Quick-Taps */}
      <div>
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="font-semibold text-slate-600">
            2. Tap township slang or Rand notes
          </span>
          <span className="text-[11px] text-slate-400">Zero typing needed</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {SLANG_QUICK_BUTTONS.map(slang => (
            <button
              key={slang.term}
              type="button"
              onClick={() => handleAddSlang(slang.term, slang.amount)}
              className="flex min-h-[48px] flex-col items-center justify-center rounded-xl border border-emerald-200 bg-emerald-50/50 px-2.5 py-1.5 text-slate-900 hover:bg-emerald-50 active:scale-[0.98] transition-all"
            >
              <span className="text-xs font-bold">+1 {slang.label}</span>
              <span className="text-[11px] font-mono font-semibold text-emerald-800 tabular-nums">
                +R{slang.amount.toLocaleString('en-ZA')}
              </span>
            </button>
          ))}
        </div>

        {/* Standard Quick Rand Buttons (+R10, +R20, +R50, +R100) */}
        <div className="mt-1.5 grid grid-cols-4 gap-1.5">
          {QUICK_RAND_INCREMENTS.map(inc => (
            <button
              key={inc}
              type="button"
              onClick={() => handleAddQuickRand(inc)}
              className="flex min-h-[48px] items-center justify-center rounded-xl border border-slate-200 bg-slate-50 px-2 py-2 font-mono text-xs font-bold text-slate-800 tabular-nums hover:bg-slate-100 active:scale-[0.98] transition-all"
            >
              +R{inc}
            </button>
          ))}
        </div>
      </div>

      {/* High-Contrast Live Readout + Numeric Keypad */}
      <div className="pt-2 border-t border-slate-100 space-y-2.5">
        <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5">
          <div className="min-w-0">
            <div className="text-xs font-bold text-slate-900 truncate">
              {activeTile.defaultTitle}
            </div>
            <div className="text-[11px] text-slate-500 truncate">
              {flowType === 'income' ? 'Money In' : 'Money Out'}
              {activeSlangSummary ? ` · ${activeSlangSummary}` : ''}
            </div>
          </div>

          <div
            className={`font-mono text-xl sm:text-2xl font-extrabold tabular-nums shrink-0 ${
              flowType === 'income' ? 'text-emerald-700' : 'text-slate-900'
            }`}
          >
            {formatZAR(amountValue)}
          </div>
        </div>

        {/* 3x4 Tactile Digit Pad */}
        <div className="grid grid-cols-3 gap-1.5">
          {KEYPAD_DIGITS.map(digit => (
            <button
              key={digit}
              type="button"
              onClick={() => handlePressDigit(digit)}
              className="flex min-h-[48px] items-center justify-center rounded-xl border border-slate-200 bg-white font-mono text-base font-bold text-slate-900 tabular-nums hover:bg-slate-50 active:scale-[0.98] transition-all"
            >
              {digit}
            </button>
          ))}

          <button
            type="button"
            onClick={handleClearAmount}
            aria-label="Clear amount"
            className="flex min-h-[48px] items-center justify-center gap-1 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold text-slate-600 hover:bg-slate-100 active:scale-[0.98] transition-all"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Clear</span>
          </button>

          <button
            type="button"
            onClick={() => handlePressDigit('0')}
            className="flex min-h-[48px] items-center justify-center rounded-xl border border-slate-200 bg-white font-mono text-base font-bold text-slate-900 tabular-nums hover:bg-slate-50 active:scale-[0.98] transition-all"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleBackspace}
            aria-label="Backspace digit"
            className="flex min-h-[48px] items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 active:scale-[0.98] transition-all"
          >
            <Delete className="h-4 w-4" />
          </button>
        </div>

        {/* Add Item CTA */}
        <button
          type="button"
          disabled={amountValue <= 0}
          onClick={handleCommitToPreview}
          className="flex w-full min-h-[48px] items-center justify-center gap-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 active:scale-[0.98] transition-all disabled:opacity-45 disabled:cursor-not-allowed"
        >
          <Plus className="h-4 w-4 shrink-0" />
          <span>
            {amountValue > 0
              ? `Add ${formatZAR(amountValue)} (${activeTile.label})`
              : 'Tap Slang or Digits Above'}
          </span>
        </button>
      </div>
    </div>
  );
};
