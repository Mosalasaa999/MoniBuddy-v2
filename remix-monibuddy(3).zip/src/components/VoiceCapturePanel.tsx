import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Check,
  RotateCcw,
  AlertCircle,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Grid3X3,
  Loader2,
  Download
} from 'lucide-react';
import {
  VoiceRecognitionLanguage,
  SpeechTier,
  WasmVoicePackSnapshot,
  ConnectionProfile,
  VoicePackNeededError,
  Tier4FallbackError,
  wasmVoicePackManager,
  getConnectionProfile,
  getNetworkInformation,
  resolveActiveSpeechTier,
  startProgressiveSpeechCapture,
  ProgressiveSpeechSession
} from '../VoiceRecorder';
import {
  PHONETIC_ALIAS_MATRIX,
  ParsedVoiceEntry,
  parseVernacularTransaction
} from '../SlangDictionary';
import { useApp } from '../context/AppContext';
import { OfflineVoicePackModal } from './OfflineVoicePackModal';
import { Tier4TouchPad } from './Tier4TouchPad';

interface VoiceCapturePanelProps {
  selectedDate: string;
  onPopulateManualForm?: (entry: ParsedVoiceEntry) => void;
}

const LANGUAGE_OPTIONS: { code: VoiceRecognitionLanguage; label: string }[] = [
  { code: 'en-ZA', label: 'English (SA)' },
  { code: 'zu-ZA', label: 'isiZulu' },
  { code: 'nso-ZA', label: 'Sepedi' }
];

const SAMPLE_PHRASES = [
  'Two choco for taxi and one clipa for airtime',
  'Spaza sales R350 and three tiger for taxi',
  'Wages one grand and two choco for data',
  'Four tiger for transport'
];

export const VoiceCapturePanel: React.FC<VoiceCapturePanelProps> = ({
  selectedDate,
  onPopulateManualForm
}) => {
  const { addTransaction, language, networkMode } = useApp();

  const [captureMode, setCaptureMode] = useState<'voice' | 'touch'>('voice');
  const [voiceLang, setVoiceLang] = useState<VoiceRecognitionLanguage>(
    language === 'zu' ? 'zu-ZA' : 'en-ZA'
  );

  // Voice & Tier state
  const [packState, setPackState] = useState<WasmVoicePackSnapshot>(() =>
    wasmVoicePackManager.getSnapshot()
  );
  const [connectionProfile, setConnectionProfile] = useState<ConnectionProfile>(() =>
    getConnectionProfile(networkMode)
  );
  const [activeTier, setActiveTier] = useState<SpeechTier>(() =>
    resolveActiveSpeechTier(networkMode, wasmVoicePackManager.getSnapshot().status)
  );
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [voicePackModalOpen, setVoicePackModalOpen] = useState<boolean>(false);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);

  // Parsed entries state (shared across Voice & Tier 4 Touch Pad)
  const [transcript, setTranscript] = useState<string>('');
  const [parsedEntries, setParsedEntries] = useState<ParsedVoiceEntry[]>([]);
  const [detectedSlang, setDetectedSlang] = useState<string[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [showSlangGuide, setShowSlangGuide] = useState<boolean>(false);

  const abortControllerRef = useRef<AbortController | null>(null);
  const activeSessionRef = useRef<ProgressiveSpeechSession | null>(null);

  useEffect(() => {
    if (language === 'zu') {
      setVoiceLang('zu-ZA');
    } else if (language === 'en') {
      setVoiceLang('en-ZA');
    }
  }, [language]);

  // Subscribe to WASM Voice Pack Coordinator & Network Information API
  useEffect(() => {
    const unsubscribe = wasmVoicePackManager.subscribe(snap => {
      setPackState(snap);
      setActiveTier(resolveActiveSpeechTier(networkMode, snap.status));
    });

    const syncNetworkState = () => {
      const nextProfile = getConnectionProfile(networkMode);
      setConnectionProfile(nextProfile);
      setActiveTier(
        resolveActiveSpeechTier(networkMode, wasmVoicePackManager.getSnapshot().status)
      );
      // Silent Auto-Download ONLY on unmetered Wi-Fi (saveData === false)
      wasmVoicePackManager.evaluateAutoWifiPrefetch(networkMode);
    };

    syncNetworkState();

    const conn = getNetworkInformation();
    window.addEventListener('online', syncNetworkState);
    window.addEventListener('offline', syncNetworkState);
    conn?.addEventListener?.('change', syncNetworkState);

    return () => {
      unsubscribe();
      window.removeEventListener('online', syncNetworkState);
      window.removeEventListener('offline', syncNetworkState);
      conn?.removeEventListener?.('change', syncNetworkState);
    };
  }, [networkMode]);

  // Auto-switch to Tier 4 Touch Pad if hardware has zero mic support on startup
  useEffect(() => {
    if (activeTier === 'tier4-touch') {
      setCaptureMode('touch');
    }
  }, [activeTier]);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
      activeSessionRef.current?.cancel();
    };
  }, []);

  const applyTranscript = (rawText: string) => {
    setTranscript(rawText);
    setErrorMessage(null);
    setSavedNotice(null);

    if (!rawText.trim()) {
      setParsedEntries([]);
      setDetectedSlang([]);
      return;
    }

    const result = parseVernacularTransaction(rawText);
    setParsedEntries(result.entries);
    setDetectedSlang(result.slangTags);

    if (result.entries.length === 0) {
      setErrorMessage(
        'No amount or vernacular term was recognized in that phrase. Try mentioning an amount like "two choco for taxi" or switch to the Touch Pad.'
      );
    }
  };

  const handleStartRecording = async () => {
    setErrorMessage(null);
    setSavedNotice(null);
    setFallbackNotice(null);

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    const session = startProgressiveSpeechCapture({
      language: voiceLang,
      networkMode,
      signal: controller.signal,
      onTierChange: tier => setActiveTier(tier),
      onAudioLevel: level => setAudioLevel(level),
      onTranscribing: () => {
        setIsRecording(false);
        setIsTranscribing(true);
      }
    });

    activeSessionRef.current = session;
    setActiveTier(session.activeTier);
    setIsRecording(true);
    setIsTranscribing(false);

    try {
      const { transcript: spokenText, tierUsed } = await session.result;
      setIsRecording(false);
      setIsTranscribing(false);
      setAudioLevel(0);
      setActiveTier(tierUsed);
      applyTranscript(spokenText);
    } catch (err) {
      setIsRecording(false);
      setIsTranscribing(false);
      setAudioLevel(0);

      if (err instanceof DOMException && err.name === 'AbortError') {
        return;
      }

      if (err instanceof VoicePackNeededError) {
        setVoicePackModalOpen(true);
        return;
      }

      if (err instanceof Tier4FallbackError) {
        setFallbackNotice(err.message);
        setCaptureMode('touch');
        return;
      }

      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Unable to capture voice right now. Try again or tap Touch Pad above.'
      );
    }
  };

  const handleFinishSpeaking = () => {
    activeSessionRef.current?.stopRecording();
  };

  const handleCancelRecording = () => {
    abortControllerRef.current?.abort();
    activeSessionRef.current?.cancel();
    setIsRecording(false);
    setIsTranscribing(false);
    setAudioLevel(0);
  };

  // Modal Handlers
  const handleModalDownloadNow = async () => {
    try {
      await wasmVoicePackManager.downloadVoicePack();
      setVoicePackModalOpen(false);
      setSavedNotice(
        'Offline voice pack saved to your phone. Tap Speak Transaction to record with zero data.'
      );
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return;
      }
      // Error is displayed inside OfflineVoicePackModal via packState.error
    }
  };

  const handleModalDownloadLaterOnWifi = () => {
    wasmVoicePackManager.queueForWifi();
    setVoicePackModalOpen(false);
    setFallbackNotice(
      'Offline voice pack (35 MB) queued — it will download automatically next time you connect to Wi-Fi. Use the Manual Touch Pad below for now.'
    );
    setCaptureMode('touch');
  };

  const handleModalUseTouchPad = () => {
    if (packState.status === 'downloading') {
      // Allow background download to continue or simply switch user to touch pad immediately
      setVoicePackModalOpen(false);
    } else {
      setVoicePackModalOpen(false);
    }
    setFallbackNotice(null);
    setCaptureMode('touch');
  };

  const handleAddTouchPadEntry = (entry: ParsedVoiceEntry) => {
    setSavedNotice(null);
    setErrorMessage(null);
    setParsedEntries(prev => [...prev, entry]);
    if (entry.tags.length > 0) {
      setDetectedSlang(prev => [...new Set([...prev, ...entry.tags])]);
    }
  };

  const handleUpdateEntry = (
    index: number,
    patch: Partial<ParsedVoiceEntry>
  ) => {
    setParsedEntries(prev =>
      prev.map((entry, idx) => (idx === index ? { ...entry, ...patch } : entry))
    );
  };

  const handleRemoveEntry = (index: number) => {
    setParsedEntries(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleSaveParsedEntries = () => {
    const validEntries = parsedEntries.filter(
      item =>
        item.title.trim().length > 0 &&
        Number.isFinite(item.amount) &&
        item.amount > 0
    );
    if (validEntries.length === 0) return;

    for (const entry of validEntries) {
      addTransaction({
        type: entry.type,
        title: entry.title.trim(),
        amount: entry.amount,
        category: entry.category,
        date: selectedDate,
        tags: entry.tags.length > 0 ? entry.tags : undefined,
        transcript: transcript.trim() || undefined
      });
    }

    const count = validEntries.length;
    setSavedNotice(
      `Saved ${count} ${count === 1 ? 'entry' : 'entries'} to your ledger.`
    );
    setTranscript('');
    setParsedEntries([]);
    setDetectedSlang([]);
  };

  const handleClear = () => {
    abortControllerRef.current?.abort();
    activeSessionRef.current?.cancel();
    setIsRecording(false);
    setIsTranscribing(false);
    setAudioLevel(0);
    setTranscript('');
    setParsedEntries([]);
    setDetectedSlang([]);
    setErrorMessage(null);
    setSavedNotice(null);
  };

  const formatZAR = (num: number) =>
    'R ' +
    num.toLocaleString('en-ZA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });

  const tierDescription = (() => {
    if (captureMode === 'touch') {
      return 'Tier 4: Manual Slang & Keypad';
    }
    if (activeTier === 'tier1-cloud') {
      return 'Tier 1: Online Native Speech';
    }
    if (activeTier === 'tier2-ondevice') {
      return 'Tier 2: On-Device Native Speech';
    }
    if (activeTier === 'tier3-wasm') {
      return packState.status === 'ready'
        ? 'Tier 3: Offline WASM Ready'
        : 'Tier 3: Offline WASM (35 MB Pack)';
    }
    return 'Tier 4: Manual Touch Pad';
  })();

  const voicePackStatusLabel = (() => {
    if (packState.status === 'ready') return 'Offline pack cached';
    if (packState.status === 'downloading') {
      return `Caching offline pack (${packState.progress}%)`;
    }
    if (packState.status === 'queued-wifi') return 'Queued for Wi-Fi';
    return 'Zero cellular auto-download';
  })();

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
      {/* Header & Mode / Language Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="min-w-0">
          <h3 className="text-sm font-bold text-slate-900">
            Voice Capture &amp; Township Touch Pad
          </h3>
          {/* Unboxed inline metadata (Zero-Pill Discipline) */}
          <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5">
            <span>{tierDescription}</span>
            <span aria-hidden="true">·</span>
            <span>{voicePackStatusLabel}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Primary Mode Switcher: Voice vs Tier 4 Touch Pad */}
          <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setCaptureMode('voice')}
              className={`flex min-h-[40px] items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
                captureMode === 'voice'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Mic className="h-3.5 w-3.5 text-emerald-700" />
              <span>Voice</span>
            </button>
            <button
              type="button"
              onClick={() => setCaptureMode('touch')}
              className={`flex min-h-[40px] items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
                captureMode === 'touch'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Grid3X3 className="h-3.5 w-3.5 text-emerald-700" />
              <span>Touch Pad</span>
            </button>
          </div>

          {/* Segmented Language Control (shown in Voice mode) */}
          {captureMode === 'voice' && (
            <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1">
              {LANGUAGE_OPTIONS.map(opt => (
                <button
                  key={opt.code}
                  type="button"
                  disabled={isRecording || isTranscribing}
                  onClick={() => setVoiceLang(opt.code)}
                  className={`min-h-[40px] rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    voiceLang === opt.code
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  } disabled:opacity-50`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Two-Column Capture & Preview Row */}
      <div className="mt-4 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column: Voice Capture OR Tier 4 Visual Touch Pad */}
        <div className="lg:col-span-7 space-y-3">
          {captureMode === 'touch' ? (
            <Tier4TouchPad
              onAddEntry={handleAddTouchPadEntry}
              fallbackNotice={fallbackNotice}
            />
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2.5">
                {!isRecording && !isTranscribing ? (
                  <button
                    type="button"
                    onClick={handleStartRecording}
                    className="flex min-h-[48px] items-center gap-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 active:scale-[0.98] transition-all whitespace-nowrap shrink-0"
                  >
                    <Mic className="h-4 w-4 shrink-0" />
                    <span>Speak Transaction</span>
                  </button>
                ) : isRecording ? (
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={handleFinishSpeaking}
                      className="flex min-h-[48px] items-center gap-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 active:scale-[0.98] transition-all whitespace-nowrap shrink-0"
                    >
                      <Square className="h-3.5 w-3.5 fill-current shrink-0" />
                      <span>
                        {activeTier === 'tier3-wasm'
                          ? 'Done Speaking (Transcribe)'
                          : 'Stop Listening'}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={handleCancelRecording}
                      className="flex min-h-[48px] items-center justify-center rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="flex min-h-[48px] items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs font-bold text-slate-800">
                    <Loader2 className="h-4 w-4 animate-spin text-emerald-700 shrink-0" />
                    <span>Transcribing offline on your phone...</span>
                  </div>
                )}

                {packState.status !== 'ready' && !isRecording && !isTranscribing && (
                  <button
                    type="button"
                    onClick={() => setVoicePackModalOpen(true)}
                    className="flex min-h-[48px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Download className="h-3.5 w-3.5 text-emerald-700 shrink-0" />
                    <span>
                      {packState.status === 'downloading'
                        ? `Downloading (${packState.progress}%)`
                        : 'Offline Voice Pack'}
                    </span>
                  </button>
                )}

                {(transcript || parsedEntries.length > 0 || errorMessage) &&
                  !isRecording &&
                  !isTranscribing && (
                    <button
                      type="button"
                      onClick={handleClear}
                      className="flex min-h-[48px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                    >
                      <RotateCcw className="h-3.5 w-3.5 shrink-0" />
                      <span>Clear</span>
                    </button>
                  )}

                <button
                  type="button"
                  onClick={() => setShowSlangGuide(prev => !prev)}
                  className="ml-auto flex min-h-[40px] items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 whitespace-nowrap shrink-0"
                >
                  <BookOpen className="h-3.5 w-3.5 shrink-0" />
                  <span>
                    {showSlangGuide ? 'Hide slang dictionary' : 'Slang dictionary'}
                  </span>
                  {showSlangGuide ? (
                    <ChevronUp className="h-3.5 w-3.5 shrink-0" />
                  ) : (
                    <ChevronDown className="h-3.5 w-3.5 shrink-0" />
                  )}
                </button>
              </div>

              {/* Live Tier 3 Microphone Level Meter */}
              {isRecording && activeTier === 'tier3-wasm' && (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-3 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-emerald-950">
                      Listening offline — tap Done Speaking when finished
                    </span>
                    <span className="font-mono text-[11px] text-emerald-800 tabular-nums">
                      16 kHz local PCM
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-emerald-100">
                    <div
                      className="h-full rounded-full bg-emerald-600 transition-transform duration-100 origin-left"
                      style={{ transform: `scaleX(${Math.max(0.08, audioLevel)})` }}
                    />
                  </div>
                </div>
              )}

              {/* Live / Editable Transcript Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-700">
                  Spoken phrase (or type to test offline slang parser)
                </label>
                <div className="mt-1 flex gap-2">
                  <input
                    type="text"
                    value={transcript}
                    onChange={e => applyTranscript(e.target.value)}
                    placeholder='e.g. "Two choco for taxi and one clipa for airtime"'
                    className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden focus:ring-2 focus:ring-emerald-600/20"
                  />
                </div>
              </div>

              {/* Quick Test Phrases */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500">
                  Try sample voice phrases:
                </span>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {SAMPLE_PHRASES.map(phrase => (
                    <button
                      key={phrase}
                      type="button"
                      onClick={() => applyTranscript(phrase)}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] font-medium text-slate-700 hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-900 transition-colors text-left"
                    >
                      &ldquo;{phrase}&rdquo;
                    </button>
                  ))}
                </div>
              </div>

              {/* Collapsible Slang Reference Table */}
              {showSlangGuide && (
                <div className="pt-3 border-t border-slate-100">
                  <div className="text-xs font-bold text-slate-800 mb-2">
                    Supported Township &amp; Vernacular Slang Matrix
                  </div>
                  <div className="divide-y divide-slate-100 text-xs">
                    {PHONETIC_ALIAS_MATRIX.map(group => (
                      <div
                        key={group.term}
                        className="py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-1"
                      >
                        <div>
                          <span className="font-bold text-slate-900 capitalize">
                            {group.term}
                          </span>
                          <span className="text-slate-400 mx-1.5">·</span>
                          <span className="text-slate-500">
                            {group.aliases.slice(0, 5).join(', ')}
                          </span>
                        </div>
                        <div className="font-mono font-semibold text-slate-700 tabular-nums shrink-0">
                          {group.amount !== undefined
                            ? formatZAR(group.amount)
                            : group.category}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {/* Error or Confirmation Messages */}
          {errorMessage && (
            <div className="flex items-start justify-between gap-3 rounded-xl border border-rose-200 bg-rose-50/70 p-3 text-xs text-rose-800">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
              {captureMode === 'voice' && (
                <button
                  type="button"
                  onClick={() => setCaptureMode('touch')}
                  className="font-bold text-rose-900 underline whitespace-nowrap shrink-0"
                >
                  Open Touch Pad
                </button>
              )}
            </div>
          )}

          {savedNotice && (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 p-3 text-xs font-semibold text-emerald-900">
              <Check className="h-4 w-4 text-emerald-700 shrink-0" />
              <span>{savedNotice}</span>
            </div>
          )}
        </div>

        {/* Right Column: Parsed Entries Preview & Confirm */}
        <div className="lg:col-span-5 lg:border-l lg:border-slate-100 lg:pl-5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900">
              Parsed Ledger Entries ({parsedEntries.length})
            </h4>
            {detectedSlang.length > 0 && (
              <span className="text-[11px] text-slate-500">
                Slang: {detectedSlang.join(' · ')}
              </span>
            )}
          </div>

          {parsedEntries.length === 0 ? (
            <div className="mt-3 py-6 text-center border border-dashed border-slate-200 rounded-xl px-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                {captureMode === 'touch'
                  ? 'Tap a category icon and slang buttons (+1 Choco, +1 Clipa) or digits on the Touch Pad to build your entry.'
                  : 'Tap Speak Transaction, pick a sample phrase, or switch to the Touch Pad to log cash in seconds.'}
              </p>
            </div>
          ) : (
            <div className="mt-3 space-y-3">
              <div className="divide-y divide-slate-100">
                {parsedEntries.map((entry, idx) => (
                  <div
                    key={`${entry.title}-${idx}`}
                    className="py-2.5 first:pt-0 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <input
                        type="text"
                        value={entry.title}
                        onChange={e =>
                          handleUpdateEntry(idx, { title: e.target.value })
                        }
                        className="flex-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          handleUpdateEntry(idx, {
                            type: entry.type === 'expense' ? 'income' : 'expense'
                          })
                        }
                        className={`min-h-[36px] rounded-lg px-2.5 py-1 text-[11px] font-bold transition-colors whitespace-nowrap shrink-0 ${
                          entry.type === 'income'
                            ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                            : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
                        }`}
                      >
                        {entry.type === 'income' ? '+ Money In' : '- Money Out'}
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="text-[11px] text-slate-500 truncate">
                        {entry.category}
                        {entry.tags.length > 0 && ` · ${entry.tags.join(', ')}`}
                      </span>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="relative w-28">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-2 text-xs font-bold text-slate-400">
                            R
                          </span>
                          <input
                            type="number"
                            step="any"
                            min="1"
                            value={entry.amount}
                            onChange={e =>
                              handleUpdateEntry(idx, {
                                amount: Number(e.target.value)
                              })
                            }
                            className="w-full rounded-lg border border-slate-200 pl-6 pr-2 py-1 text-xs font-mono font-bold text-slate-900 tabular-nums focus:border-emerald-600 focus:outline-hidden"
                          />
                        </div>

                        {onPopulateManualForm && parsedEntries.length === 1 && (
                          <button
                            type="button"
                            onClick={() => onPopulateManualForm(entry)}
                            className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 whitespace-nowrap"
                          >
                            Edit in form
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => handleRemoveEntry(idx)}
                          className="text-[11px] font-semibold text-slate-400 hover:text-rose-600 whitespace-nowrap"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={handleSaveParsedEntries}
                className="flex w-full min-h-[48px] items-center justify-center gap-1.5 rounded-xl bg-emerald-700 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 active:scale-[0.98] transition-all"
              >
                <Check className="h-4 w-4 shrink-0" />
                <span>
                  Save {parsedEntries.length}{' '}
                  {parsedEntries.length === 1 ? 'Entry' : 'Entries'} to Ledger
                </span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Explicit Cellular Data Guard / Offline Voice Pack Modal */}
      <OfflineVoicePackModal
        isOpen={voicePackModalOpen}
        onClose={() => setVoicePackModalOpen(false)}
        packState={packState}
        connectionProfile={connectionProfile}
        onDownloadNow={handleModalDownloadNow}
        onCancelDownload={() => wasmVoicePackManager.cancelDownload()}
        onDownloadLaterOnWifi={handleModalDownloadLaterOnWifi}
        onUseManualTouchPad={handleModalUseTouchPad}
      />
    </div>
  );
};
