import React from 'react';
import { Download, Wifi, Grid3X3, X, AlertTriangle, Loader2 } from 'lucide-react';
import { ConnectionProfile, WasmVoicePackSnapshot } from '../VoiceRecorder';

interface OfflineVoicePackModalProps {
  isOpen: boolean;
  onClose: () => void;
  packState: WasmVoicePackSnapshot;
  connectionProfile: ConnectionProfile;
  onDownloadNow: () => void;
  onCancelDownload: () => void;
  onDownloadLaterOnWifi: () => void;
  onUseManualTouchPad: () => void;
}

export const OfflineVoicePackModal: React.FC<OfflineVoicePackModalProps> = ({
  isOpen,
  onClose,
  packState,
  connectionProfile,
  onDownloadNow,
  onCancelDownload,
  onDownloadLaterOnWifi,
  onUseManualTouchPad
}) => {
  if (!isOpen) return null;

  const isDownloading = packState.status === 'downloading';
  const isOffline = connectionProfile === 'offline';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="voice-pack-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
    >
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-50 text-amber-800 border border-amber-200/70">
              <Download className="h-5 w-5" />
            </div>
            <div>
              <h3
                id="voice-pack-modal-title"
                className="text-base font-bold text-slate-900"
              >
                Offline Voice Pack Needed
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Protects your prepaid mobile data
              </p>
            </div>
          </div>

          {!isDownloading && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close modal"
              className="flex min-h-[44px] min-w-[44px] -m-1.5 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Body */}
        <div className="mt-4 space-y-3">
          <p className="text-sm text-slate-700 leading-relaxed">
            To record speech without internet, a <strong className="font-mono font-bold text-slate-900">35MB</strong> voice pack is required. Once saved on your phone, offline speech works forever with zero data.
          </p>

          {connectionProfile === 'cellular' || connectionProfile === 'save-data' ? (
            <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-xs text-amber-950">
              <AlertTriangle className="h-4 w-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                You are currently on mobile data{connectionProfile === 'save-data' ? ' (Data Saver active)' : ''}. MoniBuddy blocked automatic download so your airtime is never used without permission.
              </span>
            </div>
          ) : isOffline ? (
            <div className="flex items-start gap-2.5 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700">
              <Wifi className="h-4 w-4 text-slate-500 shrink-0 mt-0.5" />
              <span>
                Your phone currently has no internet signal. Choose <strong>Download Later on Wi-Fi</strong> or log immediately with the <strong>Manual Touch Pad</strong>.
              </span>
            </div>
          ) : null}

          {packState.error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50/80 p-3 text-xs text-rose-900">
              {packState.error}
            </div>
          )}

          {/* Live Download Progress State */}
          {isDownloading && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 font-semibold text-slate-800">
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-emerald-700" />
                  <span>Saving voice pack to phone...</span>
                </span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {packState.progress}%
                </span>
              </div>

              <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200">
                <div
                  className="h-full rounded-full bg-emerald-700 transition-transform duration-150 origin-left"
                  style={{ transform: `scaleX(${Math.max(0.02, packState.progress / 100)})` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono tabular-nums">
                <span>
                  {packState.downloadedMB.toFixed(1)} MB / {packState.totalMB.toFixed(0)} MB
                </span>
                <span>Cached locally</span>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="mt-5 space-y-2 pt-4 border-t border-slate-100">
          {isDownloading ? (
            <div className="flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={onCancelDownload}
                className="flex flex-1 min-h-[48px] items-center justify-center rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-xs font-bold text-rose-800 hover:bg-rose-100 active:scale-[0.98] transition-all"
              >
                Cancel Download
              </button>
              <button
                type="button"
                onClick={onUseManualTouchPad}
                className="flex flex-1 min-h-[48px] items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white hover:bg-slate-800 active:scale-[0.98] transition-all"
              >
                <Grid3X3 className="h-4 w-4 shrink-0" />
                <span>Use Touch Pad Meanwhile</span>
              </button>
            </div>
          ) : (
            <>
              <button
                type="button"
                disabled={isOffline}
                onClick={onDownloadNow}
                className="flex w-full min-h-[48px] items-center justify-center gap-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 active:scale-[0.98] transition-all disabled:opacity-45 disabled:cursor-not-allowed"
              >
                <Download className="h-4 w-4 shrink-0" />
                <span className="font-sans">Download Now (35 MB)</span>
              </button>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={onDownloadLaterOnWifi}
                  className="flex min-h-[48px] items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs font-bold text-slate-800 hover:bg-slate-50 active:scale-[0.98] transition-all whitespace-nowrap"
                >
                  <Wifi className="h-4 w-4 text-emerald-700 shrink-0" />
                  <span>Download Later on Wi-Fi</span>
                </button>

                <button
                  type="button"
                  onClick={onUseManualTouchPad}
                  className="flex min-h-[48px] items-center justify-center gap-1.5 rounded-xl bg-slate-900 px-3 py-2.5 text-xs font-bold text-white hover:bg-slate-800 active:scale-[0.98] transition-all whitespace-nowrap"
                >
                  <Grid3X3 className="h-4 w-4 shrink-0" />
                  <span>Use Manual Touch Pad</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
