/**
 * @fileoverview Offline-First Rule-Based Local Scam Parser for MoniBuddy ("Context-Aware Defensive Shield").
 * Evaluates transaction payloads (recipient ID, amount, account age, transfer velocity, agent fees)
 * and user voice/text transcripts against deterministic heuristic threat patterns with zero network dependency.
 */

export type ThreatCategory =
  | 'PREDATORY_LENDING_UPFRONT_FEE'
  | 'PREDATORY_LENDING_UNREALISTIC_RETURN'
  | 'SOCIAL_ENGINEERING_URGENCY'
  | 'OFFICIAL_IMPERSONATION'
  | 'AGENT_FEE_EXTORTION'
  | 'PIN_OTP_DISCLOSURE'
  | 'TELEMETRY_ANOMALY';

export type ScamSeverity = 'SAFE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type TransactionOperationType =
  | 'p2p_transfer'
  | 'loan_fee_payment'
  | 'cash_out'
  | 'cash_in'
  | 'merchant_payment';

export interface TransactionTelemetryPayload {
  readonly transactionId?: string;
  readonly recipientId: string;
  readonly recipientName?: string;
  readonly amountZar: number;
  /** Age of the recipient account in days (0 = newly created / unverified burner). */
  readonly recipientAccountAgeDays: number;
  /** Whether the recipient was newly added to the user's contact/beneficiary book in the last 24h. */
  readonly isNewlyAddedRecipient: boolean;
  /** Number of outbound transfers initiated by the user in the last 60 minutes. */
  readonly recentTransferCountLastHour: number;
  /** Optional operation type for cash-in / cash-out fee validation. */
  readonly operationType?: TransactionOperationType;
  /** Optional fee demanded or charged by a cash-out/mobile-money agent in ZAR. */
  readonly agentFeeChargedZar?: number;
  /** Optional NCR (National Credit Regulator) registration status if known locally. */
  readonly isRegisteredCreditProvider?: boolean;
  readonly timestampIso?: string;
}

export interface HeuristicRuleDefinition {
  readonly id: string;
  readonly category: ThreatCategory;
  readonly weight: number;
  readonly description: string;
  readonly patterns: readonly RegExp[];
}

export interface DetectedThreatSignal {
  readonly ruleId: string;
  readonly category: ThreatCategory;
  readonly weight: number;
  readonly description: string;
  readonly matchedKeywords: readonly string[];
}

export interface AgentFeeTier {
  readonly minAmountZar: number;
  readonly maxAmountZar: number;
  readonly officialMaxFeeZar: number;
}

export interface ScamParserEvaluation {
  /** Normalized risk score strictly bounded in [0.0, 1.0]. */
  readonly riskScore: number;
  readonly severity: ScamSeverity;
  readonly isBlockedRecommended: boolean;
  readonly signals: readonly DetectedThreatSignal[];
  readonly matchedKeywords: readonly string[];
  readonly categoryBreakdown: Readonly<Record<ThreatCategory, number>>;
  readonly feeTierViolation?: {
    readonly withdrawalAmountZar: number;
    readonly chargedFeeZar: number;
    readonly officialMaxFeeZar: number;
    readonly overchargeAmountZar: number;
  };
  readonly evaluatedAtIso: string;
}

/**
 * Official South African township mobile-money / voucher cash-out fee schedule (ZAR).
 * Used offline to detect agent surcharge extortion during cash-in / cash-out operations.
 */
export const OFFICIAL_CASH_OUT_FEE_TIERS: readonly AgentFeeTier[] = [
  { minAmountZar: 1, maxAmountZar: 100, officialMaxFeeZar: 6 },
  { minAmountZar: 100.01, maxAmountZar: 500, officialMaxFeeZar: 10 },
  { minAmountZar: 500.01, maxAmountZar: 1000, officialMaxFeeZar: 15 },
  { minAmountZar: 1000.01, maxAmountZar: 3000, officialMaxFeeZar: 25 },
  { minAmountZar: 3000.01, maxAmountZar: 5000, officialMaxFeeZar: 35 }
];

/**
 * Hardcoded heuristic threat dictionary covering English, South African township vernacular,
 * isiZulu, and Sepedi social engineering, advance-fee micro-loans, and agent PIN/fee extortion.
 */
export const HEURISTIC_THREAT_DICTIONARY: readonly HeuristicRuleDefinition[] = [
  // 1. Predatory Lending — Upfront / Advance Fee Disbursement Traps
  {
    id: 'RULE_PREDATORY_UPFRONT_FEE',
    category: 'PREDATORY_LENDING_UPFRONT_FEE',
    weight: 0.55,
    description: 'Demands an upfront processing, admin, legal, or release fee before disbursing a loan.',
    patterns: [
      /\b(pay|send|deposit|transfer)\b[^.!?]{0,45}\b(processing|admin|administrative|initiation|release|clearance|registration|verification|insurance|lawyer)\s+(fee|deposit|charge|cost|money)\b/giu,
      /\b(processing|admin|release|registration|clearance|activation)\s+fee\s+(first|before|to\s+release|to\s+unlock|required)\b/giu,
      /\bdeposit\s+r?\s*\d+[^.!?]{0,35}\b(to\s+release|to\s+unlock|for\s+loan|get\s+r?\s*\d+)\b/giu,
      /\b(moneymarket|pep\s*cell|kazang|flash\s*voucher|1voucher|ott\s*voucher)\b[^.!?]{0,50}\b(release|loan|approved|fee)\b/giu,
      /\bkhokha\b[^.!?]{0,35}\b(imali\s+yokuvula|ifizi|ukukhulula\s+imalimboleko)\b/giu,
      /\blefa\b[^.!?]{0,35}\b(tefo\s+ya\s+go\s+bula|kadimo)\b/giu
    ]
  },
  // 2. Predatory Lending — Unrealistic Returns, Mashonisa Compounding & Blacklist-Free Hooks
  {
    id: 'RULE_PREDATORY_UNREALISTIC_TERMS',
    category: 'PREDATORY_LENDING_UNREALISTIC_RETURN',
    weight: 0.42,
    description: 'Promises guaranteed instant loans without credit checks, compounding daily mashonisa interest, or unrealistic investment multipliers.',
    patterns: [
      /\b(100%|200%|300%|double\s+your\s+money)\s*(daily|weekly|in\s+24\s*hours|return|profit)\b/giu,
      /\bguaranteed\s+instant\s+(loan|payout|cash|approval)\b/giu,
      /\b(no\s+credit\s+check|blacklisted\s+welcome|without\s+payslip)\b[^.!?]{0,45}\b(instant|approved|loan|cash)\b/giu,
      /\b(\d{2,3}%\s*(daily|per\s+day|interest\s+per\s+week)|compounding\s+daily\s+interest|mashonisa\s+special)\b/giu,
      /\b(leave|hand\s+over|surrender)\s+(your\s+)?(sassa\s+card|id\s+book|bank\s+card|pin)\b/giu
    ]
  },
  // 3. Social Engineering & High-Pressure Temporal Urgency Cues
  {
    id: 'RULE_SOCIAL_URGENCY_PRESSURE',
    category: 'SOCIAL_ENGINEERING_URGENCY',
    weight: 0.34,
    description: 'Applies high-pressure urgency, panic emergencies (police/hospital), or imminent account lock threats.',
    patterns: [
      /\b(send\s+right\s+now|right\s+now|immediately|within\s+\d+\s*(minutes|mins|hours|hrs)|before\s+midnight|urgent\s+notice|act\s+fast)\b/giu,
      /\b(police\s+station|arrested|in\s+custody|bail\s+money|roadblock\s+fine)\b/giu,
      /\b(hospital\s+emergency|casualty|icu|ambulance|accident\s+ward|urgent\s+operation)\b/giu,
      /\b(account\s+(locked|suspended|blocked|frozen)|grant\s+(suspended|on\s+hold|forfeited)|sim\s+swap\s+pending)\b/giu,
      /\b(sent\s+by\s+mistake|wrong\s+number\s+please\s+reverse|send\s+it\s+back\s+urgently)\b/giu,
      /\b(phuthuma|thumela\s+manje|esibhedlela|emaphoyiseni)\b/giu,
      /\b(akere\s+o\s+romele\s+gonabjale|sepetlele|maphodisa)\b/giu
    ]
  },
  // 4. Impersonation of Official Entities (SASSA, Bank Fraud Dept, SARS, Network Operator)
  {
    id: 'RULE_OFFICIAL_IMPERSONATION',
    category: 'OFFICIAL_IMPERSONATION',
    weight: 0.40,
    description: 'Claims authority as a SASSA/SASA official, bank fraud investigator, SARS agent, or mobile network operator.',
    patterns: [
      /\b(sassa|sasa)\s+(official|agent|head\s+office|grant\s+officer|verification\s+desk|srd\s+department|urgent\s+notice)\b/giu,
      /\b(bank|capitec|fnb|standard\s+bank|absa|nedbank|tymebank)\s+(fraud\s+department|security\s+team|forensics|investigator|cancellation\s+desk)\b/giu,
      /\b(network\s+operator|vodacom|mtn|telkom|cell\s*c)\s+(agent|sim\s+department|rica\s+officer|upgrade\s+desk)\b/giu,
      /\b(sars\s+(official|erefund|tax\s+refund\s+portal)|home\s+affairs\s+officer)\b/giu,
      /\b(http:\/\/|bit\.ly\/|tinyurl\.com\/|[a-z0-9-]+-(?:portal|verify|sassa|erefund)\.[a-z]{2,})/giu
    ]
  },
  // 5. Agent Extortion & Cash-Out Surcharge / PIN & OTP Disclosure
  {
    id: 'RULE_PIN_OTP_DISCLOSURE',
    category: 'PIN_OTP_DISCLOSURE',
    weight: 0.58,
    description: 'Requests secret bank PIN, One-Time PIN (OTP), USSD auth code, or voucher secret during a transaction or cash-out.',
    patterns: [
      /\b(share|send|reply\s+with|read\s+out|give\s+me|enter\s+your|tell\s+the\s+agent)\b[^.!?]{0,40}\b(otp|one[\s-]time\s+pin|secret\s+pin|5[\s-]digit\s+pin|4[\s-]digit\s+pin|bank\s+pin|cvv|ussd\s+code|cash[\s-]send\s+pin)\b/giu,
      /\b(otp|secret\s+pin|one[\s-]time\s+pin)\s+(to\s+cancel|to\s+reverse|to\s+verify|to\s+release|for\s+cash[\s-]out)\b/giu,
      /\b(ungiphe\s+i[\s-]?pin|ipini\s+yakho|ikhodi\s+ye[\s-]?otp)\b/giu,
      /\b(mpha\s+pin\s+ya\s+gago|nomoro\s+ya\s+sephiri)\b/giu
    ]
  },
  {
    id: 'RULE_AGENT_FEE_EXTORTION_TEXT',
    category: 'AGENT_FEE_EXTORTION',
    weight: 0.44,
    description: 'Demands unauthorized extra agent cash-out commission, "system offline" surcharge, or split-withdrawal fee.',
    patterns: [
      /\b(agent|spaza|kiosk|teller)\b[^.!?]{0,45}\b(extra\s+fee|cash[\s-]out\s+fee|withdrawal\s+charge|system\s+offline\s+fee|after[\s-]hours\s+fee|commission)\b/giu,
      /\b(pay|give)\s+r?\s*\d+\s+(extra|cash)\s+(for\s+cash[\s-]out|to\s+withdraw|agent\s+cut)\b/giu
    ]
  }
];

/**
 * Looks up the maximum permitted mobile-money / voucher cash-out fee for a given ZAR withdrawal.
 */
export const getOfficialMaxAgentFeeZar = (withdrawalAmountZar: number): number => {
  if (!Number.isFinite(withdrawalAmountZar) || withdrawalAmountZar <= 0) {
    return 0;
  }
  const matchedTier = OFFICIAL_CASH_OUT_FEE_TIERS.find(
    tier => withdrawalAmountZar >= tier.minAmountZar && withdrawalAmountZar <= tier.maxAmountZar
  );
  if (matchedTier) {
    return matchedTier.officialMaxFeeZar;
  }
  // Above R5,000 cap at 0.8% rounded to nearest Rand
  return Math.round(withdrawalAmountZar * 0.008);
};

const clampScore = (raw: number): number => {
  if (!Number.isFinite(raw) || raw <= 0) return 0;
  if (raw >= 1) return 1;
  return Number(raw.toFixed(3));
};

const scoreToSeverity = (score: number): ScamSeverity => {
  if (score >= 0.75) return 'CRITICAL';
  if (score >= 0.55) return 'HIGH';
  if (score >= 0.30) return 'MEDIUM';
  if (score >= 0.12) return 'LOW';
  return 'SAFE';
};

/**
 * Evaluates a user transcript (voice or SMS/WhatsApp text) and optional transaction telemetry
 * completely offline against deterministic threat rules.
 */
export const evaluateScamRisk = (
  transcriptOrMessage: string,
  telemetry?: TransactionTelemetryPayload
): ScamParserEvaluation => {
  const normalizedText = transcriptOrMessage.trim();
  const signals: DetectedThreatSignal[] = [];
  const allMatchedKeywords = new Set<string>();

  const categoryBreakdown: Record<ThreatCategory, number> = {
    PREDATORY_LENDING_UPFRONT_FEE: 0,
    PREDATORY_LENDING_UNREALISTIC_RETURN: 0,
    SOCIAL_ENGINEERING_URGENCY: 0,
    OFFICIAL_IMPERSONATION: 0,
    AGENT_FEE_EXTORTION: 0,
    PIN_OTP_DISCLOSURE: 0,
    TELEMETRY_ANOMALY: 0
  };

  // 1. Evaluate transcript / message heuristics
  if (normalizedText.length > 0) {
    for (const rule of HEURISTIC_THREAT_DICTIONARY) {
      const ruleMatches = new Set<string>();

      for (const regex of rule.patterns) {
        const flags = regex.flags.includes('g') ? regex.flags : `${regex.flags}g`;
        const clone = new RegExp(regex.source, flags);
        for (const match of normalizedText.matchAll(clone)) {
          const phrase = match[0].trim();
          if (phrase) {
            ruleMatches.add(phrase);
            allMatchedKeywords.add(phrase);
          }
        }
      }

      if (ruleMatches.size > 0) {
        // Multi-phrase hit within same rule adds a small reinforcement bonus up to +0.08
        const reinforcement = Math.min(0.08, (ruleMatches.size - 1) * 0.04);
        const effectiveWeight = Number((rule.weight + reinforcement).toFixed(3));
        signals.push({
          ruleId: rule.id,
          category: rule.category,
          weight: effectiveWeight,
          description: rule.description,
          matchedKeywords: [...ruleMatches]
        });
        categoryBreakdown[rule.category] = Number(
          (categoryBreakdown[rule.category] + effectiveWeight).toFixed(3)
        );
      }
    }
  }

  // 2. Evaluate structured transaction telemetry heuristics
  let feeTierViolation: ScamParserEvaluation['feeTierViolation'] | undefined;

  if (telemetry) {
    // 2a. Newly created / burner recipient account (< 7 days old)
    if (telemetry.recipientAccountAgeDays >= 0 && telemetry.recipientAccountAgeDays < 7) {
      const weight = telemetry.recipientAccountAgeDays <= 1 ? 0.28 : 0.18;
      const label = `recipient_account_age_${telemetry.recipientAccountAgeDays}d`;
      allMatchedKeywords.add(label);
      signals.push({
        ruleId: 'TELEMETRY_BURNER_ACCOUNT_AGE',
        category: 'TELEMETRY_ANOMALY',
        weight,
        description: `Recipient account (${telemetry.recipientId}) is only ${telemetry.recipientAccountAgeDays} day(s) old — common for mule/burner scam accounts.`,
        matchedKeywords: [label]
      });
      categoryBreakdown.TELEMETRY_ANOMALY = Number(
        (categoryBreakdown.TELEMETRY_ANOMALY + weight).toFixed(3)
      );
    }

    // 2b. Newly added beneficiary combined with non-trivial transfer or social-engineering cues
    if (telemetry.isNewlyAddedRecipient) {
      const hasSocialOrImpersonation =
        categoryBreakdown.SOCIAL_ENGINEERING_URGENCY > 0 ||
        categoryBreakdown.OFFICIAL_IMPERSONATION > 0;
      const weight = hasSocialOrImpersonation ? 0.24 : telemetry.amountZar >= 300 ? 0.14 : 0.08;
      allMatchedKeywords.add('newly_added_recipient');
      signals.push({
        ruleId: 'TELEMETRY_NEW_RECIPIENT_RISK',
        category: 'TELEMETRY_ANOMALY',
        weight,
        description: 'Recipient was added within the last 24 hours with no prior trusted payment history.',
        matchedKeywords: ['newly_added_recipient']
      });
      categoryBreakdown.TELEMETRY_ANOMALY = Number(
        (categoryBreakdown.TELEMETRY_ANOMALY + weight).toFixed(3)
      );
    }

    // 2c. High outbound transfer velocity (rapid panic drains / multiple voucher splits)
    if (telemetry.recentTransferCountLastHour >= 3) {
      const weight = telemetry.recentTransferCountLastHour >= 5 ? 0.25 : 0.16;
      const velocityTag = `high_velocity_${telemetry.recentTransferCountLastHour}_tx_1h`;
      allMatchedKeywords.add(velocityTag);
      signals.push({
        ruleId: 'TELEMETRY_HIGH_TRANSFER_VELOCITY',
        category: 'TELEMETRY_ANOMALY',
        weight,
        description: `Unusual transfer velocity: ${telemetry.recentTransferCountLastHour} outbound transfers in the past hour.`,
        matchedKeywords: [velocityTag]
      });
      categoryBreakdown.TELEMETRY_ANOMALY = Number(
        (categoryBreakdown.TELEMETRY_ANOMALY + weight).toFixed(3)
      );
    }

    // 2d. Unregistered micro-lender demanding loan fee
    if (
      telemetry.isRegisteredCreditProvider === false &&
      (telemetry.operationType === 'loan_fee_payment' ||
        categoryBreakdown.PREDATORY_LENDING_UPFRONT_FEE > 0 ||
        categoryBreakdown.PREDATORY_LENDING_UNREALISTIC_RETURN > 0)
    ) {
      const weight = 0.28;
      allMatchedKeywords.add('unregistered_credit_provider');
      signals.push({
        ruleId: 'TELEMETRY_UNREGISTERED_LENDER',
        category: 'PREDATORY_LENDING_UPFRONT_FEE',
        weight,
        description: 'Recipient is not registered with the National Credit Regulator (NCR) and is soliciting loan-related payments.',
        matchedKeywords: ['unregistered_credit_provider']
      });
      categoryBreakdown.PREDATORY_LENDING_UPFRONT_FEE = Number(
        (categoryBreakdown.PREDATORY_LENDING_UPFRONT_FEE + weight).toFixed(3)
      );
    }

    // 2e. Agent Cash-Out / Cash-In Fee Surcharge Validation
    if (
      (telemetry.operationType === 'cash_out' || telemetry.operationType === 'cash_in') &&
      typeof telemetry.agentFeeChargedZar === 'number' &&
      telemetry.agentFeeChargedZar > 0 &&
      telemetry.amountZar > 0
    ) {
      const officialMaxFeeZar = getOfficialMaxAgentFeeZar(telemetry.amountZar);
      if (telemetry.agentFeeChargedZar > officialMaxFeeZar) {
        const overchargeAmountZar = Number(
          (telemetry.agentFeeChargedZar - officialMaxFeeZar).toFixed(2)
        );
        const overchargeRatio = overchargeAmountZar / Math.max(1, officialMaxFeeZar);
        const weight = overchargeRatio >= 1 ? 0.62 : 0.45;
        const feeTag = `agent_overcharge_R${overchargeAmountZar}`;
        allMatchedKeywords.add(feeTag);

        feeTierViolation = {
          withdrawalAmountZar: telemetry.amountZar,
          chargedFeeZar: telemetry.agentFeeChargedZar,
          officialMaxFeeZar,
          overchargeAmountZar
        };

        signals.push({
          ruleId: 'TELEMETRY_UNAUTHORIZED_AGENT_FEE_TIER',
          category: 'AGENT_FEE_EXTORTION',
          weight,
          description: `Agent fee of R${telemetry.agentFeeChargedZar.toFixed(2)} exceeds the official maximum tier fee of R${officialMaxFeeZar.toFixed(2)} for a R${telemetry.amountZar.toFixed(2)} cash operation (overcharged by R${overchargeAmountZar.toFixed(2)}).`,
          matchedKeywords: [feeTag]
        });
        categoryBreakdown.AGENT_FEE_EXTORTION = Number(
          (categoryBreakdown.AGENT_FEE_EXTORTION + weight).toFixed(3)
        );
      }
    }
  }

  // 3. Compounding Synergy Boosts (multi-vector social engineering)
  let rawScore = signals.reduce((sum, sig) => sum + sig.weight, 0);

  if (
    categoryBreakdown.OFFICIAL_IMPERSONATION > 0 &&
    categoryBreakdown.SOCIAL_ENGINEERING_URGENCY > 0
  ) {
    rawScore += 0.14;
  }

  if (
    categoryBreakdown.PREDATORY_LENDING_UPFRONT_FEE > 0 &&
    categoryBreakdown.PREDATORY_LENDING_UNREALISTIC_RETURN > 0
  ) {
    rawScore += 0.12;
  }

  if (
    categoryBreakdown.PIN_OTP_DISCLOSURE > 0 &&
    (categoryBreakdown.AGENT_FEE_EXTORTION > 0 || categoryBreakdown.OFFICIAL_IMPERSONATION > 0)
  ) {
    rawScore += 0.15;
  }

  const riskScore = clampScore(rawScore);
  const severity = scoreToSeverity(riskScore);

  return {
    riskScore,
    severity,
    isBlockedRecommended: riskScore >= 0.55,
    signals,
    matchedKeywords: [...allMatchedKeywords],
    categoryBreakdown,
    feeTierViolation,
    evaluatedAtIso: telemetry?.timestampIso ?? new Date().toISOString()
  };
};
