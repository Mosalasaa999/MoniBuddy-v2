/**
 * @fileoverview Comprehensive offline unit test suite for `scamParser.ts` and `scamDeductionEngine.ts`.
 * Covers predatory micro-loans, emergency/official impersonation scams, unauthorized agent cash-out fees,
 * localized isiZulu/Sepedi/English audio scripts, and safe baseline transactions.
 *
 * Run via: `npx tsx src/scamShield.test.ts`
 */

import {
  evaluateScamRisk,
  getOfficialMaxAgentFeeZar,
  TransactionTelemetryPayload
} from './scamParser';
import {
  deduceScamAndBuildIncidentReport,
  generateLocalizedAudioScripts
} from './scamDeductionEngine';

export interface ShieldUnitTestResult {
  readonly id: string;
  readonly name: string;
  readonly passed: boolean;
  readonly details: string;
}

const assertCondition = (condition: boolean, failureMessage: string): void => {
  if (!condition) {
    throw new Error(failureMessage);
  }
};

export const runDefensiveShieldTestSuite = (): readonly ShieldUnitTestResult[] => {
  const cases: {
    id: string;
    name: string;
    run: () => string;
  }[] = [
    {
      id: 'TC-01',
      name: 'Predatory Micro-Loan: Upfront fee + unregistered credit provider maps to TEMPLATE_PREDATORY_LENDER',
      run: () => {
        const transcript =
          'Guaranteed instant loan of R5000 with no credit check! Deposit R150 processing fee first via 1Voucher to release your cash.';
        const telemetry: TransactionTelemetryPayload = {
          transactionId: 'TX-LOAN-901',
          recipientId: '0719998821',
          recipientName: 'QuickCash Loans SA',
          amountZar: 150,
          recipientAccountAgeDays: 3,
          isNewlyAddedRecipient: true,
          recentTransferCountLastHour: 1,
          operationType: 'loan_fee_payment',
          isRegisteredCreditProvider: false,
          timestampIso: '2026-10-24T10:00:00.000Z'
        };

        const deduction = deduceScamAndBuildIncidentReport({
          transcriptOrMessage: transcript,
          telemetry,
          preferredLanguage: 'en'
        });

        assertCondition(
          deduction.template.templateId === 'TEMPLATE_PREDATORY_LENDER',
          `Expected TEMPLATE_PREDATORY_LENDER, got ${deduction.template.templateId}`
        );
        assertCondition(
          deduction.evaluation.riskScore >= 0.85 && deduction.evaluation.riskScore <= 1.0,
          `Expected critical riskScore in [0.85, 1.0], got ${deduction.evaluation.riskScore}`
        );
        assertCondition(
          deduction.evaluation.severity === 'CRITICAL',
          `Expected CRITICAL severity, got ${deduction.evaluation.severity}`
        );
        assertCondition(
          deduction.incidentReport.recommendedBlockTransfer === true,
          'Expected recommendedBlockTransfer to be true'
        );
        assertCondition(
          deduction.incidentReport.detectedTriggerKeywords.includes('unregistered_credit_provider'),
          'Expected unregistered_credit_provider trigger in incident report'
        );
        assertCondition(
          deduction.audioWarningScripts.en.includes('Never pay a fee to receive a loan'),
          'Expected English audio script to warn against upfront loan fees'
        );
        assertCondition(
          deduction.audioWarningScripts.zu.length > 20 &&
            deduction.audioWarningScripts.nso.length > 20,
          'Expected non-empty isiZulu and Sepedi audio warning scripts'
        );

        return `Score=${deduction.evaluation.riskScore} (${deduction.evaluation.severity}) -> ${deduction.template.templateId}`;
      }
    },
    {
      id: 'TC-02',
      name: 'Predatory Lending: Compounding daily mashonisa interest & SASSA card surrender retention',
      run: () => {
        const transcript =
          '100% daily return investment or instant loan! Just leave your SASSA card and secret PIN with our mashonisa special.';
        const evaluation = evaluateScamRisk(transcript);

        assertCondition(
          evaluation.categoryBreakdown.PREDATORY_LENDING_UNREALISTIC_RETURN > 0,
          'Expected PREDATORY_LENDING_UNREALISTIC_RETURN signal'
        );
        assertCondition(
          evaluation.riskScore >= 0.42,
          `Expected elevated riskScore >= 0.42, got ${evaluation.riskScore}`
        );

        const deduction = deduceScamAndBuildIncidentReport({
          transcriptOrMessage: transcript,
          existingEvaluation: evaluation,
          preferredLanguage: 'zu'
        });
        assertCondition(
          deduction.template.templateId === 'TEMPLATE_PREDATORY_LENDER',
          `Expected TEMPLATE_PREDATORY_LENDER, got ${deduction.template.templateId}`
        );

        return `Score=${evaluation.riskScore}, Template=${deduction.template.templateId}`;
      }
    },
    {
      id: 'TC-03',
      name: 'Emergency Impersonation: Hospital/Police panic + newly added burner recipient maps to TEMPLATE_IMPERSONATION_URGENT',
      run: () => {
        const transcript =
          'Hospital emergency! Your cousin is in casualty after an accident, send right now R950 to this nurse number before midnight!';
        const telemetry: TransactionTelemetryPayload = {
          transactionId: 'TX-EMG-404',
          recipientId: '0638821904',
          recipientName: 'Nurse Dube',
          amountZar: 950,
          recipientAccountAgeDays: 1,
          isNewlyAddedRecipient: true,
          recentTransferCountLastHour: 3,
          operationType: 'p2p_transfer',
          timestampIso: '2026-10-24T10:15:00.000Z'
        };

        const deduction = deduceScamAndBuildIncidentReport({
          transcriptOrMessage: transcript,
          telemetry,
          preferredLanguage: 'nso'
        });

        assertCondition(
          deduction.template.templateId === 'TEMPLATE_IMPERSONATION_URGENT',
          `Expected TEMPLATE_IMPERSONATION_URGENT, got ${deduction.template.templateId}`
        );
        assertCondition(
          deduction.evaluation.riskScore >= 0.75,
          `Expected riskScore >= 0.75, got ${deduction.evaluation.riskScore}`
        );
        assertCondition(
          deduction.incidentReport.transactionMetadata.isNewlyAddedRecipient === true,
          'Expected incidentReport metadata to preserve isNewlyAddedRecipient=true'
        );
        assertCondition(
          deduction.activeAudioScript.includes('R950'),
          `Expected Sepedi activeAudioScript to interpolate R950, got: ${deduction.activeAudioScript}`
        );

        return `Score=${deduction.evaluation.riskScore} (${deduction.evaluation.severity}) -> ${deduction.template.templateId}`;
      }
    },
    {
      id: 'TC-04',
      name: 'Official Entity Impersonation: SASSA & Bank Fraud Department OTP phishing',
      run: () => {
        const transcript =
          'SASSA official verification desk & Capitec fraud department: Your grant is suspended. Reply with your 5-digit PIN and OTP immediately at http://sassa-verify.me';
        const deduction = deduceScamAndBuildIncidentReport({
          transcriptOrMessage: transcript,
          preferredLanguage: 'zu'
        });

        assertCondition(
          deduction.template.templateId === 'TEMPLATE_IMPERSONATION_URGENT',
          `Expected TEMPLATE_IMPERSONATION_URGENT, got ${deduction.template.templateId}`
        );
        assertCondition(
          deduction.evaluation.riskScore >= 0.9,
          `Expected near-max riskScore >= 0.90, got ${deduction.evaluation.riskScore}`
        );
        assertCondition(
          deduction.incidentReport.triggeredRuleIds.includes('RULE_OFFICIAL_IMPERSONATION') &&
            deduction.incidentReport.triggeredRuleIds.includes('RULE_PIN_OTP_DISCLOSURE'),
          'Expected both RULE_OFFICIAL_IMPERSONATION and RULE_PIN_OTP_DISCLOSURE'
        );

        return `Score=${deduction.evaluation.riskScore}, Rules=${deduction.incidentReport.triggeredRuleIds.length}`;
      }
    },
    {
      id: 'TC-05',
      name: 'Agent Extortion: Cash-out fee exceeding official tier + PIN demand maps to TEMPLATE_UNAUTHORIZED_AGENT_FEE',
      run: () => {
        const transcript =
          'Kiosk agent says system offline fee applies, pay R45 extra for cash-out and give me your Cash-Send PIN.';
        const telemetry: TransactionTelemetryPayload = {
          transactionId: 'TX-CSH-772',
          recipientId: 'AGENT-KIOSK-19',
          recipientName: 'Corner Spaza Kiosk',
          amountZar: 400,
          recipientAccountAgeDays: 120,
          isNewlyAddedRecipient: false,
          recentTransferCountLastHour: 1,
          operationType: 'cash_out',
          agentFeeChargedZar: 45,
          timestampIso: '2026-10-24T10:30:00.000Z'
        };

        const officialMax = getOfficialMaxAgentFeeZar(400);
        assertCondition(officialMax === 10, `Expected R10 official max fee for R400, got R${officialMax}`);

        const deduction = deduceScamAndBuildIncidentReport({
          transcriptOrMessage: transcript,
          telemetry,
          preferredLanguage: 'en'
        });

        assertCondition(
          deduction.template.templateId === 'TEMPLATE_UNAUTHORIZED_AGENT_FEE',
          `Expected TEMPLATE_UNAUTHORIZED_AGENT_FEE, got ${deduction.template.templateId}`
        );
        assertCondition(
          deduction.evaluation.feeTierViolation?.overchargeAmountZar === 35,
          `Expected overcharge of R35, got ${deduction.evaluation.feeTierViolation?.overchargeAmountZar}`
        );
        assertCondition(
          deduction.activeAudioScript.includes('R10'),
          `Expected audio warning to state official R10 fee cap, got: ${deduction.activeAudioScript}`
        );

        return `Overcharge=R${deduction.evaluation.feeTierViolation?.overchargeAmountZar}, Score=${deduction.evaluation.riskScore}`;
      }
    },
    {
      id: 'TC-06',
      name: 'Benign Routine Transaction: Trusted grocery merchant within normal parameters remains SAFE',
      run: () => {
        const transcript = 'Bought maize meal, cooking oil, and bread at Boxer store.';
        const telemetry: TransactionTelemetryPayload = {
          transactionId: 'TX-SAFE-102',
          recipientId: 'MERCHANT-BOXER-04',
          recipientName: 'Boxer Superstores Soweto',
          amountZar: 185,
          recipientAccountAgeDays: 1400,
          isNewlyAddedRecipient: false,
          recentTransferCountLastHour: 1,
          operationType: 'merchant_payment'
        };

        const deduction = deduceScamAndBuildIncidentReport({
          transcriptOrMessage: transcript,
          telemetry,
          preferredLanguage: 'en'
        });

        assertCondition(
          deduction.evaluation.riskScore === 0,
          `Expected 0.0 riskScore for routine purchase, got ${deduction.evaluation.riskScore}`
        );
        assertCondition(
          deduction.evaluation.severity === 'SAFE',
          `Expected SAFE severity, got ${deduction.evaluation.severity}`
        );
        assertCondition(
          deduction.template.templateId === 'TEMPLATE_GENERAL_SAFE',
          `Expected TEMPLATE_GENERAL_SAFE, got ${deduction.template.templateId}`
        );

        const scripts = generateLocalizedAudioScripts('TEMPLATE_GENERAL_SAFE');
        assertCondition(
          Boolean(scripts.en && scripts.zu && scripts.nso),
          'Expected trilingual scripts for safe template'
        );

        return `Score=${deduction.evaluation.riskScore} (${deduction.evaluation.severity})`;
      }
    }
  ];

  return cases.map(tc => {
    try {
      const details = tc.run();
      return { id: tc.id, name: tc.name, passed: true, details };
    } catch (error) {
      return {
        id: tc.id,
        name: tc.name,
        passed: false,
        details: error instanceof Error ? error.message : String(error)
      };
    }
  });
};

// Allow direct CLI execution via `npx tsx src/scamShield.test.ts`
const isCliExecution = (() => {
  try {
    return typeof process !== 'undefined' && Array.isArray(process.argv) && process.argv[1]?.includes('scamShield.test');
  } catch {
    return false;
  }
})();

if (isCliExecution) {
  const results = runDefensiveShieldTestSuite();
  let failed = 0;
  for (const r of results) {
    const badge = r.passed ? 'PASS' : 'FAIL';
    console.log(`[${badge}] ${r.id} - ${r.name}\n       ${r.details}`);
    if (!r.passed) failed += 1;
  }
  if (failed > 0) {
    process.exit(1);
  }
  console.log(`\nAll ${results.length} Context-Aware Defensive Shield unit tests passed.`);
}
