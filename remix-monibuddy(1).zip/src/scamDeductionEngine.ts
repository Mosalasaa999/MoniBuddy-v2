/**
 * @fileoverview AI Scam Deduction & Contextual Template Manager for MoniBuddy.
 * Deterministically maps detected threat signals from `scamParser.ts` to pre-configured
 * Scam Context Templates, generates pre-populated incident dispute payloads, and produces
 * voice-synthesizer-ready warning scripts in English, isiZulu, and Sepedi.
 */

import {
  ScamParserEvaluation,
  TransactionTelemetryPayload,
  evaluateScamRisk
} from './scamParser';

export type ScamTemplateId =
  | 'TEMPLATE_PREDATORY_LENDER'
  | 'TEMPLATE_IMPERSONATION_URGENT'
  | 'TEMPLATE_UNAUTHORIZED_AGENT_FEE'
  | 'TEMPLATE_GENERAL_SAFE';

export type SupportedWarningLanguage = 'en' | 'zu' | 'nso';

export interface LocalizedTextMap {
  readonly en: string;
  readonly zu: string;
  readonly nso: string;
}

export interface LocalizedActionStepsMap {
  readonly en: readonly string[];
  readonly zu: readonly string[];
  readonly nso: readonly string[];
}

export interface ScamContextTemplate {
  readonly templateId: ScamTemplateId;
  readonly title: LocalizedTextMap;
  readonly summary: LocalizedTextMap;
  readonly reportingAuthority: string;
  readonly reportingContact: string;
  readonly recommendedActions: LocalizedActionStepsMap;
  /** Plain-language, TTS-ready audio warning templates with optional `{amount}` / `{maxFee}` slots. */
  readonly audioScriptTemplate: LocalizedTextMap;
}

export interface ContextualIncidentReportPayload {
  readonly reportId: string;
  readonly createdAtIso: string;
  readonly deducedTemplateId: ScamTemplateId;
  readonly deducedScamTitle: string;
  /** Normalized risk score (0.0 – 1.0). */
  readonly riskScore: number;
  readonly severity: ScamParserEvaluation['severity'];
  readonly recommendedBlockTransfer: boolean;
  readonly reportingAuthority: string;
  readonly reportingHotline: string;
  readonly transactionMetadata: {
    readonly transactionId: string;
    readonly recipientId: string;
    readonly recipientName: string;
    readonly amountZar: number;
    readonly recipientAccountAgeDays: number;
    readonly isNewlyAddedRecipient: boolean;
    readonly recentTransferCountLastHour: number;
    readonly operationType: string;
    readonly agentFeeChargedZar: number | null;
  };
  readonly detectedTriggerKeywords: readonly string[];
  readonly triggeredRuleIds: readonly string[];
  readonly localizedActionSteps: readonly string[];
  readonly audioWarningScripts: LocalizedTextMap;
  readonly activeAudioScript: string;
  readonly userNarrativeSummary: string;
}

export interface ScamDeductionResult {
  readonly template: ScamContextTemplate;
  readonly evaluation: ScamParserEvaluation;
  readonly localizedTitle: string;
  readonly localizedSummary: string;
  readonly localizedActions: readonly string[];
  readonly audioWarningScripts: LocalizedTextMap;
  readonly activeAudioScript: string;
  readonly incidentReport: ContextualIncidentReportPayload;
}

/**
 * Hardcoded Scam Context Templates for offline deduction and dispute auto-population.
 */
export const SCAM_CONTEXT_TEMPLATES: Readonly<Record<ScamTemplateId, ScamContextTemplate>> = {
  TEMPLATE_PREDATORY_LENDER: {
    templateId: 'TEMPLATE_PREDATORY_LENDER',
    title: {
      en: 'Predatory Micro-Loan / Advance-Fee Trap',
      zu: 'Umkhonyovu Wemalimboleko Yamanga (Imali Yokuvula)',
      nso: 'Boradia bja Kadimo ya Tšhelete ya Tebogo ya Pele'
    },
    summary: {
      en: 'Registered South African credit providers NEVER demand an upfront admin, release, or voucher fee before paying out a loan, and are prohibited from holding your SASSA or bank card.',
      zu: 'Abambolekisi bemali abasemthethweni abaze bacele imali yokuvula noma ivawusha ngaphambi kokukhipha imalimboleko, futhi akuvumelekile ukuthi bagcine ikhadi lakho lakwa-SASSA.',
      nso: 'Baabi ba dikadimo ba semolao ga ba nke ba nyaka tefo ya go bula pele ba ntšha kadimo, gomme ga ba dumelelwe go swara karata ya gago ya SASSA.'
    },
    reportingAuthority: 'National Credit Regulator (NCR) & SAPS Crime Stop',
    reportingContact: '0860 627 627 / 08600 10111',
    recommendedActions: {
      en: [
        'Stop immediately: Do NOT pay any processing, admin, or voucher release fee.',
        'Never hand over your SASSA card, ID book, or secret PIN to a mashonisa or online lender.',
        'Verify the lender with the National Credit Regulator (NCR) on 0860 627 627.',
        'Use your MoniBuddy Emergency Fund instead of high-interest unregulated loans.'
      ],
      zu: [
        'Yima ngokushesha: UNGAKHOKHI mali yokuvula, i-admin fee, noma ivawusha.',
        'Ungaze unikeze umashonisa ikhadi lakho lakwa-SASSA, umazisi (ID), noma i-PIN yakho.',
        'Qinisekisa umbolekisi kwa-National Credit Regulator (NCR) ku-0860 627 627.',
        'Sebenzisa Isikhwama Esiphuthumayo se-MoniBuddy esikhundleni sokuboleka komashonisa.'
      ],
      nso: [
        'Ema gonabjale: O SE KE wa lefa tefo ya admin goba voucher go lokolla kadimo.',
        'O se ke wa fa motho karata ya gago ya SASSA, pukwana ya boitsebišo (ID), goba PIN.',
        'Netefatša moabi wa kadimo go National Credit Regulator (NCR) mo go 0860 627 627.',
        'Šomiša Letlole la Tšhoganetšo la MoniBuddy go efoga dikadimo tša tswalo ya godimo.'
      ]
    },
    audioScriptTemplate: {
      en: 'Warning: Never pay a fee to receive a loan. Legitimate lenders deduct fees from the loan agreement and never ask for vouchers or upfront deposits. This is a common advance-fee scam.',
      zu: 'Isixwayiso: Ungaze ukhokhe imali kuqala ukuze uthole imalimboleko. Abambolekisi abasemthethweni abaceli idiphozithi noma amavawusha ngaphambili. Lona ngumkhonyovu ojwayelekile.',
      nso: 'Temošo: O se ke wa lefa tšhelete pele gore o hwetše kadimo. Baabi ba semolao ga ba kgopele ditefo tša pele goba di-voucher. Ye ke boradia bjo bo tlwaelegilego.'
    }
  },

  TEMPLATE_IMPERSONATION_URGENT: {
    templateId: 'TEMPLATE_IMPERSONATION_URGENT',
    title: {
      en: 'Urgent Impersonation / Social Engineering Alert',
      zu: 'Umkhonyovu Wokuzenza Isikhulu Noma Isimo Esiphuthumayo',
      nso: 'Boradia bja go Itira Mohlankedi ka Tšhoganetšo'
    },
    summary: {
      en: 'High-pressure urgency cues combined with official entity impersonation (SASSA, bank fraud desk, police, or hospital crisis) targeting an unverified or newly added recipient.',
      zu: 'Amagama akuxhamazelisayo ahambisana nokuzenza isikhulu sakwa-SASSA, ibhange, amaphoyisa noma isibhedlela ukuze uthumele imali ku-akhawunti entsha engaqinisekisiwe.',
      nso: 'Mantšu a go go tšhošetša ka tšhoganetšo a kopane le go itira mohlankedi wa SASSA, panka, maphodisa goba sepetlele go akhaonto ye mpsha.'
    },
    reportingAuthority: 'SABRIC Bank Fraud Helpline & SASSA Fraud',
    reportingContact: '0860 101 248 / 0800 60 10 11',
    recommendedActions: {
      en: [
        'Pause for 5 minutes: Scammers manufacture panic so you transfer money before verifying.',
        'Hang up and call your family member, bank (number on the back of your card), or SASSA (0800 60 10 11) directly.',
        'Do NOT click unofficial links or reverse alleged "mistaken eWallet" SMS deposits.',
        'Block and report this recipient number before sending any funds.'
      ],
      zu: [
        'Thatha imizuzu emihlanu ucabange: Abakhohlisi bakufaka uvalo ukuze uthumele imali ungakaqinisekisi.',
        'Vala ucingo bese ushayela ilungu lomndeni, ibhange lakho (inombolo engemuva kwekhadi), noma i-SASSA (0800 60 10 11) ngqo.',
        'UNGACINDEZELI izixhumanisi zamanga futhi ungabuyiseli imali ye-SMS ye-eWallet mbumbulu.',
        'Vimba futhi ubike le nombolo ngaphambi kokuthumela imali.'
      ],
      nso: [
        'Khutša metsotso ye mehlano: Baradia ba hlola letšhogo gore o romele tšhelete o sa netefatša.',
        'Kgaola mogala gomme o leletše leloko la lapa, panka ya gago (nomoro ya ka morago ga karata), goba SASSA (0800 60 10 11) thwii.',
        'O SE KE wa kgotla di-link tša bofora goba wa bušetša tšhelete ya SMS ya bofora ya eWallet.',
        'Thibela le go bega nomoro ye pele o romela tšhelete.'
      ]
    },
    audioScriptTemplate: {
      en: 'Warning: Slow down and verify first. This message uses urgent panic tactics or pretends to be SASSA, the police, or your bank. Hang up and call the official helpline directly before sending {amount}.',
      zu: 'Isixwayiso: Yehlisa umoya uqinisekise kuqala. Lo mlayezo usebenzisa uvalo noma uzenza abakwa-SASSA, amaphoyisa, noma ibhange lakho. Vala ucingo ushayele inombolo esemthethweni ngaphambi kokuthumela u-{amount}.',
      nso: 'Temošo: Theoša maswafo o netefatše pele. Molaetša wo o šomiša letšhogo goba o itira SASSA, maphodisa, goba panka ya gago. Leletša nomoro ya semolao pele o romela {amount}.'
    }
  },

  TEMPLATE_UNAUTHORIZED_AGENT_FEE: {
    templateId: 'TEMPLATE_UNAUTHORIZED_AGENT_FEE',
    title: {
      en: 'Unauthorized Agent Fee / Cash-Out PIN Extortion',
      zu: 'Ukukhokhiswa Ngokungemthetho Kwe-Agent Noma Ukucelwa Kwe-PIN',
      nso: 'Tefo ye e sa Dumelelwago ya Agent Goba Kgopelo ya PIN'
    },
    summary: {
      en: 'Detected an excessive cash-out surcharge above the official tariff tier or a demand to disclose your secret PIN / One-Time PIN (OTP) to an agent.',
      zu: 'Kubanjwe imali engaphezulu kwemali esemthethweni yokukhipha imali noma isicelo sokuthi unikeze i-agent i-PIN yakho eyimfihlo noma i-OTP.',
      nso: 'Go lemogilwe tefo ya godimo ga kelo ya semolao ya go ntšha tšhelete goba kgopelo ya go fa agent PIN ya gago ya sephiri goba OTP.'
    },
    reportingAuthority: 'Banking Ombud & Mobile Network Fraud Desk',
    reportingContact: '0860 800 900 / 0860 101 248',
    recommendedActions: {
      en: [
        'Refuse to pay unofficial "extra cash-out" or "system offline" surcharges above {maxFee}.',
        'Shield your keypad: NEVER read out or hand your 4/5-digit PIN or OTP to a spaza or kiosk agent.',
        'Cancel the cash-out and use an official retail till (Shoprite, Pick n Pay, Boxer) or bank ATM.',
        'Submit this pre-filled incident report to flag the agent terminal ID.'
      ],
      zu: [
        'Nqaba ukukhokha imali engaphezulu kuka-{maxFee} yokukhipha imali okungeyona esemthethweni.',
        'Fihla izinombolo zakho: UNGAZE usho noma unikeze i-agent i-PIN yakho noma i-OTP.',
        'Khansela ukukhipha imali usebenzise ithili esemthethweni (Shoprite, Pick n Pay, Boxer) noma i-ATM.',
        'Thumela lo mbiko ukuze kubikwe leyo agent.'
      ],
      nso: [
        'Gana go lefa tefo ya tlaleletšo ya ka godimo ga {maxFee} ge o ntšha tšhelete.',
        'Šireletša dinomoro tša gago: O SE KE wa botša agent PIN ya gago ya sephiri goba OTP.',
        'Khansela modiro wo gomme o šomiše lebenkele la semolao (Shoprite, Pick n Pay, Boxer) goba ATM.',
        'Romela pego ye go bega agent yeo.'
      ]
    },
    audioScriptTemplate: {
      en: 'Warning: Do not hand over your PIN or pay extra cash-out fees. The official maximum fee for this withdrawal is {maxFee}. Never share your One-Time PIN with any agent.',
      zu: 'Isixwayiso: Unganikezi muntu i-PIN yakho futhi ungakhokhi imali engaphezulu. Imali esemthethweni ephezulu yokukhipha le mali ngu-{maxFee}. Ungaze wabelane nge-OTP yakho ne-agent.',
      nso: 'Temošo: O se ke wa fa motho PIN ya gago goba wa lefa tefo ya tlaleletšo. Tefo ya godimo ya semolao ke {maxFee}. O se ke wa abelana ka OTP ya gago le agent.'
    }
  },

  TEMPLATE_GENERAL_SAFE: {
    templateId: 'TEMPLATE_GENERAL_SAFE',
    title: {
      en: 'No Active Scam Pattern Detected',
      zu: 'Azikho Izimpawu Zomkhonyovu Ezitholiwe',
      nso: 'Ga go na Maano a Boradia a a Lemogilwego'
    },
    summary: {
      en: 'No high-risk advance-fee, impersonation, or agent extortion patterns were triggered. Always verify recipient details before sending cash.',
      zu: 'Azikho izimpawu zomkhonyovu wemalimboleko, ukuzenza isikhulu, noma ukukhokhiswa ngokungemthetho ezitholiwe. Qinisekisa imininingwane ngaphambi kokuthumela imali.',
      nso: 'Ga go na dika tša boradia tše di lemogilwego. Netefatša dintlha tša moamogedi ka mehla pele o romela tšhelete.'
    },
    reportingAuthority: 'SABRIC Fraud Prevention',
    reportingContact: '0860 101 248',
    recommendedActions: {
      en: [
        'Double-check the recipient mobile or account number before confirming.',
        'Keep your bank PIN and One-Time PIN (OTP) strictly private at all times.'
      ],
      zu: [
        'Hlola kabusha inombolo yocingo noma eye-akhawunti ngaphambi kokuqinisekisa.',
        'Gcina i-PIN yakho yasebhange kanye ne-OTP kuyimfihlo ngaso sonke isikhathi.'
      ],
      nso: [
        'Lekola gape nomoro ya mogala goba akhaonto pele o tiišetša.',
        'Boloka PIN ya gago ya panka le OTP e le sephiri ka mehla.'
      ]
    },
    audioScriptTemplate: {
      en: 'No scam patterns were detected in this check. Remember to keep your secret PIN private at all times.',
      zu: 'Azikho izimpawu zomkhonyovu ezitholiwe. Khumbula ukugcina i-PIN yakho iyimfihlo ngaso sonke isikhathi.',
      nso: 'Ga go na dika tša boradia tše di lemogilwego. Gopola go boloka PIN ya gago e le sephiri ka mehla.'
    }
  }
};

const interpolateSlots = (
  rawText: string,
  amountZar?: number,
  maxFeeZar?: number
): string => {
  const formattedAmount =
    typeof amountZar === 'number' && amountZar > 0
      ? `R${amountZar.toFixed(0)}`
      : 'any money';
  const formattedMaxFee =
    typeof maxFeeZar === 'number' && maxFeeZar > 0
      ? `R${maxFeeZar.toFixed(0)}`
      : 'the official tariff';

  return rawText
    .replace(/\{amount\}/g, formattedAmount)
    .replace(/\{maxFee\}/g, formattedMaxFee);
};

/**
 * Deduces the highest-priority Scam Context Template from a parser evaluation and transaction metadata.
 */
export const selectScamContextTemplate = (
  evaluation: ScamParserEvaluation,
  telemetry?: TransactionTelemetryPayload
): ScamTemplateId => {
  if (evaluation.riskScore < 0.12 && evaluation.signals.length === 0) {
    return 'TEMPLATE_GENERAL_SAFE';
  }

  const { categoryBreakdown, feeTierViolation } = evaluation;

  const predatoryScore =
    categoryBreakdown.PREDATORY_LENDING_UPFRONT_FEE +
    categoryBreakdown.PREDATORY_LENDING_UNREALISTIC_RETURN;

  const agentExtortionScore =
    categoryBreakdown.AGENT_FEE_EXTORTION +
    (telemetry?.operationType === 'cash_out' || telemetry?.operationType === 'cash_in'
      ? categoryBreakdown.PIN_OTP_DISCLOSURE
      : 0);

  const impersonationUrgentScore =
    categoryBreakdown.OFFICIAL_IMPERSONATION +
    categoryBreakdown.SOCIAL_ENGINEERING_URGENCY +
    (telemetry?.operationType !== 'cash_out' && telemetry?.operationType !== 'cash_in'
      ? categoryBreakdown.PIN_OTP_DISCLOSURE * 0.85
      : 0) +
    (telemetry?.isNewlyAddedRecipient ? 0.2 : 0);

  // Explicit agent fee tier violation takes precedence when cash-in/out overcharge occurs
  if (feeTierViolation && agentExtortionScore >= predatoryScore) {
    return 'TEMPLATE_UNAUTHORIZED_AGENT_FEE';
  }

  if (
    predatoryScore > 0 &&
    predatoryScore >= impersonationUrgentScore &&
    predatoryScore >= agentExtortionScore
  ) {
    return 'TEMPLATE_PREDATORY_LENDER';
  }

  if (
    agentExtortionScore > 0 &&
    agentExtortionScore >= impersonationUrgentScore &&
    agentExtortionScore >= predatoryScore
  ) {
    return 'TEMPLATE_UNAUTHORIZED_AGENT_FEE';
  }

  if (impersonationUrgentScore > 0 || evaluation.riskScore >= 0.25) {
    return 'TEMPLATE_IMPERSONATION_URGENT';
  }

  return 'TEMPLATE_GENERAL_SAFE';
};

/**
 * Generates plain-language, Web Speech API synthesizer-ready warning scripts
 * in English (`en`), isiZulu (`zu`), and Sepedi (`nso`).
 */
export const generateLocalizedAudioScripts = (
  templateId: ScamTemplateId,
  amountZar?: number,
  officialMaxFeeZar?: number
): LocalizedTextMap => {
  const template = SCAM_CONTEXT_TEMPLATES[templateId];
  return {
    en: interpolateSlots(template.audioScriptTemplate.en, amountZar, officialMaxFeeZar),
    zu: interpolateSlots(template.audioScriptTemplate.zu, amountZar, officialMaxFeeZar),
    nso: interpolateSlots(template.audioScriptTemplate.nso, amountZar, officialMaxFeeZar)
  };
};

/**
 * Full AI Scam Deduction & Incident Reporting Pipeline:
 * 1. Evaluates transcript & transaction telemetry via `evaluateScamRisk` (or accepts pre-computed evaluation).
 * 2. Maps signals to `TEMPLATE_PREDATORY_LENDER`, `TEMPLATE_IMPERSONATION_URGENT`, or `TEMPLATE_UNAUTHORIZED_AGENT_FEE`.
 * 3. Pre-populates a structured dispute/incident payload when the user clicks "Report Issue" or triggers an alert.
 * 4. Produces localized warning scripts in isiZulu, Sepedi, and English.
 */
export const deduceScamAndBuildIncidentReport = (params: {
  transcriptOrMessage: string;
  telemetry?: TransactionTelemetryPayload;
  preferredLanguage?: SupportedWarningLanguage;
  existingEvaluation?: ScamParserEvaluation;
}): ScamDeductionResult => {
  const {
    transcriptOrMessage,
    telemetry,
    preferredLanguage = 'en',
    existingEvaluation
  } = params;

  const evaluation =
    existingEvaluation ?? evaluateScamRisk(transcriptOrMessage, telemetry);

  const templateId = selectScamContextTemplate(evaluation, telemetry);
  const template = SCAM_CONTEXT_TEMPLATES[templateId];

  const amountZar = telemetry?.amountZar;
  const maxFeeZar = evaluation.feeTierViolation?.officialMaxFeeZar;

  const audioWarningScripts = generateLocalizedAudioScripts(
    templateId,
    amountZar,
    maxFeeZar
  );

  const localizedActions = template.recommendedActions[preferredLanguage].map(step =>
    interpolateSlots(step, amountZar, maxFeeZar)
  );

  const reportTimestamp = evaluation.evaluatedAtIso;
  const deterministicSuffix = Math.abs(
    Array.from(`${transcriptOrMessage}|${telemetry?.recipientId ?? 'local'}`).reduce(
      (hash, ch) => (hash * 31 + ch.charCodeAt(0)) | 0,
      7
    )
  )
    .toString(36)
    .toUpperCase()
    .slice(0, 6);

  const incidentReport: ContextualIncidentReportPayload = {
    reportId: `MB-SHIELD-${deterministicSuffix}`,
    createdAtIso: reportTimestamp,
    deducedTemplateId: templateId,
    deducedScamTitle: template.title[preferredLanguage],
    riskScore: evaluation.riskScore,
    severity: evaluation.severity,
    recommendedBlockTransfer: evaluation.isBlockedRecommended,
    reportingAuthority: template.reportingAuthority,
    reportingHotline: template.reportingContact,
    transactionMetadata: {
      transactionId: telemetry?.transactionId ?? 'TX-LOCAL-UNCOMMITTED',
      recipientId: telemetry?.recipientId ?? 'UNSPECIFIED_RECIPIENT',
      recipientName: telemetry?.recipientName ?? 'Unknown / Unverified Contact',
      amountZar: telemetry?.amountZar ?? 0,
      recipientAccountAgeDays: telemetry?.recipientAccountAgeDays ?? -1,
      isNewlyAddedRecipient: telemetry?.isNewlyAddedRecipient ?? false,
      recentTransferCountLastHour: telemetry?.recentTransferCountLastHour ?? 0,
      operationType: telemetry?.operationType ?? 'message_inspection',
      agentFeeChargedZar: telemetry?.agentFeeChargedZar ?? null
    },
    detectedTriggerKeywords: evaluation.matchedKeywords,
    triggeredRuleIds: evaluation.signals.map(sig => sig.ruleId),
    localizedActionSteps: localizedActions,
    audioWarningScripts,
    activeAudioScript: audioWarningScripts[preferredLanguage],
    userNarrativeSummary: `[${templateId}] Risk ${(evaluation.riskScore * 100).toFixed(0)}% (${evaluation.severity}). Triggers: ${
      evaluation.matchedKeywords.length > 0
        ? evaluation.matchedKeywords.join(', ')
        : 'none'
    }.`
  };

  return {
    template,
    evaluation,
    localizedTitle: template.title[preferredLanguage],
    localizedSummary: template.summary[preferredLanguage],
    localizedActions,
    audioWarningScripts,
    activeAudioScript: audioWarningScripts[preferredLanguage],
    incidentReport
  };
};
