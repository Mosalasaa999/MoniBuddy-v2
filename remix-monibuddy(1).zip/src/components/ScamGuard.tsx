import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  TransactionOperationType,
  TransactionTelemetryPayload,
  getOfficialMaxAgentFeeZar
} from '../scamParser';
import {
  SupportedWarningLanguage,
  deduceScamAndBuildIncidentReport
} from '../scamDeductionEngine';
import {
  ShieldUnitTestResult,
  runDefensiveShieldTestSuite
} from '../scamShield.test';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  PhoneCall,
  Copy,
  Check,
  Volume2,
  VolumeX,
  FileWarning,
  SlidersHorizontal,
  Play
} from 'lucide-react';

interface ThreatPreset {
  readonly title: string;
  readonly text: string;
  readonly telemetry: TransactionTelemetryPayload;
}

const PRESET_SCENARIOS: readonly ThreatPreset[] = [
  {
    title: 'Predatory Loan "Admin Fee"',
    text: 'Guaranteed instant loan of R10,000 approved with no credit check! Deposit R150 processing fee first via 1Voucher / Shoprite MoneyMarket to release your cash today.',
    telemetry: {
      transactionId: 'TX-LOAN-901',
      recipientId: '071 999 8821',
      recipientName: 'QuickCash Micro-Loans',
      amountZar: 150,
      recipientAccountAgeDays: 2,
      isNewlyAddedRecipient: true,
      recentTransferCountLastHour: 1,
      operationType: 'loan_fee_payment',
      isRegisteredCreditProvider: false
    }
  },
  {
    title: 'Hospital Emergency Impersonation',
    text: 'Hospital emergency! Your cousin was in a taxi accident and is in casualty, send right now R950 to this nurse number before midnight for urgent operation!',
    telemetry: {
      transactionId: 'TX-EMG-404',
      recipientId: '063 882 1904',
      recipientName: 'Nurse Dube (Unverified)',
      amountZar: 950,
      recipientAccountAgeDays: 1,
      isNewlyAddedRecipient: true,
      recentTransferCountLastHour: 3,
      operationType: 'p2p_transfer'
    }
  },
  {
    title: 'SASSA & Bank Fraud OTP Phishing',
    text: 'SASSA official verification desk & Capitec fraud department: Your SRD grant is suspended. Reply with your 5-digit secret PIN and OTP immediately at http://sassa-grant-verify.me',
    telemetry: {
      transactionId: 'TX-IMP-219',
      recipientId: '082 004 1192',
      recipientName: 'Unknown Caller',
      amountZar: 370,
      recipientAccountAgeDays: 0,
      isNewlyAddedRecipient: true,
      recentTransferCountLastHour: 2,
      operationType: 'p2p_transfer'
    }
  },
  {
    title: 'Agent Cash-Out Fee & PIN Extortion',
    text: 'Spaza kiosk agent says system offline fee applies: pay R45 extra cash-out fee to withdraw and read out your Cash-Send PIN to the teller.',
    telemetry: {
      transactionId: 'TX-CSH-772',
      recipientId: 'AGENT-KIOSK-19',
      recipientName: 'Corner Kiosk Cash-Out',
      amountZar: 400,
      recipientAccountAgeDays: 180,
      isNewlyAddedRecipient: false,
      recentTransferCountLastHour: 1,
      operationType: 'cash_out',
      agentFeeChargedZar: 45
    }
  },
  {
    title: 'Normal Spaza / Boxer Purchase',
    text: 'Capitec: R250.00 card purchase at Boxer Superstores on 24/10. Available balance R680.00. Helpline 0860 10 20 43.',
    telemetry: {
      transactionId: 'TX-SAFE-102',
      recipientId: 'MERCHANT-BOXER-04',
      recipientName: 'Boxer Superstores',
      amountZar: 250,
      recipientAccountAgeDays: 1200,
      isNewlyAddedRecipient: false,
      recentTransferCountLastHour: 1,
      operationType: 'merchant_payment'
    }
  }
];

export const ScamGuard: React.FC = () => {
  const { t, language, speakText, stopSpeaking, isSpeaking } = useApp();

  const [inputText, setInputText] = useState<string>(PRESET_SCENARIOS[0].text);
  const [showTelemetryControls, setShowTelemetryControls] = useState<boolean>(true);

  // Transaction Telemetry State
  const [recipientId, setRecipientId] = useState<string>(PRESET_SCENARIOS[0].telemetry.recipientId);
  const [recipientName, setRecipientName] = useState<string>(
    PRESET_SCENARIOS[0].telemetry.recipientName ?? ''
  );
  const [amountZar, setAmountZar] = useState<number>(PRESET_SCENARIOS[0].telemetry.amountZar);
  const [recipientAccountAgeDays, setRecipientAccountAgeDays] = useState<number>(
    PRESET_SCENARIOS[0].telemetry.recipientAccountAgeDays
  );
  const [isNewlyAddedRecipient, setIsNewlyAddedRecipient] = useState<boolean>(
    PRESET_SCENARIOS[0].telemetry.isNewlyAddedRecipient
  );
  const [recentTransferCountLastHour, setRecentTransferCountLastHour] = useState<number>(
    PRESET_SCENARIOS[0].telemetry.recentTransferCountLastHour
  );
  const [operationType, setOperationType] = useState<TransactionOperationType>(
    PRESET_SCENARIOS[0].telemetry.operationType ?? 'p2p_transfer'
  );
  const [agentFeeChargedZar, setAgentFeeChargedZar] = useState<number>(0);
  const [isRegisteredCreditProvider, setIsRegisteredCreditProvider] = useState<boolean>(false);

  // Audio script language & Incident Report visibility
  const [warningLang, setWarningLang] = useState<SupportedWarningLanguage>(
    language === 'zu' ? 'zu' : 'en'
  );
  const [showIncidentReport, setShowIncidentReport] = useState<boolean>(false);
  const [incidentSubmitted, setIncidentSubmitted] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Offline Self-Test Runner State
  const [testResults, setTestResults] = useState<readonly ShieldUnitTestResult[] | null>(null);

  const applyPreset = (preset: ThreatPreset) => {
    setInputText(preset.text);
    setRecipientId(preset.telemetry.recipientId);
    setRecipientName(preset.telemetry.recipientName ?? '');
    setAmountZar(preset.telemetry.amountZar);
    setRecipientAccountAgeDays(preset.telemetry.recipientAccountAgeDays);
    setIsNewlyAddedRecipient(preset.telemetry.isNewlyAddedRecipient);
    setRecentTransferCountLastHour(preset.telemetry.recentTransferCountLastHour);
    setOperationType(preset.telemetry.operationType ?? 'p2p_transfer');
    setAgentFeeChargedZar(preset.telemetry.agentFeeChargedZar ?? 0);
    setIsRegisteredCreditProvider(preset.telemetry.isRegisteredCreditProvider ?? true);
    setIncidentSubmitted(false);
  };

  const telemetryPayload = useMemo((): TransactionTelemetryPayload => {
    return {
      recipientId: recipientId.trim() || 'UNSPECIFIED',
      recipientName: recipientName.trim() || undefined,
      amountZar: Number.isFinite(amountZar) ? Math.max(0, amountZar) : 0,
      recipientAccountAgeDays: Math.max(0, recipientAccountAgeDays),
      isNewlyAddedRecipient,
      recentTransferCountLastHour: Math.max(0, recentTransferCountLastHour),
      operationType,
      agentFeeChargedZar:
        operationType === 'cash_out' || operationType === 'cash_in'
          ? Math.max(0, agentFeeChargedZar)
          : undefined,
      isRegisteredCreditProvider:
        operationType === 'loan_fee_payment' ? isRegisteredCreditProvider : undefined
    };
  }, [
    recipientId,
    recipientName,
    amountZar,
    recipientAccountAgeDays,
    isNewlyAddedRecipient,
    recentTransferCountLastHour,
    operationType,
    agentFeeChargedZar,
    isRegisteredCreditProvider
  ]);

  const deduction = useMemo(() => {
    if (!inputText.trim() && telemetryPayload.amountZar === 0) return null;
    return deduceScamAndBuildIncidentReport({
      transcriptOrMessage: inputText,
      telemetry: telemetryPayload,
      preferredLanguage: warningLang
    });
  }, [inputText, telemetryPayload, warningLang]);

  const copyToClipboard = (key: string, value: string) => {
    navigator.clipboard.writeText(value);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const officialMaxFee = getOfficialMaxAgentFeeZar(amountZar);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            {t.scamGuardTitle}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Context-Aware Defensive Shield — evaluates messages, voice transcripts, and transfer telemetry 100% offline
          </p>
        </div>

        {/* Localized Warning Language Selector */}
        <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1 self-start sm:self-auto">
          {(
            [
              { code: 'en', label: 'English' },
              { code: 'zu', label: 'isiZulu' },
              { code: 'nso', label: 'Sepedi' }
            ] as const
          ).map(item => (
            <button
              key={item.code}
              type="button"
              onClick={() => setWarningLang(item.code)}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                warningLang === item.code
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Defensive Shield Evaluator */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs space-y-5">
        {/* Preset Scenarios */}
        <div>
          <span className="text-xs font-semibold text-slate-600">
            Load a real-world scam or transaction scenario:
          </span>
          <div className="mt-2 flex flex-wrap gap-2">
            {PRESET_SCENARIOS.map(preset => (
              <button
                key={preset.title}
                type="button"
                onClick={() => applyPreset(preset)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-900 transition-colors whitespace-nowrap"
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        {/* Message / Transcript Input */}
        <div>
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-800">
              SMS, WhatsApp Message, or Spoken Transcript
            </label>
            {inputText && (
              <button
                type="button"
                onClick={() => setInputText('')}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                Clear text
              </button>
            )}
          </div>
          <textarea
            rows={3}
            value={inputText}
            onChange={e => {
              setInputText(e.target.value);
              setIncidentSubmitted(false);
            }}
            placeholder="Paste suspicious SMS, loan offer, emergency plea, or agent demand here..."
            className="mt-1.5 w-full rounded-xl border border-slate-200 p-3.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-hidden focus:ring-2 focus:ring-emerald-600/20 leading-relaxed"
          />
        </div>

        {/* Transaction Telemetry Inspector */}
        <div className="pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-slate-600" />
              <span className="text-xs font-bold text-slate-900">
                Transaction Telemetry Context (Offline Heuristic Inputs)
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowTelemetryControls(prev => !prev)}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
            >
              {showTelemetryControls ? 'Hide telemetry' : 'Edit telemetry'}
            </button>
          </div>

          {showTelemetryControls && (
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Recipient ID / Phone
                </label>
                <input
                  type="text"
                  value={recipientId}
                  onChange={e => setRecipientId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Transfer / Cash-Out Amount (ZAR)
                </label>
                <input
                  type="number"
                  min="0"
                  step="10"
                  value={amountZar}
                  onChange={e => setAmountZar(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Recipient Account Age (Days)
                </label>
                <input
                  type="number"
                  min="0"
                  value={recipientAccountAgeDays}
                  onChange={e => setRecipientAccountAgeDays(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Transfers in Last Hour (Velocity)
                </label>
                <input
                  type="number"
                  min="0"
                  value={recentTransferCountLastHour}
                  onChange={e => setRecentTransferCountLastHour(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600">
                  Operation Type
                </label>
                <select
                  value={operationType}
                  onChange={e => setOperationType(e.target.value as TransactionOperationType)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                >
                  <option value="p2p_transfer">Person-to-Person Transfer</option>
                  <option value="loan_fee_payment">Loan / Advance Fee Request</option>
                  <option value="cash_out">Agent Cash-Out</option>
                  <option value="cash_in">Agent Cash-In</option>
                  <option value="merchant_payment">Retail Merchant Payment</option>
                </select>
              </div>

              {(operationType === 'cash_out' || operationType === 'cash_in') && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600">
                    Agent Fee Demanded (Official max: R{officialMaxFee})
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={agentFeeChargedZar}
                    onChange={e => setAgentFeeChargedZar(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono tabular-nums text-slate-900 focus:border-emerald-600 focus:outline-hidden"
                  />
                </div>
              )}

              {operationType === 'loan_fee_payment' && (
                <div className="flex items-end pb-1.5">
                  <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!isRegisteredCreditProvider}
                      onChange={e => setIsRegisteredCreditProvider(!e.target.checked)}
                      className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-600"
                    />
                    <span>Unregistered Lender (Non-NCR)</span>
                  </label>
                </div>
              )}

              <div className="flex items-end pb-1.5">
                <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isNewlyAddedRecipient}
                    onChange={e => setIsNewlyAddedRecipient(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-600"
                  />
                  <span>Newly added recipient (&lt;24h)</span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Deduction Engine Result Card */}
        {deduction && (
          <div
            className={`rounded-2xl border p-5 space-y-4 ${
              deduction.evaluation.severity === 'CRITICAL' ||
              deduction.evaluation.severity === 'HIGH'
                ? 'border-rose-300 bg-rose-50/70'
                : deduction.evaluation.severity === 'MEDIUM' ||
                  deduction.evaluation.severity === 'LOW'
                ? 'border-amber-300 bg-amber-50/70'
                : 'border-emerald-300 bg-emerald-50/70'
            }`}
          >
            {/* Top Status Row */}
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                {deduction.evaluation.severity === 'CRITICAL' ||
                deduction.evaluation.severity === 'HIGH' ? (
                  <ShieldAlert className="h-6 w-6 text-rose-600 shrink-0 mt-0.5" />
                ) : deduction.evaluation.severity === 'MEDIUM' ||
                  deduction.evaluation.severity === 'LOW' ? (
                  <AlertTriangle className="h-6 w-6 text-amber-600 shrink-0 mt-0.5" />
                ) : (
                  <ShieldCheck className="h-6 w-6 text-emerald-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                    {deduction.localizedTitle}
                  </h3>
                  <div className="mt-0.5 text-xs text-slate-600 font-mono tabular-nums">
                    Template: {deduction.template.templateId} · Severity:{' '}
                    {deduction.evaluation.severity} · Risk Score:{' '}
                    {deduction.evaluation.riskScore.toFixed(2)} (
                    {Math.round(deduction.evaluation.riskScore * 100)}%)
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    if (isSpeaking) {
                      stopSpeaking();
                    } else {
                      speakText(deduction.activeAudioScript);
                    }
                  }}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="h-4 w-4 text-rose-600" />
                      <span>Stop Voice</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="h-4 w-4 text-emerald-700" />
                      <span>Play Warning ({warningLang.toUpperCase()})</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setShowIncidentReport(prev => !prev)}
                  className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
                >
                  <FileWarning className="h-4 w-4" />
                  <span>{showIncidentReport ? 'Hide Report' : 'Report Issue'}</span>
                </button>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
              {deduction.localizedSummary}
            </p>

            {/* Triggered Heuristic Signals */}
            {deduction.evaluation.signals.length > 0 && (
              <div className="pt-3 border-t border-black/10 space-y-1.5">
                <div className="text-xs font-bold text-slate-800">
                  Detected Heuristic Signals ({deduction.evaluation.signals.length})
                </div>
                <ul className="space-y-1 text-xs text-slate-700">
                  {deduction.evaluation.signals.map(sig => (
                    <li key={sig.ruleId} className="flex items-baseline justify-between gap-3">
                      <span>
                        <strong className="font-semibold text-slate-900">{sig.ruleId}:</strong>{' '}
                        {sig.description}
                      </span>
                      <span className="font-mono text-[11px] font-bold text-slate-600 tabular-nums shrink-0">
                        +{sig.weight.toFixed(2)}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Localized Recommended Action Steps */}
            <div className="pt-3 border-t border-black/10">
              <div className="text-xs font-bold text-slate-800 mb-1.5">
                Recommended Action Steps ({warningLang.toUpperCase()})
              </div>
              <ol className="list-decimal list-inside space-y-1 text-xs text-slate-800 font-medium">
                {deduction.localizedActions.map((step, index) => (
                  <li key={index}>{step}</li>
                ))}
              </ol>
            </div>

            {/* Voice-Synthesizer Script Preview (All 3 Languages) */}
            <div className="pt-3 border-t border-black/10 space-y-2">
              <div className="text-xs font-bold text-slate-800">
                Voice-Synthesizer Warning Scripts (Offline TTS Ready)
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
                <div className="rounded-xl bg-white/90 border border-black/5 p-3">
                  <div className="font-bold text-slate-700 mb-1">English (en)</div>
                  <p className="text-slate-600 leading-relaxed">
                    &ldquo;{deduction.audioWarningScripts.en}&rdquo;
                  </p>
                </div>
                <div className="rounded-xl bg-white/90 border border-black/5 p-3">
                  <div className="font-bold text-slate-700 mb-1">isiZulu (zu)</div>
                  <p className="text-slate-600 leading-relaxed">
                    &ldquo;{deduction.audioWarningScripts.zu}&rdquo;
                  </p>
                </div>
                <div className="rounded-xl bg-white/90 border border-black/5 p-3">
                  <div className="font-bold text-slate-700 mb-1">Sepedi (nso)</div>
                  <p className="text-slate-600 leading-relaxed">
                    &ldquo;{deduction.audioWarningScripts.nso}&rdquo;
                  </p>
                </div>
              </div>
            </div>

            {/* Auto-Populated Contextual Incident Report Payload */}
            {showIncidentReport && (
              <div className="pt-4 border-t border-black/10 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                      Pre-Populated Contextual Dispute &amp; Incident Report (
                      {deduction.incidentReport.reportId})
                    </h4>
                    <p className="text-[11px] text-slate-600">
                      Authority: {deduction.incidentReport.reportingAuthority} ·{' '}
                      {deduction.incidentReport.reportingHotline}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        copyToClipboard(
                          'incident_json',
                          JSON.stringify(deduction.incidentReport, null, 2)
                        )
                      }
                      className="flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                    >
                      {copiedKey === 'incident_json' ? (
                        <Check className="h-3.5 w-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="h-3.5 w-3.5" />
                      )}
                      <span>
                        {copiedKey === 'incident_json' ? 'Copied JSON' : 'Copy Payload'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIncidentSubmitted(true)}
                      className="rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-800"
                    >
                      Queue Dispute Packet
                    </button>
                  </div>
                </div>

                {incidentSubmitted && (
                  <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-xs font-semibold text-emerald-950">
                    Dispute report {deduction.incidentReport.reportId} queued locally for{' '}
                    {deduction.incidentReport.reportingAuthority}. Zero airtime used.
                  </div>
                )}

                <pre className="max-h-60 overflow-auto rounded-xl bg-slate-900 p-3.5 text-[11px] font-mono text-emerald-300 leading-relaxed">
                  {JSON.stringify(deduction.incidentReport, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Built-in Unit Test Verification Suite */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Defensive Shield Self-Verification Suite
            </h3>
            <p className="text-xs text-slate-500">
              Run deterministic unit tests for predatory micro-loans, emergency impersonation, and agent fee tiers
            </p>
          </div>
          <button
            type="button"
            onClick={() => setTestResults(runDefensiveShieldTestSuite())}
            className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
          >
            <Play className="h-3.5 w-3.5" />
            <span>Run 6 Unit Tests</span>
          </button>
        </div>

        {testResults ? (
          <div className="mt-3 divide-y divide-slate-100 text-xs">
            {testResults.map(res => (
              <div
                key={res.id}
                className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <span
                    className={`font-mono font-bold mr-2 ${
                      res.passed ? 'text-emerald-700' : 'text-rose-700'
                    }`}
                  >
                    {res.passed ? 'PASS' : 'FAIL'} · {res.id}
                  </span>
                  <span className="font-semibold text-slate-900">{res.name}</span>
                </div>
                <span className="font-mono text-[11px] text-slate-500 tabular-nums shrink-0">
                  {res.details}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-3 text-xs text-slate-500">
            Click <strong>Run 6 Unit Tests</strong> to execute `scamShield.test.ts` directly in your browser.
          </p>
        )}
      </div>

      {/* Official South African Fraud Hotlines */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-xs">
        <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
          <PhoneCall className="h-5 w-5 text-emerald-700" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Verified South African Fraud &amp; Credit Helplines
            </h3>
            <p className="text-xs text-slate-500">
              Free official numbers to report banking scams, mashonisa card retention, or SASSA fraud
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              category: 'Bank & Card Fraud',
              name: 'SABRIC Banking Helpline',
              desc: 'Report ATM skimming, fake bank SMSs, and unauthorized deductions.',
              phone: '0860 101 248'
            },
            {
              category: 'Predatory Lenders',
              name: 'National Credit Regulator (NCR)',
              desc: 'Report unregistered lenders demanding upfront fees or holding SASSA cards.',
              phone: '0860 627 627'
            },
            {
              category: 'Police & Extortion',
              name: 'SAPS Crime Stop',
              desc: 'Report threats, extortion, or physical confiscation of ID books and grant cards.',
              phone: '08600 10111'
            }
          ].map(line => (
            <div
              key={line.phone}
              className="rounded-xl border border-slate-200 p-4 flex flex-col justify-between"
            >
              <div>
                <div className="text-[11px] font-semibold text-slate-500">
                  {line.category}
                </div>
                <h4 className="mt-1 text-xs sm:text-sm font-bold text-slate-900">
                  {line.name}
                </h4>
                <p className="text-xs text-slate-500 mt-1">{line.desc}</p>
              </div>
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                  {line.phone}
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(line.phone, line.phone)}
                  className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  {copiedKey === line.phone ? (
                    <Check className="h-3 w-3 text-emerald-600" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                  <span>{copiedKey === line.phone ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
