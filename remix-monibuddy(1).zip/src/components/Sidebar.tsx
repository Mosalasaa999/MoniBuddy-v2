import React from 'react';
import { useApp } from '../context/AppContext';
import { TabType } from '../types';
import {
  PiggyBank,
  ArrowDownUp,
  ShieldCheck,
  ShieldAlert,
  Smartphone,
  BookOpen,
  Lock,
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface SidebarProps {
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  mobileOpen,
  setMobileOpen
}) => {
  const {
    t,
    resetAllData,
    loadDemoData,
    pots,
    transactions
  } = useApp();

  const handleNavClick = (tab: TabType) => {
    setCurrentTab(tab);
    setMobileOpen(false);
  };

  const navItems: { id: TabType; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'overview',
      label: t.navOverview,
      icon: <PiggyBank className="h-4 w-4" />,
      badge: pots.length > 0 ? `${pots.length}` : undefined
    },
    {
      id: 'income_expenses',
      label: t.navIncomeExpenses,
      icon: <ArrowDownUp className="h-4 w-4" />,
      badge: transactions.length > 0 ? `${transactions.length}` : undefined
    },
    {
      id: 'buffer_credit',
      label: t.navBufferCredit,
      icon: <ShieldCheck className="h-4 w-4" />
    },
    {
      id: 'scam_guard',
      label: t.navScamGuard,
      icon: <ShieldAlert className="h-4 w-4" />
    },
    {
      id: 'sync_2g',
      label: t.nav2gSync,
      icon: <Smartphone className="h-4 w-4" />
    }
  ];

  const infoItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    {
      id: 'technical_brief',
      label: t.navTechnicalBrief,
      icon: <BookOpen className="h-4 w-4" />
    },
    {
      id: 'privacy_legal',
      label: t.navPrivacyLegal,
      icon: <Lock className="h-4 w-4" />
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 shrink-0 flex-col border-r border-slate-200 bg-white transition-transform duration-200 ease-in-out md:static md:h-full md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Mobile Header */}
        <div className="flex h-14 items-center gap-2.5 border-b border-slate-100 px-6 md:hidden">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-700 text-white font-bold">
            m
          </div>
          <span className="font-bold text-slate-900">monibuddy</span>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          <div>
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              MY MONEY
            </div>
            <nav className="space-y-1">
              {navItems.map(item => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`group flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-emerald-50 text-emerald-900 shadow-xs ring-1 ring-emerald-600/15'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`transition-colors ${
                          isActive ? 'text-emerald-700' : 'text-slate-400 group-hover:text-slate-600'
                        }`}
                      >
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          isActive
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          <div>
            <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              HELP &amp; SAFETY
            </div>
            <nav className="space-y-1">
              {infoItems.map(item => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-emerald-50 text-emerald-900 shadow-xs ring-1 ring-emerald-600/15'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <span
                      className={`transition-colors ${
                        isActive ? 'text-emerald-700' : 'text-slate-400 group-hover:text-slate-600'
                      }`}
                    >
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Friendly Sample Data Box */}
        <div className="border-t border-slate-200 p-4 bg-slate-50/60">
          <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs">
            <div className="text-xs font-bold text-slate-800">Try with sample data?</div>
            <p className="mt-0.5 text-[11px] text-slate-500 leading-snug">
              Load typical township expenses (taxi, spaza, electricity) to test the app.
            </p>

            <div className="mt-3 flex flex-col gap-1.5">
              <button
                onClick={loadDemoData}
                className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-700 transition-colors"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>Load Sample Data</span>
              </button>
              <button
                onClick={resetAllData}
                className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 hover:text-slate-800 transition-colors"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Start Fresh (Clear)</span>
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
