import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Language, NetworkMode } from '../types';
import { Volume2, Globe, Wifi, WifiOff, Radio, ChevronDown, Check, LogOut, Mic } from 'lucide-react';

interface NavbarProps {
  onOpenAudioGuideModal: () => void;
  onOpenVoiceModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAudioGuideModal,
  onOpenVoiceModal
}) => {
  const {
    currentUser,
    logout,
    language,
    setLanguage,
    networkMode,
    setNetworkMode,
    isSpeaking,
    stopSpeaking,
    t
  } = useApp();

  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [networkDropdownOpen, setNetworkDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'zu', label: 'isiZulu' },
    { code: 'xh', label: 'isiXhosa' },
    { code: 'st', label: 'Sesotho' },
    { code: 'af', label: 'Afrikaans' },
  ];

  const currentLangLabel = languages.find(l => l.code === language)?.label || 'English';

  return (
    <header className="shrink-0 z-30 flex items-center justify-between border-b border-slate-200 bg-white/95 px-4 py-2.5 backdrop-blur-md sm:px-6">
      {/* Brand logo & Plain Tagline */}
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 shadow-xs text-white font-extrabold text-xl">
          m
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold tracking-tight text-slate-900">monibuddy</span>
            <span className="hidden rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-800 ring-1 ring-emerald-600/20 sm:inline-block">
              Free &amp; Offline
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {t.tagline}
          </p>
        </div>
      </div>

      {/* Top Controls: Voice Capture, Audio, Language & Connection Status */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Voice Capture Trigger */}
        <button
          onClick={onOpenVoiceModal}
          className="flex items-center gap-1.5 rounded-xl bg-emerald-700 px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-800 transition-colors whitespace-nowrap shrink-0"
          title="Log income or expense by voice"
        >
          <Mic className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Voice Log</span>
        </button>

        {/* Audio Guide Spoken Help */}
        <button
          onClick={() => {
            if (isSpeaking) {
              stopSpeaking();
            } else {
              onOpenAudioGuideModal();
            }
          }}
          className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-bold transition-all ${
            isSpeaking
              ? 'border-emerald-500 bg-emerald-50 text-emerald-800 shadow-xs animate-pulse ring-2 ring-emerald-500/20'
              : 'border-slate-200 bg-white text-slate-700 shadow-xs hover:border-emerald-300 hover:text-emerald-800'
          }`}
          title="Listen to this page read aloud"
        >
          <Volume2 className={`h-4 w-4 ${isSpeaking ? 'text-emerald-700 animate-bounce' : 'text-slate-500'}`} />
          <span>{isSpeaking ? t.audioGuideActive : t.audioGuide}</span>
        </button>

        {/* Language Selector */}
        <div className="relative">
          <button
            onClick={() => setLangDropdownOpen(!langDropdownOpen)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 shadow-xs hover:border-slate-300 hover:bg-slate-50"
            title="Choose your language"
          >
            <Globe className="h-3.5 w-3.5 text-emerald-600" />
            <span>{currentLangLabel}</span>
            <ChevronDown className="h-3 w-3 text-slate-400" />
          </button>

          {langDropdownOpen && (
            <>
              <div 
                className="fixed inset-0 z-40" 
                onClick={() => setLangDropdownOpen(false)} 
              />
              <div className="absolute right-0 z-50 mt-1.5 w-40 rounded-xl border border-slate-200 bg-white py-1.5 shadow-lg ring-1 ring-black/5 animate-in fade-in-50 zoom-in-95">
                <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Select Language
                </div>
                {languages.map(item => (
                  <button
                    key={item.code}
                    onClick={() => {
                      setLanguage(item.code);
                      setLangDropdownOpen(false);
                    }}
                    className={`flex w-full items-center justify-between px-3 py-1.5 text-xs font-medium transition-colors ${
                      language === item.code
                        ? 'bg-emerald-50 text-emerald-900 font-bold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{item.label}</span>
                    {language === item.code && <Check className="h-3.5 w-3.5 text-emerald-600" />}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Simplified Connection Status */}
        <div className="relative">
          <button
            onClick={() => setNetworkDropdownOpen(!networkDropdownOpen)}
            className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-bold shadow-xs transition-colors ${
              networkMode === '2g'
                ? 'border-amber-300 bg-amber-50 text-amber-900'
                : networkMode === 'offline'
                ? 'border-rose-300 bg-rose-50 text-rose-900'
                : 'border-emerald-200 bg-emerald-50 text-emerald-900'
            }`}
            title="Connection signal mode"
          >
            {networkMode === '2g' && <Radio className="h-3.5 w-3.5 text-amber-600" />}
            {networkMode === 'offline' && <WifiOff className="h-3.5 w-3.5 text-rose-600" />}
            {networkMode === '4g' && <Wifi className="h-3.5 w-3.5 text-emerald-600" />}

            <span className="hidden sm:inline">
              {networkMode === '2g' ? 'Signal: Weak 2G' : networkMode === 'offline' ? 'No Internet (Offline)' : 'Signal: Good'}
            </span>
            <span className="sm:hidden">
              {networkMode === '2g' ? '2G' : networkMode === 'offline' ? 'Offline' : 'Online'}
            </span>
            <ChevronDown className="h-3 w-3 opacity-60" />
          </button>

          {networkDropdownOpen && (
            <>
              <div 
                className="fixed inset-0 z-40" 
                onClick={() => setNetworkDropdownOpen(false)} 
              />
              <div className="absolute right-0 z-50 mt-1.5 w-56 rounded-xl border border-slate-200 bg-white p-2 shadow-lg ring-1 ring-black/5 animate-in fade-in-50 zoom-in-95">
                <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Simulate Phone Signal
                </div>
                
                <button
                  onClick={() => {
                    setNetworkMode('4g');
                    setNetworkDropdownOpen(false);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg p-2 text-left transition-colors ${
                    networkMode === '4g' ? 'bg-emerald-50 text-emerald-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <Wifi className="h-4 w-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="text-xs">Normal Internet</div>
                    <div className="text-[11px] text-slate-500 font-normal">When you have normal data/Wi-Fi</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setNetworkMode('2g');
                    setNetworkDropdownOpen(false);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg p-2 text-left transition-colors mt-1 ${
                    networkMode === '2g' ? 'bg-amber-50 text-amber-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <Radio className="h-4 w-4 text-amber-600 shrink-0" />
                  <div>
                    <div className="text-xs">Weak 2G Signal</div>
                    <div className="text-[11px] text-slate-500 font-normal">Slow network or low airtime</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setNetworkMode('offline');
                    setNetworkDropdownOpen(false);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg p-2 text-left transition-colors mt-1 ${
                    networkMode === 'offline' ? 'bg-rose-50 text-rose-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <WifiOff className="h-4 w-4 text-rose-600 shrink-0" />
                  <div>
                    <div className="text-xs">No Internet (Airplane Mode)</div>
                    <div className="text-[11px] text-slate-500 font-normal">Saves everything on your phone</div>
                  </div>
                </button>
              </div>
            </>
          )}
        </div>

        {/* User Profile & Logout Button */}
        {currentUser && (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-800 shadow-xs hover:border-emerald-300 hover:bg-slate-50 transition-colors"
                title="Account & Security"
              >
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-700 text-white text-[10px] font-extrabold uppercase">
                  {currentUser.name.charAt(0)}
                </div>
                <span className="hidden md:inline max-w-[90px] truncate">
                  {currentUser.name.split(' ')[0]}
                </span>
                <ChevronDown className="h-3 w-3 text-slate-400" />
              </button>

              {userDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setUserDropdownOpen(false)}
                  />
                  <div className="absolute right-0 z-50 mt-1.5 w-56 rounded-2xl border border-slate-200 bg-white p-3 shadow-xl ring-1 ring-black/5 animate-in fade-in-50 zoom-in-95">
                    <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                      <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800 text-xs font-extrabold uppercase">
                        {currentUser.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900 truncate">
                          {currentUser.name}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {currentUser.phone}
                        </div>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          logout();
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50 transition-colors"
                      >
                        <LogOut className="h-4 w-4 text-rose-600" />
                        <span>Lock Ledger &amp; Sign Out</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </header>
    );
  };
